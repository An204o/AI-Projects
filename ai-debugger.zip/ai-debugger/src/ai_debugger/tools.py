"""Structured tool interface for the debugging agent.

Every call is schema-validated, executed against a sandbox and logged. A call
is *valid* when the tool exists, the arguments match the schema and the
operation itself succeeds. A patch that applies cleanly but fails the tests is
a valid call whose patch is *rejected* (and automatically reverted).
"""

from __future__ import annotations

import time
from typing import Any

from . import schema
from .error_parser import format_report, parse_errors
from .models import ErrorReport, Edit, ToolEvent
from .patcher import PatchError, apply_edits, revert
from .retrieval import CodeIndex
from .sandbox import Sandbox, TestOutcome, ToolError

_NO_ARGS = {"type": "object", "properties": {}, "additionalProperties": False}
_EDIT = {
    "type": "object",
    "properties": {
        "path": {"type": "string", "description": "Relative path of a source file."},
        "old": {"type": "string", "description": "Exact text to replace; must occur exactly once."},
        "new": {"type": "string", "description": "Replacement text."},
    },
    "required": ["path", "old", "new"],
    "additionalProperties": False,
}

TOOL_SPECS: list[dict[str, Any]] = [
    {
        "name": "list_files",
        "description": "List every file in the workspace.",
        "input_schema": _NO_ARGS,
    },
    {
        "name": "read_file",
        "description": "Return the full text of one workspace file, with line numbers.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "Relative file path."}},
            "required": ["path"],
            "additionalProperties": False,
        },
    },
    {
        "name": "run_tests",
        "description": (
            "Run the test suite. Returns the pass/fail summary and a structured list of errors "
            "(exception type, message, traceback frames)."
        ),
        "input_schema": _NO_ARGS,
    },
    {
        "name": "search_code",
        "description": (
            "Retrieve the source functions most relevant to the latest test errors "
            "(and an optional free-text query)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Optional extra keywords or identifiers."},
                "top_k": {"type": "integer", "minimum": 1, "description": "Snippets to return (default 3)."},
            },
            "required": [],
            "additionalProperties": False,
        },
    },
    {
        "name": "propose_patch",
        "description": (
            "Apply a patch made of exact-text edits, then run the tests. If any test still fails the "
            "patch is reverted and rejected. The number of patch attempts is limited."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "edits": {"type": "array", "minItems": 1, "items": _EDIT},
                "rationale": {"type": "string", "description": "One sentence on why this fixes the bug."},
            },
            "required": ["edits"],
            "additionalProperties": False,
        },
    },
]

PREVIEW_CHARS = 300


class ToolResult:
    __slots__ = ("ok", "output")

    def __init__(self, ok: bool, output: str):
        self.ok = ok
        self.output = output


class ToolBox:
    def __init__(self, sandbox: Sandbox, max_patch_attempts: int = 3, max_output_chars: int = 4000):
        self.sandbox = sandbox
        self.max_patch_attempts = max_patch_attempts
        self.max_output_chars = max_output_chars
        self.events: list[ToolEvent] = []
        self.patch_attempts = 0
        self.rejected_patches = 0
        self.solved = False
        self.last_reports: list[ErrorReport] = []
        self.last_outcome: TestOutcome | None = None
        self._specs = {spec["name"]: spec for spec in TOOL_SPECS}

    # -- state -------------------------------------------------------------
    @property
    def valid_calls(self) -> int:
        return sum(1 for e in self.events if e.ok)

    @property
    def invalid_calls(self) -> int:
        return sum(1 for e in self.events if not e.ok)

    @property
    def patch_budget_left(self) -> int:
        return max(0, self.max_patch_attempts - self.patch_attempts)

    # -- dispatch ----------------------------------------------------------
    def call(self, name: str, args: Any) -> ToolResult:
        started = time.perf_counter()
        ok, error, meta = True, None, {}
        try:
            spec = self._specs.get(name)
            if spec is None:
                raise ToolError(f"unknown tool {name!r}; available: {', '.join(self._specs)}")
            problems = schema.validate(args, spec["input_schema"])
            if problems:
                raise ToolError("invalid arguments: " + "; ".join(problems))
            output, meta = getattr(self, f"_tool_{name}")(**args)
        except ToolError as exc:
            ok, error, output = False, str(exc), f"ERROR: {exc}"
        output = self._clip(output)
        self.events.append(
            ToolEvent(
                step=len(self.events) + 1,
                tool=str(name),
                args=self._summarise(args),
                ok=ok,
                error=error,
                preview=output[:PREVIEW_CHARS],
                duration_s=round(time.perf_counter() - started, 4),
                meta=meta,
            )
        )
        return ToolResult(ok, output)

    # -- tools -------------------------------------------------------------
    def _tool_list_files(self) -> tuple[str, dict]:
        return "\n".join(self.sandbox.list_files()), {}

    def _tool_read_file(self, path: str) -> tuple[str, dict]:
        text = self.sandbox.read(path)
        numbered = "\n".join(f"{n:4d}  {line}" for n, line in enumerate(text.splitlines(), start=1))
        return numbered, {"path": path}

    def _run(self) -> TestOutcome:
        outcome = self.sandbox.run_tests()
        self.last_outcome = outcome
        self.last_reports = parse_errors(outcome.output, str(self.sandbox.root))
        return outcome

    def _describe(self, outcome: TestOutcome) -> str:
        parts = [outcome.summary()]
        for report in self.last_reports:
            parts.append(format_report(report))
        if not self.last_reports and not outcome.all_passed:
            parts.append(outcome.output)
        return "\n".join(parts)

    def _tool_run_tests(self) -> tuple[str, dict]:
        outcome = self._run()
        meta = {
            "passed": outcome.passed, "total": outcome.total, "all_passed": outcome.all_passed,
            "errors": [r.signature() for r in self.last_reports][:5],
        }
        return self._describe(outcome), meta

    def _tool_search_code(self, query: str = "", top_k: int = 3) -> tuple[str, dict]:
        if self.last_outcome is None:
            self._run()  # retrieval needs at least one error report
        files = {
            p: self.sandbox.read(p)
            for p in self.sandbox.list_files()
            if p.endswith(".py") and not self.sandbox.is_protected(p)
        }
        snippets = CodeIndex(files).search(self.last_reports, query, min(top_k, 10))
        if not snippets:
            return "no relevant code found", {"results": 0}
        meta = {"results": len(snippets), "top": f"{snippets[0].path}:{snippets[0].name}"}
        return "\n\n".join(s.render() for s in snippets), meta

    def _tool_propose_patch(self, edits: list[dict], rationale: str = "") -> tuple[str, dict]:
        if self.patch_attempts >= self.max_patch_attempts:
            raise ToolError("patch budget exhausted; no further patches are accepted")
        self.patch_attempts += 1
        try:
            applied = apply_edits(self.sandbox, [Edit(e["path"], e["old"], e["new"]) for e in edits])
        except PatchError as exc:
            self.rejected_patches += 1
            raise ToolError(f"patch rejected, nothing applied: {exc}") from exc
        outcome = self._run()
        meta = {
            "attempt": self.patch_attempts, "files": applied.paths,
            "passed": outcome.passed, "total": outcome.total, "validated": outcome.all_passed,
        }
        if outcome.all_passed:
            self.solved = True
            return f"patch accepted: {outcome.summary()}", meta
        self.rejected_patches += 1
        revert(self.sandbox, applied)
        left = self.patch_budget_left
        return (
            f"patch REJECTED and reverted ({outcome.summary()}); {left} attempt(s) left.\n"
            + self._describe(outcome)
        ), meta

    # -- helpers -----------------------------------------------------------
    def _clip(self, text: str) -> str:
        if len(text) <= self.max_output_chars:
            return text
        return text[: self.max_output_chars] + "\n...[output truncated]"

    @staticmethod
    def _summarise(args: Any) -> dict[str, Any]:
        if not isinstance(args, dict):
            return {"_invalid": repr(args)[:100]}
        out: dict[str, Any] = {}
        for key, value in args.items():
            if key == "edits" and isinstance(value, list):
                out[key] = [
                    {"path": e.get("path")} if isinstance(e, dict) else "<invalid>" for e in value
                ]
            elif isinstance(value, str) and len(value) > 80:
                out[key] = f"<{len(value)} chars>"
            else:
                out[key] = value
        return out
