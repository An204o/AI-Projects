"""Isolated workspace for one agent run, plus the pytest-based grader."""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path

from .models import Scenario

# Files an agent may never create or modify: tests and anything that could
# change how pytest or the interpreter behaves.
PROTECTED_NAMES = {
    "conftest.py",
    "pytest.ini",
    "tox.ini",
    "setup.cfg",
    "pyproject.toml",
    "sitecustomize.py",
    "usercustomize.py",
}
IGNORED_DIRS = {"__pycache__", ".pytest_cache"}
IGNORED_FILES = {".junit.xml"}
OUTPUT_TAIL_CHARS = 3000


class ToolError(Exception):
    """A tool call was invalid or could not be carried out."""


@dataclass
class TestOutcome:
    """Result of one pytest run."""

    # Tell pytest this is a result record, not a test class.
    __test__ = False

    total: int
    passed: int
    failed: int
    errors: int
    skipped: int
    timed_out: bool
    returncode: int | None
    syntax_error: bool
    duration_s: float
    output: str

    @property
    def all_passed(self) -> bool:
        return (
            not self.timed_out
            and self.returncode == 0
            and self.failed == 0
            and self.errors == 0
            and self.total > 0
        )

    def summary(self) -> str:
        if self.timed_out:
            return "TIMED OUT"
        return (
            f"{self.passed} passed, {self.failed} failed, {self.errors} errors "
            f"(of {self.total} collected)"
        )


def _kill_process_tree(proc: subprocess.Popen) -> None:
    try:
        if os.name == "posix":
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        else:  # pragma: no cover - Windows
            proc.kill()
    except (ProcessLookupError, PermissionError, OSError):
        pass


def _tail(text: str, limit: int = OUTPUT_TAIL_CHARS) -> str:
    return text if len(text) <= limit else "...[truncated]...\n" + text[-limit:]


class Sandbox:
    """A temporary directory holding one task's files.

    Use as a context manager. The agent reads and writes through
    :meth:`read`, :meth:`write` and friends, which enforce path safety. The
    grader calls :meth:`restore_tests` and :meth:`run_tests`.
    """

    def __init__(self, task: Scenario, test_timeout_s: float = 30.0, base_dir: str | None = None):
        self.task = task
        self.test_timeout_s = test_timeout_s
        self._base_dir = base_dir
        self._tmp: tempfile.TemporaryDirectory | None = None
        self.root: Path = Path()

    # -- lifecycle ---------------------------------------------------------
    def __enter__(self) -> "Sandbox":
        self._tmp = tempfile.TemporaryDirectory(prefix="ai_debugger_", dir=self._base_dir)
        self.root = Path(self._tmp.name).resolve()
        for path, content in {**self.task.files, **self.task.tests}.items():
            self._write_raw(path, content)
        return self

    def __exit__(self, *exc_info) -> None:
        if self._tmp is not None:
            self._tmp.cleanup()
            self._tmp = None

    # -- path handling -----------------------------------------------------
    def resolve(self, path: str) -> Path:
        """Resolve ``path`` inside the workspace or raise :class:`ToolError`."""
        if not isinstance(path, str) or not path.strip():
            raise ToolError("path must be a non-empty string")
        candidate = (self.root / path).resolve()
        if candidate != self.root and self.root not in candidate.parents:
            raise ToolError(f"path escapes the workspace: {path!r}")
        return candidate

    def relative(self, path: Path) -> str:
        return path.relative_to(self.root).as_posix()

    @staticmethod
    def is_protected(path: str) -> bool:
        parts = Path(path).as_posix().split("/")
        return parts[0] == "tests" or parts[-1] in PROTECTED_NAMES

    def _write_raw(self, path: str, content: str) -> None:
        target = self.resolve(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")

    # -- agent-facing operations -------------------------------------------
    def list_files(self) -> list[str]:
        found: list[str] = []
        for current, dirs, files in os.walk(self.root):
            dirs[:] = sorted(d for d in dirs if d not in IGNORED_DIRS)
            for name in sorted(files):
                if name in IGNORED_FILES:
                    continue
                found.append(self.relative(Path(current) / name))
        return sorted(found)

    def read(self, path: str) -> str:
        target = self.resolve(path)
        if not target.is_file():
            raise ToolError(f"no such file: {path}")
        return target.read_text(encoding="utf-8", errors="replace")

    def write(self, path: str, content: str) -> None:
        if not isinstance(content, str):
            raise ToolError("content must be a string")
        # Check the *resolved* location so "src/../tests/x.py" is caught too.
        relative = self.relative(self.resolve(path))
        if self.is_protected(relative):
            raise ToolError(f"{path} is read-only (tests and configuration are protected)")
        self._write_raw(relative, content)

    # -- grading -----------------------------------------------------------
    def restore_tests(self) -> None:
        """Rewrite the original test files, undoing any tampering."""
        for path, content in self.task.tests.items():
            self._write_raw(path, content)
        for name in PROTECTED_NAMES:
            stray = self.root / name
            if stray.exists() and name not in {Path(p).name for p in self.task.tests}:
                stray.unlink()

    def edited_files(self) -> list[str]:
        """Source files that were created or changed relative to the task."""
        edited = []
        for path in self.list_files():
            if self.is_protected(path):
                continue
            original = self.task.files.get(path)
            if original is None or self.read(path) != original:
                edited.append(path)
        return edited

    def run_tests(self) -> TestOutcome:
        return run_pytest(self.root, self.test_timeout_s, self.task.expected_tests)


def run_pytest(root: Path, timeout_s: float, expected_total: int) -> TestOutcome:
    """Run pytest in ``root`` and return structured results.

    Counts come from a junit XML report, so they do not depend on parsing
    console output. A hung run is killed after ``timeout_s`` seconds.
    """
    junit = root / ".junit.xml"
    if junit.exists():
        junit.unlink()
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "-q",
        "--tb=short",
        "-p",
        "no:cacheprovider",
        f"--junitxml={junit}",
        "tests",
    ]
    env = {
        **os.environ,
        "PYTHONPATH": str(root),
        "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONHASHSEED": "0",
    }
    env.pop("PYTEST_ADDOPTS", None)
    start = time.perf_counter()
    proc = subprocess.Popen(
        cmd,
        cwd=root,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        errors="replace",
        start_new_session=(os.name == "posix"),
    )
    timed_out = False
    try:
        output, _ = proc.communicate(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        timed_out = True
        _kill_process_tree(proc)
        output, _ = proc.communicate()
    duration = time.perf_counter() - start

    tests = failures = errors = skipped = 0
    if junit.exists():
        try:
            for suite in ET.parse(junit).getroot().iter("testsuite"):
                tests += int(suite.get("tests", 0))
                failures += int(suite.get("failures", 0))
                errors += int(suite.get("errors", 0))
                skipped += int(suite.get("skipped", 0))
        except ET.ParseError:
            pass
    passed = max(0, tests - failures - errors - skipped)
    total = max(expected_total, tests)
    return TestOutcome(
        total=total,
        passed=min(passed, total),
        failed=failures,
        errors=errors,
        skipped=skipped,
        timed_out=timed_out,
        returncode=None if timed_out else proc.returncode,
        syntax_error=("SyntaxError" in output or "IndentationError" in output),
        duration_s=duration,
        output=_tail(output),
    )


def copy_tree(src: Path, dst: Path) -> None:
    """Small helper used by tests and tooling."""
    shutil.copytree(src, dst, dirs_exist_ok=True)
