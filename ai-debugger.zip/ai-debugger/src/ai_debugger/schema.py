"""A small JSON-Schema subset validator for tool arguments.

Supports: type (object, array, string, integer), properties, required, items,
additionalProperties=false, minItems and minimum. That covers every tool
interface in this project without adding a dependency.
"""

from __future__ import annotations

from typing import Any

_TYPES: dict[str, tuple[type, ...]] = {
    "object": (dict,),
    "array": (list,),
    "string": (str,),
    "integer": (int,),
}


def validate(value: Any, schema: dict[str, Any], path: str = "arguments") -> list[str]:
    """Return a list of human-readable problems; empty means valid."""
    problems: list[str] = []
    expected = schema.get("type")
    if expected:
        python_types = _TYPES[expected]
        # bool is a subclass of int; never accept it as an integer
        if not isinstance(value, python_types) or isinstance(value, bool) and expected == "integer":
            return [f"{path} must be {expected}, got {type(value).__name__}"]
    if isinstance(value, dict):
        properties = schema.get("properties", {})
        for name in schema.get("required", []):
            if name not in value:
                problems.append(f"{path}.{name} is required")
        for name, item in value.items():
            if name in properties:
                problems += validate(item, properties[name], f"{path}.{name}")
            elif schema.get("additionalProperties") is False:
                problems.append(f"{path}.{name} is not allowed")
    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0):
            problems.append(f"{path} needs at least {schema['minItems']} item(s)")
        if "items" in schema:
            for index, item in enumerate(value):
                problems += validate(item, schema["items"], f"{path}[{index}]")
    if isinstance(value, int) and not isinstance(value, bool) and "minimum" in schema:
        if value < schema["minimum"]:
            problems.append(f"{path} must be >= {schema['minimum']}")
    return problems
