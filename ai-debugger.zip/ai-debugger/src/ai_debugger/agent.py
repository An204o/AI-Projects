"""The debugging agent loop, run budgets and the single-run driver."""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass
from typing import Any

from .error_parser import format_report
from .llm import ChatClient
from .models import ExecutionRecord, Scenario
from .sandbox import Sandbox, TestOutcome
from .tools import TOOL_SPECS, ToolBox

SYSTEM_PROMPT = (
    "You are a careful debugging agent working in a small Python project whose tests fail. "
    "Workflow: inspect the error, retrieve and read the relevant source, then propose a minimal "
    "patch with propose_patch. Patches are validated by running the full test suite and are reverted "
    "if any test still fails; you have a small, fixed number of patch attempts, so read carefully "
    "before patching. Never edit tests or configuration. When a patch is accepted, reply with a "
    "one-sentence summary and make no further tool calls."
)


@dataclass
class Limits:
    """Per-run bounds."""

    max_steps: int = 20          # total tool calls
    max_patch_attempts: int = 3  # bounded retries
    max_invalid_calls: int = 5   # malformed / failing calls tolerated
    wall_timeout_s: float = 300.0
    test_timeout_s: float = 30.0

    def __post_init__(self) -> None:
        for name in ("max_steps", "max_patch_attempts", "max_invalid_calls"):
            if getattr(self, name) < 1:
                raise ValueError(f"{name} must be >= 1")
        if self.wall_timeout_s <= 0 or self.test_timeout_s <= 0:
            raise ValueError("timeouts must be positive")


class Budget:
    def __init__(self, limits: Limits):
        self.limits = limits
        self.started = time.perf_counter()

    def stop_reason(self, toolbox: ToolBox) -> str | None:
        """Return why the loop must stop now, or None to continue."""
        if toolbox.solved:
            return "finished"
        if time.perf_counter() - self.started > self.limits.wall_timeout_s:
            return "timeout"
        if toolbox.patch_attempts >= self.limits.max_patch_attempts:
            return "retries_exhausted"
        if toolbox.invalid_calls >= self.limits.max_invalid_calls:
            return "invalid_call_limit"
        if len(toolbox.events) >= self.limits.max_steps:
            return "step_limit"
        return None


@dataclass
class AgentOutcome:
    stop_reason: str  # finished | retries_exhausted | invalid_call_limit | step_limit | timeout
    message: str = ""
    input_tokens: int = 0
    output_tokens: int = 0


class Agent:
    name = "agent"
    simulated = False

    def solve(self, scenario: Scenario, toolbox: ToolBox, budget: Budget, initial: TestOutcome) -> AgentOutcome:
        raise NotImplementedError


def build_initial_prompt(scenario: Scenario, toolbox: ToolBox, prefetch: bool) -> str:
    parts = [
        f"Problem: {scenario.description}",
        "Files:\n" + "\n".join(toolbox.sandbox.list_files()),
        f"Initial test run ({toolbox.last_outcome.summary() if toolbox.last_outcome else 'not run'}):",
    ]
    parts.append("\n".join(format_report(r) for r in toolbox.last_reports) or "(no structured errors)")
    if prefetch:
        parts.append("Retrieved source context:\n" + toolbox.call("search_code", {}).output)
    return "\n\n".join(parts)


class LLMAgent(Agent):
    """Tool-using loop on top of any :class:`ChatClient`."""

    def __init__(self, client: ChatClient, name: str = "llm", prefetch_context: bool = True):
        self.client = client
        self.name = name
        self.prefetch_context = prefetch_context

    def solve(self, scenario: Scenario, toolbox: ToolBox, budget: Budget, initial: TestOutcome) -> AgentOutcome:
        messages: list[dict[str, Any]] = [
            {"role": "user", "content": build_initial_prompt(scenario, toolbox, self.prefetch_context)}
        ]
        in_tokens = out_tokens = 0
        last_text = ""
        while True:
            reason = budget.stop_reason(toolbox)
            if reason:
                return AgentOutcome(reason, last_text, in_tokens, out_tokens)
            turn = self.client.complete(SYSTEM_PROMPT, messages, TOOL_SPECS)
            in_tokens += turn.input_tokens
            out_tokens += turn.output_tokens
            last_text = turn.text or last_text
            messages.append({"role": "assistant", "content": turn.blocks})
            if not turn.tool_calls:
                return AgentOutcome("finished", last_text, in_tokens, out_tokens)
            results = []
            for call in turn.tool_calls:
                if budget.stop_reason(toolbox):
                    content, is_error = "ERROR: budget exhausted", True
                else:
                    result = toolbox.call(call.name, call.args)
                    content, is_error = result.output, not result.ok
                results.append(
                    {"type": "tool_result", "tool_use_id": call.id, "content": content, "is_error": is_error}
                )
            messages.append({"role": "user", "content": results})


def classify_outcome(fixed: bool, reason: str, patch_attempts: int) -> str:
    if fixed:
        return "fixed"
    if reason in ("retries_exhausted", "invalid_call_limit", "step_limit", "timeout", "agent_error"):
        return reason
    return "no_patch" if patch_attempts == 0 else "retries_exhausted"


def debug_scenario(
    scenario: Scenario,
    agent: Agent,
    limits: Limits | None = None,
    repeat: int = 0,
    run_id: str | None = None,
    include_events: bool = True,
) -> ExecutionRecord:
    """Run one agent on one scenario and return the execution record.

    The final verdict comes from re-running the original tests in a clean state,
    not from the agent's own claim.
    """
    limits = limits or Limits()
    started = time.perf_counter()
    error: str | None = None
    message = ""
    in_tokens = out_tokens = 0
    with Sandbox(scenario, limits.test_timeout_s) as sandbox:
        toolbox = ToolBox(sandbox, limits.max_patch_attempts)
        initial = toolbox._run()
        initial_error = (
            toolbox.last_reports[0].signature() if toolbox.last_reports else "no structured error"
        )
        reason = "finished"
        try:
            outcome = agent.solve(scenario, toolbox, Budget(limits), initial)
            reason, message = outcome.stop_reason, outcome.message
            in_tokens, out_tokens = outcome.input_tokens, outcome.output_tokens
        except Exception as exc:  # noqa: BLE001 - an agent crash is a recorded result
            reason, error = "agent_error", f"{type(exc).__name__}: {exc}"
        sandbox.restore_tests()
        final = sandbox.run_tests()
        fixed = final.all_passed and final.total == scenario.expected_tests
        outcome_name = classify_outcome(fixed, reason, toolbox.patch_attempts)
        events = toolbox.events
        return ExecutionRecord(
            run_id=run_id or uuid.uuid4().hex[:12],
            scenario_id=scenario.scenario_id,
            agent=agent.name,
            repeat=repeat,
            simulated=agent.simulated,
            outcome=outcome_name,
            fixed=fixed,
            initial_error=initial_error,
            steps=len(events),
            tool_calls=len(events),
            valid_calls=toolbox.valid_calls,
            invalid_calls=toolbox.invalid_calls,
            patch_attempts=toolbox.patch_attempts,
            rejected_patches=toolbox.rejected_patches,
            duration_s=round(time.perf_counter() - started, 3),
            input_tokens=in_tokens,
            output_tokens=out_tokens,
            message=message[:500],
            error=error,
            events=[e.to_dict() for e in events] if include_events else [],
        )
