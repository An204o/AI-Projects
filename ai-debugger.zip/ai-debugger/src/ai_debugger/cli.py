"""Command line: ai-debugger {list,validate,run,llm-run,report,serve}."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .agent import Limits
from .analysis import render_report
from .logging_utils import read_records
from .scenarios import build_scenarios, validate_all
from .service import DebuggerService
from .simulated import PROFILES


def _limits(args: argparse.Namespace) -> Limits:
    return Limits(max_steps=args.max_steps, max_patch_attempts=args.max_patches,
                  max_invalid_calls=args.max_invalid)


def cmd_list(args: argparse.Namespace) -> int:
    for s in build_scenarios():
        print(f"{s.scenario_id:28} {s.exception:20} {s.description}")
    print(f"\n{len(build_scenarios())} scenarios")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    bad = validate_all()
    for sid, problems in bad.items():
        print(f"FAIL {sid}: {'; '.join(problems)}")
    print(f"{len(build_scenarios()) - len(bad)}/{len(build_scenarios())} scenarios valid")
    return 1 if bad else 0


def cmd_run(args: argparse.Namespace) -> int:
    service = DebuggerService(Path(args.out) / "executions.jsonl")
    records = service.run_batch(args.profile, args.repeats, args.scenario or None, _limits(args))
    fixed = sum(r.fixed for r in records)
    print(f"[SIMULATED] {len(records)} runs, {fixed} fixed -> {service.log.path}")
    return 0


def cmd_llm_run(args: argparse.Namespace) -> int:
    from .agent import LLMAgent
    from .llm import AnthropicChatClient

    if "YOUR_MODEL" in args.model:
        print("error: pass a real --model id", file=sys.stderr)
        return 2
    client = AnthropicChatClient(model=args.model)  # needs `pip install anthropic` + ANTHROPIC_API_KEY
    service = DebuggerService(
        Path(args.out) / "executions.jsonl",
        agent_factory=lambda profile, repeat: LLMAgent(client, name=args.model),
    )
    records = service.run_batch("llm", args.repeats, args.scenario or None, _limits(args))
    print(f"{len(records)} runs, {sum(r.fixed for r in records)} fixed -> {service.log.path}")
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    text = render_report(read_records(args.log))
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(f"wrote {args.output}")
    else:
        print(text)
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError:
        print("error: pip install fastapi uvicorn", file=sys.stderr)
        return 2
    uvicorn.run("ai_debugger.api:app", host=args.host, port=args.port)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ai-debugger", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    def limits(p: argparse.ArgumentParser) -> None:
        p.add_argument("--max-steps", type=int, default=20)
        p.add_argument("--max-patches", type=int, default=3)
        p.add_argument("--max-invalid", type=int, default=5)
        p.add_argument("--scenario", action="append", help="scenario id (repeatable); default all")
        p.add_argument("--repeats", type=int, default=1)
        p.add_argument("--out", default="runs")

    sub.add_parser("list", help="list scenarios").set_defaults(func=cmd_list)
    sub.add_parser("validate", help="check every scenario's fixes").set_defaults(func=cmd_validate)
    run = sub.add_parser("run", help="run SIMULATED agents (pipeline test, not a model result)")
    run.add_argument("--profile", choices=sorted(PROFILES), default="strong")
    limits(run)
    run.set_defaults(func=cmd_run)
    llm = sub.add_parser("llm-run", help="run a real model via the Anthropic API")
    llm.add_argument("--model", required=True)
    limits(llm)
    llm.set_defaults(func=cmd_llm_run)
    rep = sub.add_parser("report", help="analyse an execution log")
    rep.add_argument("log")
    rep.add_argument("--output")
    rep.set_defaults(func=cmd_report)
    srv = sub.add_parser("serve", help="start the FastAPI service")
    srv.add_argument("--host", default="127.0.0.1")
    srv.add_argument("--port", type=int, default=8000)
    srv.set_defaults(func=cmd_serve)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
