"""Framework-independent service layer (the FastAPI app is a thin wrapper).

Only built-in scenario ids can be run, so the API never executes
caller-supplied code.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .agent import Agent, Limits, debug_scenario
from .analysis import analyze
from .error_parser import parse_errors
from .logging_utils import ExecutionLog, read_records
from .models import ExecutionRecord
from .retrieval import CodeIndex
from .scenarios import build_scenarios, get_scenario
from .simulated import PROFILES, SimulatedAgent


class DebuggerService:
    def __init__(self, log_path: str | Path = "runs/executions.jsonl", agent_factory=None):
        self.log = ExecutionLog(log_path)
        self._agent_factory = agent_factory or self._simulated_factory

    @staticmethod
    def _simulated_factory(profile: str, repeat: int) -> Agent:
        return SimulatedAgent(profile=profile, repeat=repeat)

    # -- queries -----------------------------------------------------------
    def list_scenarios(self) -> list[dict[str, Any]]:
        return [
            {"scenario_id": s.scenario_id, "exception": s.exception, "description": s.description,
             "tests": s.expected_tests}
            for s in build_scenarios()
        ]

    def get_scenario(self, scenario_id: str) -> dict[str, Any]:
        s = get_scenario(scenario_id)  # KeyError for unknown ids
        return {"scenario_id": s.scenario_id, "exception": s.exception, "description": s.description,
                "files": s.files, "tests": s.tests}

    def parse_error(self, text: str) -> list[dict[str, Any]]:
        return [r.to_dict() for r in parse_errors(text)]

    def search(self, scenario_id: str, query: str = "", top_k: int = 3) -> list[dict[str, Any]]:
        s = get_scenario(scenario_id)
        index = CodeIndex({p: c for p, c in s.files.items()})
        return [
            {"path": x.path, "name": x.name, "start": x.start, "end": x.end, "score": round(x.score, 3),
             "reasons": x.reasons}
            for x in index.search([], query, top_k)
        ]

    # -- runs --------------------------------------------------------------
    def run(self, scenario_id: str, profile: str = "strong", repeat: int = 0,
            limits: Limits | None = None) -> ExecutionRecord:
        if profile not in PROFILES and self._agent_factory == self._simulated_factory:
            raise ValueError(f"unknown profile {profile!r}; choose from {sorted(PROFILES)}")
        scenario = get_scenario(scenario_id)
        record = debug_scenario(scenario, self._agent_factory(profile, repeat), limits, repeat)
        self.log.append(record)
        return record

    def run_batch(self, profile: str = "strong", repeats: int = 1, scenario_ids: list[str] | None = None,
                  limits: Limits | None = None) -> list[ExecutionRecord]:
        ids = scenario_ids or [s.scenario_id for s in build_scenarios()]
        return [self.run(sid, profile, repeat, limits) for repeat in range(repeats) for sid in ids]

    def records(self) -> list[ExecutionRecord]:
        return read_records(self.log.path) if self.log.path.exists() else []

    def analysis(self) -> dict[str, Any]:
        return analyze(self.records())
