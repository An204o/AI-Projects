"""FastAPI application (requires ``pip install fastapi uvicorn``).

Run:  uvicorn ai_debugger.api:app --reload
All logic lives in :class:`ai_debugger.service.DebuggerService`; this module
only maps HTTP to it. Runs use the built-in scripted agents unless you pass a
service with a real-LLM ``agent_factory`` to :func:`create_app`.
"""

from __future__ import annotations

import os
from typing import Any

from .service import DebuggerService


def create_app(service: DebuggerService | None = None):
    try:
        from fastapi import FastAPI, HTTPException
        from pydantic import BaseModel, Field
    except ImportError as exc:  # pragma: no cover - depends on environment
        raise RuntimeError("install the API extras first: pip install fastapi uvicorn") from exc

    svc = service or DebuggerService(os.environ.get("DEBUGGER_LOG", "runs/executions.jsonl"))
    app = FastAPI(title="Tool-Using AI Software Debugger", version="0.1.0")

    class RunRequest(BaseModel):
        scenario_id: str
        profile: str = "strong"
        repeat: int = Field(0, ge=0)

    class ParseRequest(BaseModel):
        text: str = Field(..., max_length=200_000)

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/scenarios")
    def scenarios() -> list[dict[str, Any]]:
        return svc.list_scenarios()

    @app.get("/scenarios/{scenario_id}")
    def scenario(scenario_id: str) -> dict[str, Any]:
        try:
            return svc.get_scenario(scenario_id)
        except KeyError:
            raise HTTPException(status_code=404, detail="unknown scenario") from None

    @app.post("/parse-error")
    def parse_error(request: ParseRequest) -> list[dict[str, Any]]:
        return svc.parse_error(request.text)

    @app.post("/runs")
    def run(request: RunRequest) -> dict[str, Any]:
        try:
            return svc.run(request.scenario_id, request.profile, request.repeat).to_dict()
        except KeyError:
            raise HTTPException(status_code=404, detail="unknown scenario") from None
        except ValueError as exc:
            raise HTTPException(status_code=422, detail=str(exc)) from None

    @app.get("/analysis")
    def analysis() -> dict[str, Any]:
        return svc.analysis()

    return app


try:  # expose ``app`` for uvicorn when FastAPI is installed
    app = create_app()
except RuntimeError:  # pragma: no cover
    app = None
