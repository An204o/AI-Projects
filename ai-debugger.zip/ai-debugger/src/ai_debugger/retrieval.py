"""Retrieve the source code most relevant to an error.

Files are split into function-level chunks with ``ast``. Each chunk is scored
with three signals: whether a traceback frame points inside it, a BM25 match
against the error text, and a fuzzy match for identifiers that look like typos
of names quoted in the error message.
"""

from __future__ import annotations

import ast
import difflib
import math
import re
from collections import Counter
from dataclasses import dataclass, field

from .models import ErrorReport

STOPWORDS = {
    "the", "and", "for", "not", "def", "return", "self", "none", "true", "false", "with", "from",
    "import", "this", "that", "are", "was", "has", "have", "can", "error", "line", "in", "of", "to",
    "is", "it", "an", "as", "or", "if", "else", "be",
}
_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_QUOTED = re.compile(r"'([A-Za-z_][A-Za-z0-9_]*)'")


@dataclass(frozen=True)
class Chunk:
    path: str
    name: str
    start: int
    end: int
    source: str


@dataclass
class Snippet:
    path: str
    name: str
    start: int
    end: int
    score: float
    reasons: list[str] = field(default_factory=list)
    source: str = ""

    def render(self) -> str:
        header = f"# {self.path}:{self.start}-{self.end} ({self.name}) — {'; '.join(self.reasons)}"
        body = "\n".join(
            f"{number:4d}  {text}"
            for number, text in enumerate(self.source.splitlines(), start=self.start)
        )
        return f"{header}\n{body}"


def tokenize(text: str) -> list[str]:
    """Lower-cased identifier tokens, split on snake_case and camelCase."""
    tokens: list[str] = []
    for ident in _IDENT.findall(text):
        spaced = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", ident).replace("_", " ")
        parts = [p.lower() for p in spaced.split()]
        full = ident.lower()
        for token in {full, *parts}:
            if len(token) > 1 and token not in STOPWORDS:
                tokens.append(token)
    return tokens


def build_chunks(files: dict[str, str]) -> list[Chunk]:
    """Split Python files into function, method and module-header chunks."""
    chunks: list[Chunk] = []
    for path, text in sorted(files.items()):
        if not path.endswith(".py"):
            continue
        lines = text.splitlines()
        try:
            tree = ast.parse(text)
        except SyntaxError:
            chunks.append(Chunk(path, "<file>", 1, max(1, len(lines)), text))
            continue

        def visit(nodes, prefix=""):
            for node in nodes:
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    start = min([node.lineno] + [d.lineno for d in node.decorator_list])
                    end = node.end_lineno or node.lineno
                    chunks.append(
                        Chunk(path, prefix + node.name, start, end, "\n".join(lines[start - 1:end]))
                    )
                elif isinstance(node, ast.ClassDef):
                    visit(node.body, prefix + node.name + ".")

        visit(tree.body)
        first_def = min(
            (n.lineno for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))),
            default=len(lines) + 1,
        )
        header = "\n".join(lines[: first_def - 1]).strip()
        if header:
            chunks.append(Chunk(path, "<module>", 1, first_def - 1, "\n".join(lines[: first_def - 1])))
    return chunks


class CodeIndex:
    """BM25 index over chunks with traceback and typo boosts."""

    K1, B = 1.5, 0.75

    def __init__(self, files: dict[str, str]):
        self.chunks = build_chunks(files)
        self._tokens = [tokenize(c.source + " " + c.name) for c in self.chunks]
        self._lengths = [len(t) for t in self._tokens]
        self._avg = (sum(self._lengths) / len(self._lengths)) if self._lengths else 1.0
        document_frequency: Counter[str] = Counter()
        for tokens in self._tokens:
            document_frequency.update(set(tokens))
        n = len(self.chunks)
        self._idf = {
            term: math.log(1 + (n - df + 0.5) / (df + 0.5)) for term, df in document_frequency.items()
        }
        self._term_counts = [Counter(t) for t in self._tokens]

    def _bm25(self, index: int, query_terms: list[str]) -> float:
        counts, length = self._term_counts[index], self._lengths[index]
        score = 0.0
        for term in set(query_terms):
            tf = counts.get(term, 0)
            if tf:
                score += self._idf[term] * tf * (self.K1 + 1) / (
                    tf + self.K1 * (1 - self.B + self.B * length / self._avg)
                )
        return score

    def search(
        self, reports: list[ErrorReport], extra_query: str = "", top_k: int = 3
    ) -> list[Snippet]:
        """Rank chunks for the given errors (and optional free-text query)."""
        query_text = " ".join(
            [extra_query]
            + [f"{r.exception_type} {r.message} {r.test_name or ''}" for r in reports]
            + [f.function for r in reports for f in r.frames]
        )
        query_terms = tokenize(query_text)
        quoted = [q for r in reports for q in _QUOTED.findall(r.message)]
        ranked: list[Snippet] = []
        for i, chunk in enumerate(self.chunks):
            reasons: list[str] = []
            score = self._bm25(i, query_terms)
            if score > 0:
                reasons.append("keyword match")
            for report in reports:
                for depth, frame in enumerate(reversed(report.frames)):
                    if frame.path == chunk.path and chunk.start <= frame.line <= chunk.end:
                        score += 10.0 if depth == 0 else 6.0
                        reasons.append("traceback frame" + (" (innermost)" if depth == 0 else ""))
                        break
            chunk_tokens = set(self._tokens[i])
            for name in quoted:
                close = [
                    t for t in chunk_tokens
                    if t != name.lower()
                    and difflib.SequenceMatcher(None, t, name.lower()).ratio() >= 0.8
                ]
                if close:
                    score += 3.0
                    reasons.append(f"similar identifier {close[0]!r} for {name!r}")
            if score > 0:
                ranked.append(
                    Snippet(chunk.path, chunk.name, chunk.start, chunk.end, score,
                            list(dict.fromkeys(reasons)), chunk.source)
                )
        ranked.sort(key=lambda s: (-s.score, s.path, s.start))
        return ranked[:top_k]
