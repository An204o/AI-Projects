"""Atomic, validated patching with rollback."""

from __future__ import annotations

import ast
from dataclasses import dataclass

from .models import Edit
from .sandbox import Sandbox, ToolError


class PatchError(Exception):
    """The patch was rejected; nothing was written."""


@dataclass
class AppliedPatch:
    """Original contents of every file the patch touched, for rollback."""

    snapshot: dict[str, str]

    @property
    def paths(self) -> list[str]:
        return sorted(self.snapshot)


def apply_edits(sandbox: Sandbox, edits: list[Edit]) -> AppliedPatch:
    """Apply all edits or none.

    Each edit's ``old`` text must occur exactly once in the file *as it stands
    after earlier edits in the same patch*, must differ from ``new``, and the
    target must not be protected. Python files must still parse afterwards.
    """
    if not edits:
        raise PatchError("patch contains no edits")
    originals: dict[str, str] = {}
    updated: dict[str, str] = {}
    for number, edit in enumerate(edits, start=1):
        label = f"edit {number} ({edit.path})"
        if not edit.old:
            raise PatchError(f"{label}: `old` must not be empty")
        if edit.old == edit.new:
            raise PatchError(f"{label}: `old` and `new` are identical, nothing would change")
        try:
            target = sandbox.resolve(edit.path)
            relative = sandbox.relative(target)
            if sandbox.is_protected(relative):
                raise PatchError(f"{label}: file is read-only (tests and configuration)")
            current = updated.get(relative)
            if current is None:
                current = sandbox.read(relative)
                originals[relative] = current
        except ToolError as exc:
            raise PatchError(f"{label}: {exc}") from exc
        count = current.count(edit.old)
        if count == 0:
            raise PatchError(f"{label}: `old` text not found; re-read the file and copy it exactly")
        if count > 1:
            raise PatchError(f"{label}: `old` text matches {count} places; include more context")
        updated[relative] = current.replace(edit.old, edit.new, 1)
    for relative, text in updated.items():
        if relative.endswith(".py"):
            try:
                ast.parse(text)
            except SyntaxError as exc:
                raise PatchError(
                    f"{relative}: patch would cause a syntax error at line {exc.lineno}: {exc.msg}"
                ) from exc
    for relative, text in updated.items():
        sandbox.write(relative, text)
    return AppliedPatch(snapshot=originals)


def revert(sandbox: Sandbox, patch: AppliedPatch) -> list[str]:
    """Restore the files a patch changed."""
    for relative, text in patch.snapshot.items():
        sandbox.write(relative, text)
    return patch.paths
