"""Append-only JSONL execution log (one :class:`ExecutionRecord` per line)."""

from __future__ import annotations

import json
import threading
from pathlib import Path

from .models import ExecutionRecord


class ExecutionLog:
    """Thread-safe JSONL writer. Each record is flushed as soon as it is appended."""

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def append(self, record: ExecutionRecord) -> None:
        line = json.dumps(record.to_dict(), sort_keys=True)
        with self._lock, self.path.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
            handle.flush()

    def __len__(self) -> int:
        return len(read_records(self.path)) if self.path.exists() else 0


def read_records(path: str | Path) -> list[ExecutionRecord]:
    """Load records, raising ``ValueError`` with the line number on corrupt input."""
    records: list[ExecutionRecord] = []
    with Path(path).open(encoding="utf-8") as handle:
        for number, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                records.append(ExecutionRecord.from_dict(json.loads(line)))
            except (json.JSONDecodeError, TypeError) as exc:
                raise ValueError(f"{path}:{number}: invalid execution record ({exc})") from exc
    return records
