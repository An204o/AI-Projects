"""Scripted agents for exercising the pipeline offline.

SIMULATION ONLY. These agents read the scenario's reference fix, so their
results say nothing about any real model. They exist to test the tool layer,
budgets, logging and analysis, and every record they produce is flagged
``simulated=True``.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

from .agent import Agent, AgentOutcome, Budget
from .models import Edit, Scenario
from .sandbox import TestOutcome
from .tools import ToolBox

BEHAVIOURS = ("first_try", "after_retry", "wrong_patches", "no_patch", "bad_calls", "dithering")

PROFILES: dict[str, dict[str, float]] = {
    "strong": dict(first_try=0.78, after_retry=0.12, wrong_patches=0.04, no_patch=0.02, bad_calls=0.02, dithering=0.02),
    "weak": dict(first_try=0.40, after_retry=0.20, wrong_patches=0.17, no_patch=0.08, bad_calls=0.08, dithering=0.07),
}


def _edits(edits: tuple[Edit, ...]) -> dict:
    return {"edits": [e.to_dict() for e in edits], "rationale": "simulated"}


@dataclass
class SimulatedAgent(Agent):
    profile: str = "strong"
    seed: int = 0
    repeat: int = 0
    simulated = True

    def __post_init__(self) -> None:
        if self.profile not in PROFILES:
            raise ValueError(f"unknown profile {self.profile!r}; choose from {sorted(PROFILES)}")
        self.name = f"sim-{self.profile}"

    def solve(self, scenario: Scenario, toolbox: ToolBox, budget: Budget, initial: TestOutcome) -> AgentOutcome:
        rng = random.Random(f"{self.seed}|{self.profile}|{self.repeat}|{scenario.scenario_id}")
        weights = PROFILES[self.profile]
        behaviour = rng.choices(list(weights), weights=list(weights.values()))[0]
        target = scenario.target_files[0]

        def call(name: str, args: object) -> None:
            if budget.stop_reason(toolbox) is None:
                toolbox.call(name, args)

        def done() -> AgentOutcome:
            return AgentOutcome(budget.stop_reason(toolbox) or "finished", f"simulated: {behaviour}")

        if behaviour == "no_patch":
            call("list_files", {})
            call("read_file", {"path": target})
            return done()
        if behaviour == "bad_calls":
            call("apply_diff", {"path": target})
            call("read_file", {"path": "missing/file.py"})
            call("read_file", {"path": 7})
            call("propose_patch", {"edits": []})
            call("run_tests", {"verbose": True})
            return done()
        if behaviour == "dithering":
            while budget.stop_reason(toolbox) is None:
                toolbox.call("read_file", {"path": target})
            return done()

        call("run_tests", {})
        call("search_code", {})
        call("read_file", {"path": target})
        if behaviour == "first_try":
            call("propose_patch", _edits(scenario.edits))
        elif behaviour == "after_retry":
            call("propose_patch", _edits(scenario.wrong_edits))
            call("propose_patch", _edits(scenario.edits))
        else:  # wrong_patches: spends the whole patch budget on a wrong fix
            for _ in range(toolbox.max_patch_attempts):
                call("propose_patch", _edits(scenario.wrong_edits))
        return done()
