"""ai_debugger: a tool-using LLM agent that diagnoses and fixes failing Python tests."""

__version__ = "0.1.0"
