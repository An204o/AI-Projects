"""Core data structures."""

from __future__ import annotations

import ast
from dataclasses import asdict, dataclass, field
from typing import Any


def count_tests(tests: dict[str, str]) -> int:
    total = 0
    for source in tests.values():
        for node in ast.parse(source).body:
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                total += 1
    return total


@dataclass(frozen=True)
class Edit:
    """One exact-text replacement inside one file."""

    path: str
    old: str
    new: str

    def to_dict(self) -> dict[str, str]:
        return {"path": self.path, "old": self.old, "new": self.new}


@dataclass(frozen=True)
class Scenario:
    """A failing mini-project the agent must debug.

    ``edits`` is the reference fix and ``wrong_edits`` a plausible but
    incorrect one. Both are used to validate the scenario and by the offline
    simulation only; a real model never sees them.
    """

    scenario_id: str
    exception: str  # exception type the failing test run is expected to show
    description: str
    files: dict[str, str]
    tests: dict[str, str]
    edits: tuple[Edit, ...]
    wrong_edits: tuple[Edit, ...]

    @property
    def expected_tests(self) -> int:
        return count_tests(self.tests)

    @property
    def target_files(self) -> tuple[str, ...]:
        return tuple(sorted({e.path for e in self.edits}))

    def to_dict(self) -> dict[str, Any]:
        return {
            "scenario_id": self.scenario_id,
            "exception": self.exception,
            "description": self.description,
            "files": self.files,
            "tests": self.tests,
            "edits": [e.to_dict() for e in self.edits],
            "wrong_edits": [e.to_dict() for e in self.wrong_edits],
        }


@dataclass(frozen=True)
class Frame:
    path: str
    line: int
    function: str


@dataclass
class ErrorReport:
    """One failure parsed from pytest (or plain Python traceback) output."""

    test_name: str | None
    exception_type: str
    message: str
    frames: list[Frame] = field(default_factory=list)  # outermost first

    @property
    def innermost(self) -> Frame | None:
        return self.frames[-1] if self.frames else None

    def signature(self) -> str:
        """Stable key for grouping recurring failures (numbers and paths normalised)."""
        import re

        msg = re.sub(r"/\S+", "<path>", self.message)
        msg = re.sub(r"0x[0-9a-fA-F]+", "0xN", msg)
        msg = re.sub(r"\d+", "N", msg)
        return f"{self.exception_type}: {msg[:120]}".strip()

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["signature"] = self.signature()
        return data


@dataclass
class ToolEvent:
    """One tool call made by an agent."""

    step: int
    tool: str
    args: dict[str, Any]
    ok: bool
    error: str | None
    preview: str
    duration_s: float
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# Why a run ended without a validated fix.
OUTCOMES = (
    "fixed",
    "retries_exhausted",   # patch budget used up, none validated
    "no_patch",            # agent stopped without ever proposing a patch
    "step_limit",
    "invalid_call_limit",  # too many malformed / failed tool calls
    "timeout",
    "agent_error",
)


@dataclass
class ExecutionRecord:
    """One complete debugging run: the unit that gets logged and analysed."""

    run_id: str
    scenario_id: str
    agent: str
    repeat: int
    simulated: bool
    outcome: str
    fixed: bool
    initial_error: str
    steps: int
    tool_calls: int
    valid_calls: int
    invalid_calls: int
    patch_attempts: int
    rejected_patches: int
    duration_s: float
    input_tokens: int = 0
    output_tokens: int = 0
    message: str = ""
    error: str | None = None
    events: list[dict[str, Any]] = field(default_factory=list)

    @property
    def tool_call_accuracy(self) -> float:
        return self.valid_calls / self.tool_calls if self.tool_calls else 0.0

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["tool_call_accuracy"] = round(self.tool_call_accuracy, 4)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ExecutionRecord":
        names = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in names})
