"""Aggregate execution logs: fix rates, tool accuracy and recurring failures."""

from __future__ import annotations

import math
import statistics
from collections import Counter, defaultdict
from typing import Any

from .models import ExecutionRecord


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n <= 0:
        return (0.0, 0.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def exception_type(record: ExecutionRecord) -> str:
    return record.initial_error.split(":", 1)[0].strip() or "unknown"


def summarize(records: list[ExecutionRecord]) -> dict[str, Any]:
    n = len(records)
    if n == 0:
        return {"runs": 0}
    fixed = sum(r.fixed for r in records)
    low, high = wilson_interval(fixed, n)
    calls = sum(r.tool_calls for r in records)
    valid = sum(r.valid_calls for r in records)
    first_try = sum(1 for r in records if r.fixed and r.patch_attempts == 1)
    return {
        "runs": n,
        "scenarios": len({r.scenario_id for r in records}),
        "fixed": fixed,
        "fix_rate": fixed / n,
        "fix_rate_ci95": [round(low, 4), round(high, 4)],
        "first_attempt_fix_rate": first_try / n,
        "tool_call_accuracy": valid / calls if calls else 0.0,
        "mean_steps": statistics.fmean(r.steps for r in records),
        "mean_patch_attempts": statistics.fmean(r.patch_attempts for r in records),
        "median_duration_s": statistics.median(r.duration_s for r in records),
        "outcomes": dict(Counter(r.outcome for r in records).most_common()),
        "simulated_runs": sum(r.simulated for r in records),
    }


def group_summary(records: list[ExecutionRecord], key) -> dict[str, dict[str, Any]]:
    groups: dict[str, list[ExecutionRecord]] = defaultdict(list)
    for record in records:
        groups[key(record)].append(record)
    return {name: summarize(items) for name, items in sorted(groups.items())}


def recurring_failures(records: list[ExecutionRecord], min_count: int = 2) -> list[dict[str, Any]]:
    """Group unfixed runs by error signature; the most frequent come first."""
    failed: dict[str, list[ExecutionRecord]] = defaultdict(list)
    for record in records:
        if not record.fixed:
            failed[record.initial_error].append(record)
    rows = [
        {
            "signature": signature,
            "count": len(items),
            "scenarios": sorted({r.scenario_id for r in items}),
            "outcomes": dict(Counter(r.outcome for r in items)),
        }
        for signature, items in failed.items()
        if len(items) >= min_count
    ]
    return sorted(rows, key=lambda row: (-row["count"], row["signature"]))


def analyze(records: list[ExecutionRecord]) -> dict[str, Any]:
    return {
        "overall": summarize(records),
        "by_agent": group_summary(records, lambda r: r.agent),
        "by_exception": group_summary(records, exception_type),
        "recurring_failures": recurring_failures(records),
    }


def _pct(value: float) -> str:
    return f"{100 * value:.1f}%"


def render_report(records: list[ExecutionRecord]) -> str:
    data = analyze(records)
    overall = data["overall"]
    if not overall["runs"]:
        return "# Debugger execution report\n\nNo records.\n"
    lines = ["# Debugger execution report", ""]
    if overall["simulated_runs"]:
        lines += [
            f"> **{overall['simulated_runs']} of {overall['runs']} runs are SIMULATED** (scripted agents "
            "that read the reference fix). They validate the pipeline, not any model's ability.",
            "",
        ]
    low, high = overall["fix_rate_ci95"]
    lines += [
        f"- Runs: **{overall['runs']}** over {overall['scenarios']} scenarios",
        f"- Fix rate: **{_pct(overall['fix_rate'])}** (95% CI {_pct(low)}–{_pct(high)})",
        f"- Fixed on first patch: {_pct(overall['first_attempt_fix_rate'])}",
        f"- Tool-call accuracy: {_pct(overall['tool_call_accuracy'])}",
        f"- Mean steps: {overall['mean_steps']:.1f}; mean patch attempts: {overall['mean_patch_attempts']:.2f}",
        f"- Outcomes: {overall['outcomes']}",
        "",
        "## By agent",
        "",
        "| Agent | Runs | Fix rate | Tool accuracy | Mean steps |",
        "|---|---|---|---|---|",
    ]
    for name, s in data["by_agent"].items():
        lines.append(
            f"| {name} | {s['runs']} | {_pct(s['fix_rate'])} | {_pct(s['tool_call_accuracy'])} | {s['mean_steps']:.1f} |"
        )
    lines += ["", "## By exception type", "", "| Exception | Runs | Fix rate |", "|---|---|---|"]
    for name, s in data["by_exception"].items():
        lines.append(f"| {name} | {s['runs']} | {_pct(s['fix_rate'])} |")
    lines += ["", "## Recurring failures", ""]
    if data["recurring_failures"]:
        for row in data["recurring_failures"][:10]:
            lines.append(f"- `{row['signature']}` — {row['count']} runs, outcomes {row['outcomes']}")
    else:
        lines.append("None.")
    return "\n".join(lines) + "\n"
