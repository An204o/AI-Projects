"""Built-in debugging scenarios: 20 bug patterns x 3 variants = 60 scenarios.

Every scenario is a tiny package (``pkg/``) with one failing test file. Each
carries a reference fix and a plausible-but-wrong fix; :func:`validate_scenario`
proves that the bug reproduces with the expected exception, the reference fix
makes every test pass, and the wrong fix does not.

The set is template-generated: variants of one pattern differ in identifiers
and constants, not in the underlying bug. Treat it as a regression/smoke
benchmark, not a measure of general debugging ability.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from functools import lru_cache

from .error_parser import parse_errors
from .models import Edit, Scenario
from .patcher import apply_edits
from .sandbox import Sandbox

DEFAULT_UTIL = '''"""Shared helpers."""


def noop(value):
    return value
'''


@dataclass(frozen=True)
class Template:
    template_id: str
    exception: str
    description: str
    source: str
    test: str
    edit_old: str
    edit_new: str
    wrong_old: str
    wrong_new: str
    variants: tuple[dict[str, str], ...]
    util: str = DEFAULT_UTIL


def _fill(text: str, values: dict[str, str]) -> str:
    out = text
    for key, value in values.items():
        out = out.replace(f"@@{key}@@", value)
    leftover = re.findall(r"@@\w+@@", out)
    if leftover:
        raise ValueError(f"unfilled placeholders {leftover} in template text")
    return out


def _v(**kwargs: str) -> dict[str, str]:
    return dict(kwargs)


TEMPLATES: tuple[Template, ...] = (
    Template(
        "name_typo", "NameError",
        "@@F@@(values) returns the sum of the numbers in values.",
        "def @@F@@(values):\n    @@V@@ = 0\n    for item in values:\n        @@V@@ += item\n    return @@T@@\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_sums_numbers():\n    assert @@F@@([1, 2, 3]) == 6\n\n\n"
        "def test_empty_is_zero():\n    assert @@F@@([]) == 0\n",
        "    return @@T@@", "    return @@V@@", "    return @@T@@", "    return 0",
        (
            _v(M="summing", F="sum_values", V="total", T="totl"),
            _v(M="tally", F="tally_scores", V="running", T="runing"),
            _v(M="accum", F="add_up", V="acc", T="accc"),
        ),
    ),
    Template(
        "attr_typo", "AttributeError",
        "@@C@@ stores items in @@A@@; add() appends and count() returns how many were added.",
        "class @@C@@:\n    def __init__(self):\n        self.@@A@@ = []\n\n    def add(self, item):\n"
        "        self.@@B@@.append(item)\n\n    def count(self):\n        return len(self.@@A@@)\n",
        "from pkg.@@M@@ import @@C@@\n\n\ndef test_add_and_count():\n    c = @@C@@()\n    c.add(\"x\")\n"
        "    c.add(\"y\")\n    assert c.count() == 2\n\n\ndef test_starts_empty():\n    assert @@C@@().count() == 0\n",
        "        self.@@B@@.append(item)", "        self.@@A@@.append(item)",
        "        self.@@B@@.append(item)", "        self.@@B@@ = [item]",
        (
            _v(M="cart", C="Cart", A="items", B="itmes"),
            _v(M="playlist", C="Playlist", A="songs", B="sogns"),
            _v(M="inbox", C="Inbox", A="messages", B="mesages"),
        ),
    ),
    Template(
        "key_error", "KeyError",
        "@@F@@() returns the configured @@K@@ value.",
        "SETTINGS = {\"@@K@@\": @@N@@, \"mode\": \"fast\"}\n\n\ndef @@F@@():\n    return SETTINGS[\"@@W@@\"]\n",
        "from pkg.@@M@@ import SETTINGS, @@F@@\n\n\ndef test_reads_setting():\n    assert @@F@@() == @@N@@\n\n\n"
        "def test_other_settings_untouched():\n    assert SETTINGS[\"mode\"] == \"fast\"\n",
        "SETTINGS[\"@@W@@\"]", "SETTINGS[\"@@K@@\"]", "SETTINGS[\"@@W@@\"]", "SETTINGS.get(\"@@W@@\")",
        (
            _v(M="retries", F="get_retries", K="max_retries", W="max_retrys", N="3"),
            _v(M="timeouts", F="get_timeout", K="timeout_s", W="timeout_sec", N="30"),
            _v(M="paging", F="get_page_size", K="page_size", W="pagesize", N="25"),
        ),
    ),
    Template(
        "index_error", "IndexError",
        "@@F@@(items) returns the last element of a non-empty list.",
        "def @@F@@(items):\n    return items[len(items)]\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_last_of_many():\n    assert @@F@@([1, 2, 3]) == 3\n\n\n"
        "def test_last_of_one():\n    assert @@F@@([\"a\"]) == \"a\"\n",
        "    return items[len(items)]", "    return items[-1]",
        "    return items[len(items)]", "    return items[len(items) - 2]",
        (
            _v(M="lastitem", F="last_item"),
            _v(M="finalentry", F="final_entry"),
            _v(M="tailvalue", F="tail_value"),
        ),
    ),
    Template(
        "zero_division", "ZeroDivisionError",
        "@@F@@(values) returns the arithmetic mean, or 0.0 for an empty list.",
        "def @@F@@(values):\n    return sum(values) / len(values)\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_mean():\n    assert @@F@@([2, 4, 6]) == 4.0\n\n\n"
        "def test_empty_is_zero():\n    assert @@F@@([]) == 0.0\n",
        "    return sum(values) / len(values)",
        "    if not values:\n        return 0.0\n    return sum(values) / len(values)",
        "    return sum(values) / len(values)",
        "    try:\n        return sum(values) / len(values)\n    except ZeroDivisionError:\n        return None",
        (
            _v(M="stats", F="mean"),
            _v(M="scores", F="average_score"),
            _v(M="latency", F="avg_latency"),
        ),
    ),
    Template(
        "type_error_concat", "TypeError",
        "@@F@@(items) returns the label '@@L@@: ' followed by the sum of items.",
        "def @@F@@(items):\n    total = sum(items)\n    return \"@@L@@: \" + total\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_label():\n    assert @@F@@([1, 2, 3]) == \"@@L@@: 6\"\n\n\n"
        "def test_label_empty():\n    assert @@F@@([]) == \"@@L@@: 0\"\n",
        "    return \"@@L@@: \" + total", "    return \"@@L@@: \" + str(total)",
        "    return \"@@L@@: \" + total", "    return \"@@L@@: \" + \"total\"",
        (
            _v(M="labels", F="describe_total", L="Total"),
            _v(M="summary", F="describe_sum", L="Sum"),
            _v(M="report", F="describe_items", L="Items"),
        ),
    ),
    Template(
        "mutable_default", "AssertionError",
        "@@F@@(@@I@@, bucket=None) appends to bucket; each call without a bucket starts fresh.",
        "def @@F@@(@@I@@, bucket=[]):\n    bucket.append(@@I@@)\n    return bucket\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_fresh_each_call():\n    assert @@F@@(\"a\") == [\"a\"]\n"
        "    assert @@F@@(\"b\") == [\"b\"]\n\n\ndef test_uses_given_bucket():\n"
        "    assert @@F@@(\"c\", [\"x\"]) == [\"x\", \"c\"]\n",
        "def @@F@@(@@I@@, bucket=[]):\n    bucket.append(@@I@@)\n    return bucket",
        "def @@F@@(@@I@@, bucket=None):\n    if bucket is None:\n        bucket = []\n    bucket.append(@@I@@)\n    return bucket",
        "bucket=[]", "bucket=list()",
        (
            _v(M="tags", F="add_tag", I="tag"),
            _v(M="events", F="record_event", I="event"),
            _v(M="entries", F="collect", I="entry"),
        ),
    ),
    Template(
        "range_off_by_one", "AssertionError",
        "@@F@@(n) returns 1 + 2 + ... + n.",
        "def @@F@@(n):\n    total = 0\n    for i in range(1, n):\n        total += i\n    return total\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_four():\n    assert @@F@@(4) == 10\n\n\n"
        "def test_one():\n    assert @@F@@(1) == 1\n",
        "range(1, n)", "range(1, n + 1)", "range(1, n)", "range(0, n)",
        (
            _v(M="series", F="sum_to_n"),
            _v(M="triangle", F="triangle_number"),
            _v(M="firstn", F="add_first"),
        ),
    ),
    Template(
        "wrong_operator", "AssertionError",
        "@@F@@(price, rate) returns the price after subtracting a fractional discount rate.",
        "def @@F@@(price, rate):\n    return price * (1 + rate)\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_discount():\n    assert @@F@@(200, 0.25) == 150.0\n\n\n"
        "def test_no_discount():\n    assert @@F@@(80, 0) == 80\n",
        "price * (1 + rate)", "price * (1 - rate)", "price * (1 + rate)", "price * rate",
        (
            _v(M="discount", F="apply_discount"),
            _v(M="sale", F="price_after_sale"),
            _v(M="pricing", F="net_price"),
        ),
    ),
    Template(
        "unbound_local", "UnboundLocalError",
        "@@F@@(score) maps 90+ to 'A', 80-89 to 'B' and anything lower to 'F'.",
        "def @@F@@(score):\n    if score >= 90:\n        label = \"A\"\n    elif score >= 80:\n"
        "        label = \"B\"\n    return label\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_a():\n    assert @@F@@(95) == \"A\"\n\n\n"
        "def test_b():\n    assert @@F@@(85) == \"B\"\n\n\ndef test_f():\n    assert @@F@@(50) == \"F\"\n",
        "        label = \"B\"\n    return label",
        "        label = \"B\"\n    else:\n        label = \"F\"\n    return label",
        "    if score >= 90:", "    label = None\n    if score >= 90:",
        (
            _v(M="grading", F="letter_grade"),
            _v(M="banding", F="classify_score"),
            _v(M="marks", F="mark_band"),
        ),
    ),
    Template(
        "none_return", "TypeError",
        "@@F@@(text) returns text stripped of whitespace and lower-cased.",
        "def @@F@@(text):\n    text.strip().lower()\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_length():\n    assert len(@@F@@(\"  Bob  \")) == 3\n\n\n"
        "def test_value():\n    assert @@F@@(\"  Bob  \") == \"bob\"\n",
        "    text.strip().lower()", "    return text.strip().lower()",
        "    text.strip().lower()", "    return text.strip()",
        (
            _v(M="names", F="clean_name"),
            _v(M="tagging", F="normalize_tag"),
            _v(M="words", F="tidy_word"),
        ),
    ),
    Template(
        "str_item_assignment", "TypeError",
        "@@F@@(word) returns word with its first letter upper-cased.",
        "def @@F@@(word):\n    word[0] = word[0].upper()\n    return word\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_word():\n    assert @@F@@(\"hello\") == \"Hello\"\n\n\n"
        "def test_single_letter():\n    assert @@F@@(\"a\") == \"A\"\n",
        "    word[0] = word[0].upper()\n    return word", "    return word[0].upper() + word[1:]",
        "    word[0] = word[0].upper()\n    return word",
        "    word = list(word)\n    word[0] = word[0].upper()\n    return word",
        (
            _v(M="casing", F="capitalize_first"),
            _v(M="titles", F="title_case_word"),
            _v(M="initials", F="upper_initial"),
        ),
    ),
    Template(
        "aliasing", "AssertionError",
        "@@F@@(items) returns a sorted copy and must not modify the input list.",
        "def @@F@@(items):\n    result = items\n    result.sort()\n    return result\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_sorted_output():\n    assert @@F@@([3, 1, 2]) == [1, 2, 3]\n\n\n"
        "def test_input_unchanged():\n    data = [3, 1, 2]\n    @@F@@(data)\n    assert data == [3, 1, 2]\n",
        "    result = items\n", "    result = list(items)\n",
        "    result = items\n", "    result = items  # sorted copy\n",
        (
            _v(M="copying", F="sorted_copy"),
            _v(M="ranking", F="ranked"),
            _v(M="ordering", F="ordered_scores"),
        ),
    ),
    Template(
        "dict_mutation", "RuntimeError",
        "@@F@@(data) removes keys whose values are falsy and returns the dict.",
        "def @@F@@(data):\n    for key in data:\n        if not data[key]:\n            del data[key]\n    return data\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_removes_falsy():\n"
        "    assert @@F@@({\"a\": 1, \"b\": 0, \"c\": \"\", \"d\": 3}) == {\"a\": 1, \"d\": 3}\n\n\n"
        "def test_keeps_all_truthy():\n    assert @@F@@({\"a\": 1}) == {\"a\": 1}\n",
        "    for key in data:", "    for key in list(data):",
        "    for key in data:", "    for key in data.keys():",
        (
            _v(M="empties", F="drop_empty"),
            _v(M="pruning", F="prune_blank"),
            _v(M="falsy", F="remove_falsy"),
        ),
    ),
    Template(
        "missing_base_case", "RecursionError",
        "@@F@@(n) returns n + (n-1) + ... + 1, and 0 for n <= 0.",
        "def @@F@@(n):\n    return n + @@F@@(n - 1)\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_four():\n    assert @@F@@(4) == 10\n\n\n"
        "def test_zero():\n    assert @@F@@(0) == 0\n",
        "    return n + @@F@@(n - 1)", "    if n <= 0:\n        return 0\n    return n + @@F@@(n - 1)",
        "    return n + @@F@@(n - 1)", "    if n == 1000:\n        return 0\n    return n + @@F@@(n - 1)",
        (
            _v(M="recursion", F="sum_to"),
            _v(M="countdown", F="countdown_total"),
            _v(M="rsum", F="recursive_sum"),
        ),
    ),
    Template(
        "import_name", "ImportError",
        "@@F@@(x) clamps x into the range 0..10 using a helper from pkg.util.",
        "from pkg.util import @@W@@ as clamp\n\n\ndef @@F@@(x):\n    return clamp(x, 0, 10)\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_high():\n    assert @@F@@(15) == 10\n\n\n"
        "def test_low():\n    assert @@F@@(-3) == 0\n\n\ndef test_inside():\n    assert @@F@@(5) == 5\n",
        "from pkg.util import @@W@@ as clamp", "from pkg.util import @@K@@ as clamp",
        "from pkg.util import @@W@@ as clamp", "from pkg.util import noop as clamp",
        (
            _v(M="scoring", F="limit_score", K="clamp_value", W="clamp_valu"),
            _v(M="levels", F="bound_level", K="bound", W="bnd"),
            _v(M="inputs", F="restrict_input", K="restrict", W="restrct"),
        ),
        util='"""Shared helpers."""\n\n\ndef noop(value):\n    return value\n\n\n'
        "def @@K@@(value, low, high):\n    return max(low, min(high, value))\n",
    ),
    Template(
        "value_error", "ValueError",
        "@@F@@(text) parses a quantity such as '4' or '3.5' and returns it truncated to an int.",
        "def @@F@@(text):\n    return int(text)\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_whole():\n    assert @@F@@(\"4\") == 4\n\n\n"
        "def test_fractional():\n    assert @@F@@(\"3.5\") == 3\n",
        "    return int(text)", "    return int(float(text))",
        "    return int(text)", "    return int(text.strip())",
        (
            _v(M="quantity", F="parse_quantity"),
            _v(M="counts", F="read_count"),
            _v(M="units", F="to_units"),
        ),
    ),
    Template(
        "logic_or_and", "AssertionError",
        "@@F@@(port) is True only for TCP ports 1..65535.",
        "def @@F@@(port):\n    return port > 0 or port < 65536\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_valid():\n    assert @@F@@(80) is True\n    assert @@F@@(65535) is True\n\n\n"
        "def test_zero_invalid():\n    assert @@F@@(0) is False\n\n\ndef test_too_large_invalid():\n"
        "    assert @@F@@(70000) is False\n",
        "port > 0 or port < 65536", "port > 0 and port < 65536",
        "port > 0 or port < 65536", "port > 0 and port < 65535",
        (
            _v(M="ports", F="is_valid_port"),
            _v(M="network", F="valid_port"),
            _v(M="sockets", F="port_ok"),
        ),
    ),
    Template(
        "integer_division", "AssertionError",
        "@@F@@(part, total) returns part as a percentage of total, as a float.",
        "def @@F@@(part, total):\n    return part // total * 100\n",
        "from pkg.@@M@@ import @@F@@\n\n\ndef test_quarter():\n    assert @@F@@(1, 4) == 25.0\n\n\n"
        "def test_three_quarters():\n    assert @@F@@(3, 4) == 75.0\n\n\ndef test_full():\n"
        "    assert @@F@@(4, 4) == 100.0\n",
        "part // total * 100", "part / total * 100", "part // total * 100", "part // total * 100.0",
        (
            _v(M="progress", F="percent_done"),
            _v(M="shares", F="share_pct"),
            _v(M="completion", F="completion_rate"),
        ),
    ),
    Template(
        "init_attribute", "AttributeError",
        "@@C@@(@@A@@).describe() returns '@@C@@(<@@A@@>)'.",
        "class @@C@@:\n    def __init__(self, @@A@@):\n        @@A@@ = @@A@@\n\n    def describe(self):\n"
        "        return \"@@C@@(\" + self.@@A@@ + \")\"\n",
        "from pkg.@@M@@ import @@C@@\n\n\ndef test_describe():\n    assert @@C@@(\"ann\").describe() == \"@@C@@(ann)\"\n\n\n"
        "def test_describe_other():\n    assert @@C@@(\"bo\").describe() == \"@@C@@(bo)\"\n",
        "        @@A@@ = @@A@@\n", "        self.@@A@@ = @@A@@\n",
        "        @@A@@ = @@A@@\n", "        self._@@A@@ = @@A@@\n",
        (
            _v(M="users", C="User", A="name"),
            _v(M="projects", C="Project", A="title"),
            _v(M="devices", C="Device", A="serial"),
        ),
    ),
)


def _build(template: Template, index: int, values: dict[str, str]) -> Scenario:
    module = values["M"]
    files = {
        "pkg/__init__.py": "",
        f"pkg/{module}.py": _fill(template.source, values),
        "pkg/util.py": _fill(template.util, values),
    }
    tests = {f"tests/test_{module}.py": _fill(template.test, values)}
    path = f"pkg/{module}.py"
    return Scenario(
        scenario_id=f"{template.template_id}-{index}",
        exception=template.exception,
        description=_fill(template.description, values),
        files=files,
        tests=tests,
        edits=(Edit(path, _fill(template.edit_old, values), _fill(template.edit_new, values)),),
        wrong_edits=(Edit(path, _fill(template.wrong_old, values), _fill(template.wrong_new, values)),),
    )




@lru_cache(maxsize=1)
def build_scenarios() -> tuple[Scenario, ...]:
    scenarios = [
        _build(template, i, values)
        for template in TEMPLATES
        for i, values in enumerate(template.variants, start=1)
    ]
    ids = [s.scenario_id for s in scenarios]
    if len(set(ids)) != len(ids):
        raise ValueError("duplicate scenario ids")
    return tuple(scenarios)


def get_scenario(scenario_id: str) -> Scenario:
    for scenario in build_scenarios():
        if scenario.scenario_id == scenario_id:
            return scenario
    raise KeyError(f"unknown scenario {scenario_id!r}")


def scenario_ids() -> list[str]:
    return [s.scenario_id for s in build_scenarios()]


def validate_scenario(scenario: Scenario, test_timeout_s: float = 30.0) -> list[str]:
    """Return a list of problems (empty means the scenario is sound)."""
    problems: list[str] = []
    if scenario.expected_tests < 2:
        problems.append("fewer than 2 tests")
    with Sandbox(scenario, test_timeout_s) as sandbox:
        before = sandbox.run_tests()
        if before.all_passed:
            problems.append("tests already pass before any fix")
        reports = parse_errors(before.output, str(sandbox.root))
        if scenario.exception not in {r.exception_type for r in reports}:
            found = sorted({r.exception_type for r in reports})
            problems.append(f"expected {scenario.exception} in failure output, parsed {found}")
        try:
            apply_edits(sandbox, list(scenario.edits))
        except Exception as exc:  # noqa: BLE001 - report any patch problem
            problems.append(f"reference fix does not apply: {exc}")
        else:
            after = sandbox.run_tests()
            if not after.all_passed or after.total != scenario.expected_tests:
                problems.append(f"reference fix does not pass: {after.summary()}")
    with Sandbox(scenario, test_timeout_s) as sandbox:
        try:
            apply_edits(sandbox, list(scenario.wrong_edits))
        except Exception as exc:  # noqa: BLE001
            problems.append(f"wrong fix does not apply: {exc}")
        else:
            if sandbox.run_tests().all_passed:
                problems.append("wrong fix unexpectedly passes")
    return problems


def validate_all(test_timeout_s: float = 30.0) -> dict[str, list[str]]:
    return {s.scenario_id: p for s in build_scenarios() if (p := validate_scenario(s, test_timeout_s))}
