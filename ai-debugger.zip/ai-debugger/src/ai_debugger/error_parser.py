"""Parse pytest output and plain Python tracebacks into structured error reports."""

from __future__ import annotations

import re

from .models import ErrorReport, Frame

_BLOCK_HEADER = re.compile(r"^_{2,} (?P<name>.+?) _{2,}$")
_PYTEST_FRAME = re.compile(r"^(?P<path>\S+?\.py):(?P<line>\d+): (?:in (?P<func>\S+)|\S+)")
_PYTHON_FRAME = re.compile(r'^\s*File "(?P<path>[^"]+)", line (?P<line>\d+), in (?P<func>\S+)')
_E_LINE = re.compile(r"^E\s{2,}(?P<text>.*)$")
_EXC_LINE = re.compile(
    r"^(?P<type>[A-Za-z_][\w.]*(?:Error|Exception|Exit|Iteration|Interrupt|Warning|Failed))"
    r"(?:\s*:\s*(?P<msg>.*))?$"
)
_PLAIN_EXC_LINE = re.compile(
    r"^(?P<type>[A-Za-z_][\w.]*(?:Error|Exception|Iteration))(?:\s*:\s*(?P<msg>.*))?$"
)


def _normalise_path(path: str, root: str | None) -> str | None:
    """Return a workspace-relative path, or None for frames outside the project."""
    path = path.replace("\\", "/")
    if root:
        root = root.replace("\\", "/").rstrip("/") + "/"
        if path.startswith(root):
            path = path[len(root):]
    if path.startswith(("/", "<")) or "site-packages" in path or "/lib/python" in path:
        return None
    return path.removeprefix("./")


def _dedupe(frames: list[Frame]) -> list[Frame]:
    result: list[Frame] = []
    for frame in frames:
        if frame not in result:
            result.append(frame)
    return result


def _parse_block(name: str | None, lines: list[str], root: str | None) -> ErrorReport | None:
    frames: list[Frame] = []
    exception_type = message = None
    for line in lines:
        match = _PYTEST_FRAME.match(line) or _PYTHON_FRAME.match(line)
        if match and "func" in match.groupdict():
            path = _normalise_path(match.group("path"), root)
            if path:
                frames.append(Frame(path, int(match.group("line")), match.group("func") or "?"))
            continue
        e_line = _E_LINE.match(line)
        if e_line and exception_type is None:
            text = e_line.group("text").strip()
            exc = _EXC_LINE.match(text)
            if exc:
                exception_type, message = exc.group("type"), (exc.group("msg") or "").strip()
            elif text.startswith("assert"):
                exception_type, message = "AssertionError", text
            continue
        if exception_type is None and not e_line:
            plain = _PLAIN_EXC_LINE.match(line.strip())
            if plain and frames:
                exception_type, message = plain.group("type"), (plain.group("msg") or "").strip()
    if exception_type is None:
        return None
    return ErrorReport(name, exception_type, message or "", _dedupe(frames))


def parse_errors(output: str, root: str | None = None) -> list[ErrorReport]:
    """Return one :class:`ErrorReport` per failing test or collection error.

    ``root`` is the workspace directory; absolute paths under it are made
    relative and frames in the standard library or site-packages are dropped.
    """
    lines = output.splitlines()
    blocks: list[tuple[str | None, list[str]]] = []
    current: tuple[str | None, list[str]] | None = None
    for line in lines:
        header = _BLOCK_HEADER.match(line)
        if header:
            current = (header.group("name"), [])
            blocks.append(current)
        elif line.startswith("=") and "short test summary" in line:
            current = None
        elif current is not None:
            current[1].append(line)
    if not blocks:
        blocks = [(None, lines)]
    reports = [r for name, body in blocks if (r := _parse_block(name, body, root))]
    return reports


def format_report(report: ErrorReport) -> str:
    """Compact text form used in prompts and tool results."""
    lines = [f"{report.exception_type}: {report.message}".rstrip(": ")]
    if report.test_name:
        lines.append(f"  in test: {report.test_name}")
    for frame in report.frames:
        lines.append(f"  at {frame.path}:{frame.line} in {frame.function}")
    return "\n".join(lines)
