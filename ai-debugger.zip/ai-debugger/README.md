# Tool-Using AI Software Debugger

Agent that analyzes Python errors, retrieves relevant source context, proposes patches and validates
them with tests. 60 built-in scenarios (20 bug patterns x 3 variants, 10+ exception types).

Components: pytest/traceback parser, AST-chunk BM25 retrieval, atomic validated patcher with rollback,
schema-validated tool interface (list_files, read_file, run_tests, search_code, propose_patch),
bounded budgets (steps, patch attempts, invalid calls, timeouts), JSONL execution logs, failure analysis,
FastAPI service over a testable service layer.

## Setup
    pip install -e ".[dev]"            # ".[llm]" adds anthropic, ".[api]" adds fastapi/uvicorn

## Usage
    ai-debugger list
    ai-debugger validate                                   # every scenario: bug reproduces, fix passes, wrong fix fails
    ai-debugger run --profile strong --repeats 2           # SIMULATED agents, 120 records -> runs/executions.jsonl
    ai-debugger llm-run --model <MODEL_ID> --repeats 2     # real model; needs ANTHROPIC_API_KEY (100+ real executions)
    ai-debugger report runs/executions.jsonl --output runs/report.md
    ai-debugger serve                                      # or: uvicorn ai_debugger.api:app

API: GET /health, /scenarios, /scenarios/{id}, /analysis; POST /parse-error, /runs (built-in scenario ids only).

## Tests
    pytest     # 33 passed; the API test needs fastapi installed (skipped otherwise)

## Honest notes
- `run` uses scripted agents that read the reference fix: pipeline test only, flagged `simulated=true`.
- Scenarios are template-generated. The FastAPI layer and live Anthropic client were not run in my
  environment (no package access); the client is tested with a fake SDK.
