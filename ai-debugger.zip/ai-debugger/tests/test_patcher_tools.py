import pytest

from ai_debugger.models import Edit
from ai_debugger.patcher import PatchError, apply_edits, revert
from ai_debugger.sandbox import Sandbox
from ai_debugger.scenarios import get_scenario
from ai_debugger.tools import ToolBox


@pytest.fixture
def scenario():
    return get_scenario("name_typo-1")


def test_patch_applies_atomically_and_reverts(scenario):
    with Sandbox(scenario) as sb:
        good = scenario.edits[0]
        bad = Edit(good.path, "text that is not there", "x")
        with pytest.raises(PatchError):
            apply_edits(sb, [good, bad])
        assert sb.read(good.path) == scenario.files[good.path]  # nothing written
        applied = apply_edits(sb, [good])
        assert sb.read(good.path) != scenario.files[good.path]
        revert(sb, applied)
        assert sb.read(good.path) == scenario.files[good.path]


@pytest.mark.parametrize(
    "edit, fragment",
    [
        (Edit("pkg/summing.py", "", "x"), "must not be empty"),
        (Edit("pkg/summing.py", "item", "item"), "identical"),
        (Edit("pkg/summing.py", "item", "thing"), "matches"),          # several matches
        (Edit("tests/test_summing.py", "assert", "assert not"), "read-only"),
        (Edit("pkg/../tests/test_summing.py", "assert", "assert not"), "read-only"),
        (Edit("../outside.py", "a", "b"), "escapes"),
        (Edit("pkg/summing.py", "return totl", "return (totl"), "syntax error"),
        (Edit("pkg/missing.py", "a", "b"), "no such file"),
    ],
)
def test_patch_rejections(scenario, edit, fragment):
    with Sandbox(scenario) as sb:
        with pytest.raises(PatchError, match=fragment):
            apply_edits(sb, [edit])
        assert sb.edited_files() == []


def test_toolbox_validation_and_accuracy(scenario):
    with Sandbox(scenario) as sb:
        box = ToolBox(sb, max_patch_attempts=2)
        assert box.call("list_files", {}).ok
        assert not box.call("nope", {}).ok
        assert not box.call("read_file", {}).ok
        assert not box.call("read_file", {"path": 3}).ok
        assert not box.call("read_file", {"path": "x.py", "extra": 1}).ok
        assert not box.call("read_file", {"path": "../etc/passwd"}).ok
        assert (box.valid_calls, box.invalid_calls) == (1, 5)
        assert "   1  def sum_values" in box.call("read_file", {"path": "pkg/summing.py"}).output


def test_propose_patch_accepts_good_and_rejects_bad_then_exhausts_budget(scenario):
    with Sandbox(scenario) as sb:
        box = ToolBox(sb, max_patch_attempts=2)
        wrong = {"edits": [e.to_dict() for e in scenario.wrong_edits]}
        result = box.call("propose_patch", wrong)
        assert result.ok and "REJECTED" in result.output
        assert sb.read("pkg/summing.py") == scenario.files["pkg/summing.py"]  # reverted
        assert not box.solved and box.rejected_patches == 1
        result = box.call("propose_patch", {"edits": [e.to_dict() for e in scenario.edits]})
        assert result.ok and "accepted" in result.output and box.solved
        late = box.call("propose_patch", wrong)
        assert not late.ok and "budget exhausted" in late.output
        assert box.patch_attempts == 2


def test_search_code_and_run_tests(scenario):
    with Sandbox(scenario) as sb:
        box = ToolBox(sb)
        out = box.call("run_tests", {}).output
        assert "NameError" in out and "pkg/summing.py" in out
        found = box.call("search_code", {"query": "sum"}).output
        assert "sum_values" in found
        assert not box.call("search_code", {"top_k": 0}).ok
