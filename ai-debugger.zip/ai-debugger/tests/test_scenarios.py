import pytest

from ai_debugger.scenarios import TEMPLATES, build_scenarios, get_scenario, validate_all


def test_sixty_unique_scenarios_with_enough_templates():
    scenarios = build_scenarios()
    assert len(scenarios) == 60 and len({s.scenario_id for s in scenarios}) == 60
    assert len(TEMPLATES) == 20
    assert len({s.exception for s in scenarios}) >= 10
    assert all(s.expected_tests >= 2 for s in scenarios)


def test_unknown_scenario():
    with pytest.raises(KeyError):
        get_scenario("missing")


@pytest.mark.slow
def test_every_scenario_reproduces_and_fix_works():
    problems = validate_all()
    assert problems == {}
