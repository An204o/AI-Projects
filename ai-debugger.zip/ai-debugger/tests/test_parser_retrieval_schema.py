from ai_debugger import schema
from ai_debugger.error_parser import parse_errors
from ai_debugger.retrieval import CodeIndex, tokenize
from ai_debugger.scenarios import get_scenario
from ai_debugger.sandbox import Sandbox

PYTEST_OUTPUT = """\
=================================== FAILURES ===================================
____________________________ test_sums_numbers _________________________________

    def test_sums_numbers():
>       assert sum_values([1, 2, 3]) == 6

tests/test_summing.py:5:
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
pkg/summing.py:6: in sum_values
    return totl
E   NameError: name 'totl' is not defined
=========================== short test summary info ============================
FAILED tests/test_summing.py::test_sums_numbers - NameError: name 'totl' is not defined
"""


def test_parse_pytest_name_error():
    [report] = parse_errors(PYTEST_OUTPUT)
    assert report.exception_type == "NameError"
    assert report.message == "name 'totl' is not defined"
    assert report.test_name == "test_sums_numbers"
    assert report.innermost.path == "pkg/summing.py"
    assert report.innermost.line == 6


def test_parse_assertion_and_plain_traceback():
    assertion = "____ test_x ____\n\n>   assert f(1) == 2\ntests/t.py:3: in test_x\nE   assert 3 == 2\n"
    [report] = parse_errors(assertion)
    assert report.exception_type == "AssertionError"
    plain = 'Traceback (most recent call last):\n  File "/w/pkg/a.py", line 4, in go\n    1/0\nZeroDivisionError: division by zero\n'
    [report] = parse_errors(plain, root="/w")
    assert (report.exception_type, report.innermost.path) == ("ZeroDivisionError", "pkg/a.py")


def test_parse_ignores_library_frames_and_empty_output():
    out = '____ test_x ____\n/usr/lib/python3.12/json/__init__.py:1: in loads\npkg/a.py:2: in f\nE   ValueError: bad\n'
    [report] = parse_errors(out)
    assert [f.path for f in report.frames] == ["pkg/a.py"]
    assert parse_errors("3 passed in 0.01s") == []


def test_signature_normalises_numbers_and_paths():
    a = parse_errors("____ t ____\npkg/a.py:2: in f\nE   IndexError: index 5 out of range\n")[0]
    b = parse_errors("____ t ____\npkg/a.py:2: in f\nE   IndexError: index 9 out of range\n")[0]
    assert a.signature() == b.signature()


def test_parser_on_real_pytest_output():
    scenario = get_scenario("name_typo-1")
    with Sandbox(scenario) as sandbox:
        outcome = sandbox.run_tests()
        reports = parse_errors(outcome.output, str(sandbox.root))
    assert {r.exception_type for r in reports} == {"NameError"}
    assert reports[0].innermost.path == "pkg/summing.py"


def test_tokenize_splits_identifiers():
    assert {"max", "retries", "max_retries"} <= set(tokenize("max_retries"))
    assert {"get", "page", "size"} <= set(tokenize("getPageSize"))


def test_retrieval_ranks_traceback_function_first_and_finds_typo():
    scenario = get_scenario("name_typo-1")
    files = {**scenario.files, "pkg/other.py": "def unrelated(x):\n    return x * 2\n"}
    with Sandbox(scenario) as sandbox:
        reports = parse_errors(sandbox.run_tests().output, str(sandbox.root))
    top = CodeIndex(files).search(reports, top_k=2)
    assert top[0].path == "pkg/summing.py" and top[0].name == "sum_values"
    assert any("similar identifier" in reason for reason in top[0].reasons)
    assert "pkg/other.py" not in [s.path for s in top[:1]]
    assert "   1  def sum_values" in top[0].render()


def test_schema_validation():
    spec = {
        "type": "object",
        "properties": {
            "edits": {"type": "array", "minItems": 1, "items": {
                "type": "object", "properties": {"path": {"type": "string"}},
                "required": ["path"], "additionalProperties": False}},
            "top_k": {"type": "integer", "minimum": 1},
        },
        "required": ["edits"], "additionalProperties": False,
    }
    assert schema.validate({"edits": [{"path": "a"}]}, spec) == []
    assert schema.validate({}, spec)
    assert schema.validate({"edits": []}, spec)
    assert schema.validate({"edits": [{"path": 1}]}, spec)
    assert schema.validate({"edits": [{"path": "a", "x": 1}]}, spec)
    assert schema.validate({"edits": [{"path": "a"}], "top_k": True}, spec)  # bool is not an int
    assert schema.validate({"edits": [{"path": "a"}], "top_k": 0}, spec)
    assert schema.validate([], spec)
