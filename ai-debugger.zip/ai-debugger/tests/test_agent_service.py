import json
from types import SimpleNamespace

import pytest

from ai_debugger.agent import LLMAgent, Limits, debug_scenario
from ai_debugger.analysis import analyze, recurring_failures, render_report, summarize, wilson_interval
from ai_debugger.llm import AnthropicChatClient, AssistantTurn, ToolCall
from ai_debugger.logging_utils import ExecutionLog, read_records
from ai_debugger.scenarios import build_scenarios, get_scenario
from ai_debugger.service import DebuggerService
from ai_debugger.simulated import SimulatedAgent


class ScriptedClient:
    """Plays back a fixed list of tool-call turns."""

    def __init__(self, turns):
        self.turns = list(turns)
        self.seen = []

    def complete(self, system, messages, tools):
        self.seen.append(len(messages))
        calls = self.turns.pop(0) if self.turns else []
        blocks = [{"type": "tool_use", "id": f"t{len(self.seen)}{i}", "name": n, "input": a}
                  for i, (n, a) in enumerate(calls)]
        tool_calls = [ToolCall(b["id"], b["name"], b["input"]) for b in blocks]
        return AssistantTurn(blocks or [{"type": "text", "text": "done"}], tool_calls, 10, 5)


def patch_args(edits):
    return {"edits": [e.to_dict() for e in edits]}


def test_llm_agent_fixes_with_scripted_client():
    s = get_scenario("index_error-1")
    client = ScriptedClient([[("read_file", {"path": "pkg/lastitem.py"})],
                             [("propose_patch", patch_args(s.edits))]])
    record = debug_scenario(s, LLMAgent(client, name="scripted"))
    assert record.fixed and record.outcome == "fixed" and record.patch_attempts == 1
    assert record.tool_calls == record.valid_calls + 0 + record.invalid_calls
    assert record.input_tokens > 0 and not record.simulated


def test_llm_agent_retries_then_exhausts_budget():
    s = get_scenario("index_error-1")
    wrong = patch_args(s.wrong_edits)
    client = ScriptedClient([[("propose_patch", wrong)]] * 5)
    record = debug_scenario(s, LLMAgent(client), Limits(max_patch_attempts=2))
    assert not record.fixed and record.outcome == "retries_exhausted"
    assert record.patch_attempts == 2 and record.rejected_patches == 2


def test_agent_stopping_without_patch_and_invalid_call_limit():
    s = get_scenario("index_error-1")
    assert debug_scenario(s, LLMAgent(ScriptedClient([]))).outcome == "no_patch"
    junk = [[("bogus", {})]] * 10
    record = debug_scenario(s, LLMAgent(ScriptedClient(junk)), Limits(max_invalid_calls=3))
    assert record.outcome == "invalid_call_limit" and record.invalid_calls == 3


def test_step_limit_and_agent_crash_are_recorded():
    s = get_scenario("index_error-1")
    reads = [[("read_file", {"path": "pkg/lastitem.py"})]] * 10
    record = debug_scenario(s, LLMAgent(ScriptedClient(reads)), Limits(max_steps=3))
    assert record.outcome == "step_limit" and record.steps == 3

    class Boom:
        def complete(self, *a):
            raise RuntimeError("api down")

    record = debug_scenario(s, LLMAgent(Boom()))
    assert record.outcome == "agent_error" and "api down" in record.error


def test_limits_validation():
    with pytest.raises(ValueError):
        Limits(max_steps=0)


def test_anthropic_client_with_fake_sdk():
    captured = {}

    def create(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(
            content=[SimpleNamespace(type="text", text="hi"),
                     SimpleNamespace(type="tool_use", id="u1", name="run_tests", input={})],
            usage=SimpleNamespace(input_tokens=7, output_tokens=3), stop_reason="tool_use")

    sdk = SimpleNamespace(messages=SimpleNamespace(create=create))
    turn = AnthropicChatClient("some-model", sdk_client=sdk).complete("sys", [{"role": "user", "content": "x"}], [])
    assert captured["model"] == "some-model" and captured["system"] == "sys"
    assert turn.tool_calls[0].name == "run_tests" and turn.text == "hi"
    assert (turn.input_tokens, turn.output_tokens) == (7, 3)


def test_simulated_agent_is_deterministic_and_flagged():
    s = get_scenario("zero_division-1")
    a = debug_scenario(s, SimulatedAgent("weak", seed=1), include_events=False)
    b = debug_scenario(s, SimulatedAgent("weak", seed=1), include_events=False)
    assert (a.outcome, a.steps) == (b.outcome, b.steps) and a.simulated
    with pytest.raises(ValueError):
        SimulatedAgent("nope")


def test_log_roundtrip_and_corruption(tmp_path):
    s = get_scenario("name_typo-1")
    log = ExecutionLog(tmp_path / "sub" / "log.jsonl")
    log.append(debug_scenario(s, SimulatedAgent("strong")))
    [loaded] = read_records(log.path)
    assert loaded.scenario_id == "name_typo-1" and loaded.events
    log.path.write_text("{not json}\n")
    with pytest.raises(ValueError, match=":1:"):
        read_records(log.path)


def test_analysis_math_and_report(tmp_path):
    assert wilson_interval(0, 0) == (0.0, 0.0)
    low, high = wilson_interval(50, 100)
    assert 0.40 < low < 0.41 and 0.59 < high < 0.60
    service = DebuggerService(tmp_path / "e.jsonl")
    ids = ["name_typo-1", "name_typo-2", "key_error-1"]
    records = service.run_batch("weak", repeats=2, scenario_ids=ids)
    assert len(records) == 6 and len(service.records()) == 6
    summary = summarize(records)
    assert summary["runs"] == 6 and 0 <= summary["fix_rate"] <= 1
    assert summary["simulated_runs"] == 6
    assert set(analyze(records)) == {"overall", "by_agent", "by_exception", "recurring_failures"}
    assert "SIMULATED" in render_report(records)
    unfixed = [r for r in records if not r.fixed]
    for row in recurring_failures(records, min_count=1):
        assert row["count"] >= 1
    assert sum(r["count"] for r in recurring_failures(records, 1)) == len(unfixed)
    assert summarize([]) == {"runs": 0}


def test_service_queries_and_errors(tmp_path):
    service = DebuggerService(tmp_path / "e.jsonl")
    assert len(service.list_scenarios()) == len(build_scenarios()) == 60
    assert "files" in service.get_scenario("name_typo-1")
    with pytest.raises(KeyError):
        service.get_scenario("../../etc/passwd")
    with pytest.raises(ValueError):
        service.run("name_typo-1", profile="bogus")
    assert service.search("name_typo-1", "sum")[0]["name"] == "sum_values"
    assert service.parse_error("____ t ____\npkg/a.py:2: in f\nE   KeyError: 'x'\n")[0]["exception_type"] == "KeyError"
    json.dumps(service.run("name_typo-1").to_dict())


def test_api_if_fastapi_installed(tmp_path):
    pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient

    from ai_debugger.api import create_app

    client = TestClient(create_app(DebuggerService(tmp_path / "e.jsonl")))
    assert client.get("/health").json() == {"status": "ok"}
    assert len(client.get("/scenarios").json()) == 60
    assert client.get("/scenarios/nope").status_code == 404
    assert client.post("/runs", json={"scenario_id": "nope"}).status_code == 404
    assert client.post("/runs", json={"scenario_id": "name_typo-1", "profile": "x"}).status_code == 422
    assert client.post("/runs", json={"scenario_id": "name_typo-1"}).status_code == 200
    assert client.get("/analysis").json()["overall"]["runs"] == 1
