# rag-retrieval-eval

A small, dependency-light harness that measures how **chunking strategy** and **retriever choice** affect retrieval quality for a RAG system, using an AWS troubleshooting corpus (EC2, IAM, VPC, Lambda, S3, ALB, CloudWatch).

Most RAG demos stop at "it answers questions." This project asks a measurable question instead: *given the same documents, which chunking + retrieval combination actually surfaces the evidence needed to answer?*

## What is in here

| Component | Detail |
|---|---|
| Chunkers | whole-document, fixed word windows (with/without overlap), sentence groups |
| Retrievers | BM25 (implemented from scratch), TF-IDF cosine (scikit-learn, uni+bigrams), hybrid via Reciprocal Rank Fusion |
| Metrics | Recall@k, MRR, nDCG@k, bootstrap 95% CI on MRR, and **evidence coverage** |
| Dataset | 10 hand-written troubleshooting documents, 34 questions, each with a gold document and a verbatim evidence span |

**Relevance rule:** a chunk is relevant only if it comes from the gold document *and* contains the full evidence span. This makes chunking matter: if a boundary splits the evidence, no retriever can recover it. **Evidence coverage** reports that ceiling per chunking strategy.

## Run it

```bash
pip install -r requirements.txt
python -m pytest -q
python -m rag_eval -k 3 --csv results/results.csv
```

Or with Docker:

```bash
docker build -t rag-eval .
docker run --rm rag-eval -k 3
```

## Results (k = 3, 34 questions)

| chunking | retriever | avg words | coverage | recall@3 | MRR (95% CI) |
|---|---|---:|---:|---:|---|
| fixed-25 | bm25 | 21 | 0.59 | 0.50 | 0.38 (0.25-0.53) |
| fixed-50 | bm25 | 39 | 0.79 | 0.79 | 0.73 (0.57-0.86) |
| fixed-25-o8 | bm25 | 24 | 1.00 | 0.88 | 0.68 (0.55-0.80) |
| sentences-1 | hybrid-rrf | 20 | 1.00 | 0.97 | 0.83 (0.73-0.92) |
| sentences-2-o1 | bm25 | 40 | 1.00 | 0.97 | 0.93 (0.85-0.99) |
| whole-doc | bm25 | 98 | 1.00 | 1.00 | 0.98 (0.94-1.00) |

Run the command above for the full 18-row grid.

### Findings

- **Chunk boundaries dominate retriever choice.** Fixed 25-word windows cut the evidence in 41% of questions (coverage 0.59), capping recall no matter which retriever runs. Swapping BM25 for TF-IDF or hybrid moves MRR by at most 0.03 within a strategy; moving from fixed-25 to sentences-2-o1 raises BM25 MRR by 0.55.
- **Sentence-aware chunking beats fixed windows at similar size.** Two-sentence windows with one-sentence overlap reach MRR 0.93 at about 40 words per chunk, versus 0.73 for fixed 50-word windows.
- **Overlap repairs coverage but costs precision.** Adding 8 words of overlap to 25-word windows restores coverage from 0.59 to 1.00, but MRR is still only 0.68. Overlapping windows produce several partial-match chunks per passage, which plausibly dilutes the ranking (not isolated in this experiment).
- **Hybrid RRF did not beat BM25 on this corpus.** The vocabulary overlap between questions and documents is high, so a lexical retriever is already strong. This would likely change with paraphrased questions or a dense retriever.

### Limitations

- Small, hand-written corpus (10 documents, 34 questions), so confidence intervals are wide.
- `whole-doc` scores highest only because there are just 10 candidates and every document contains its evidence. It is a ceiling, not a recommendation: its chunks average 98 words, which wastes context window in a real pipeline. `avg words` is reported to keep that trade-off visible.
- Questions were written with the documents in view, which favors lexical retrieval. A natural next step is adding a dense embedding retriever and paraphrased questions.

## Project layout

```
rag_eval/
  data.py         loading, normalization, tokenizer
  chunking.py     chunking strategies
  retrievers.py   BM25, TF-IDF, hybrid RRF
  metrics.py      Recall@k, MRR, nDCG, bootstrap CI
  evaluate.py     sweep + CLI
data/             corpus.json, questions.json
tests/            pytest suite
.github/workflows/ci.yml
```
