import math

import pytest

from rag_eval.metrics import bootstrap_ci, hit_at_k, ndcg_at_k, reciprocal_rank


def test_hit_at_k_respects_cutoff():
    assert hit_at_k([0, 0, 1], 2) == 0.0
    assert hit_at_k([0, 0, 1], 3) == 1.0


def test_reciprocal_rank():
    assert reciprocal_rank([0, 1, 0]) == 0.5
    assert reciprocal_rank([0, 0, 0]) == 0.0


def test_ndcg_perfect_and_imperfect():
    assert ndcg_at_k([1, 0, 0], 3) == pytest.approx(1.0)
    assert ndcg_at_k([0, 1, 0], 3) == pytest.approx(1 / math.log2(3))
    assert ndcg_at_k([0, 0, 0], 3) == 0.0


def test_bootstrap_ci_brackets_mean_and_is_deterministic():
    values = [0.0, 1.0, 1.0, 0.5, 1.0, 0.0, 0.5, 1.0]
    mean = sum(values) / len(values)
    low, high = bootstrap_ci(values, seed=1)
    assert low <= mean <= high
    assert (low, high) == bootstrap_ci(values, seed=1)


def test_bootstrap_ci_constant_values_collapse():
    assert bootstrap_ci([1.0] * 10) == (1.0, 1.0)
