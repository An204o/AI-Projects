import pytest

from rag_eval.chunking import fixed_words, sentence_groups, split_sentences, whole_document
from rag_eval.data import Document

DOC = Document("d", "t", "One two three. Four five six. Seven eight nine. Ten eleven twelve.")


def test_fixed_words_no_overlap_covers_everything_once():
    chunks = fixed_words(5)(DOC)
    assert " ".join(c.text for c in chunks) == DOC.text


def test_fixed_words_overlap_repeats_words():
    chunks = fixed_words(6, overlap=2)(DOC)
    assert chunks[0].text.split()[-2:] == chunks[1].text.split()[:2]


def test_fixed_words_last_window_not_duplicated():
    chunks = fixed_words(6, overlap=3)(DOC)
    assert len({c.text for c in chunks}) == len(chunks)


def test_sentence_groups_never_split_sentences():
    chunks = sentence_groups(2)(DOC)
    assert [c.text for c in chunks] == [
        "One two three. Four five six.",
        "Seven eight nine. Ten eleven twelve.",
    ]


def test_whole_document_is_single_chunk():
    assert [c.text for c in whole_document()(DOC)] == [DOC.text]


def test_split_sentences():
    assert split_sentences("A b. C d? E f!") == ["A b.", "C d?", "E f!"]


@pytest.mark.parametrize("size,overlap", [(0, 0), (3, 3), (3, -1)])
def test_invalid_window_parameters_raise(size, overlap):
    with pytest.raises(ValueError):
        fixed_words(size, overlap)(DOC)
