from pathlib import Path

import pytest

from rag_eval.chunking import chunk_corpus, sentence_groups
from rag_eval.data import load_corpus, load_questions, normalize
from rag_eval.retrievers import BM25Retriever, HybridRetriever, TfidfRetriever

DATA = Path(__file__).resolve().parent.parent / "data"
DOCS = load_corpus(DATA / "corpus.json")
QUESTIONS = load_questions(DATA / "questions.json")
DOC_TEXT = {d.id: normalize(d.text) for d in DOCS}


def test_every_question_points_to_a_real_document():
    assert {q.doc_id for q in QUESTIONS} <= set(DOC_TEXT)


@pytest.mark.parametrize("question", QUESTIONS, ids=lambda q: q.id)
def test_evidence_appears_verbatim_in_gold_document(question):
    assert normalize(question.evidence) in DOC_TEXT[question.doc_id]


def test_question_ids_are_unique():
    assert len({q.id for q in QUESTIONS}) == len(QUESTIONS)


@pytest.mark.parametrize(
    "make", [BM25Retriever, TfidfRetriever, lambda: HybridRetriever([BM25Retriever(), TfidfRetriever()])]
)
def test_retrievers_find_obvious_match(make):
    chunks = chunk_corpus(DOCS, sentence_groups(1))
    retriever = make().fit(chunks)
    top = retriever.rank("Which port must the security group allow so I can SSH in?", 3)
    assert any(chunks[i].doc_id == "ec2-ssh" for i in top)


def test_bm25_idf_is_never_negative():
    chunks = chunk_corpus(DOCS, sentence_groups(1))
    retriever = BM25Retriever().fit(chunks)
    assert all(v >= 0 for v in retriever._idf.values())


def test_hybrid_requires_members():
    with pytest.raises(ValueError):
        HybridRetriever([])
