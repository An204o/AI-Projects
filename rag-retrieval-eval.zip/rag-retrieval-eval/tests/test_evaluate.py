from pathlib import Path

import pytest

from rag_eval.chunking import Chunk, chunk_corpus, fixed_words, whole_document
from rag_eval.data import Question, load_corpus, load_questions
from rag_eval.evaluate import evidence_coverage, is_relevant, main, run_sweep
from rag_eval.retrievers import BM25Retriever

DATA = Path(__file__).resolve().parent.parent / "data"
DOCS = load_corpus(DATA / "corpus.json")
QUESTIONS = load_questions(DATA / "questions.json")


def test_is_relevant_requires_gold_doc_and_full_evidence():
    q = Question("q", "?", "d1", "alpha beta")
    assert is_relevant(Chunk("d1", 0, "xx Alpha  Beta yy"), q) == 1
    assert is_relevant(Chunk("d2", 0, "alpha beta"), q) == 0
    assert is_relevant(Chunk("d1", 0, "alpha"), q) == 0


def test_whole_document_chunking_has_full_coverage():
    chunks = chunk_corpus(DOCS, whole_document())
    assert evidence_coverage(chunks, QUESTIONS) == 1.0


def test_tiny_windows_lose_evidence_coverage():
    chunks = chunk_corpus(DOCS, fixed_words(5))
    assert evidence_coverage(chunks, QUESTIONS) < 1.0


def test_sweep_rows_are_well_formed():
    rows = run_sweep(
        DOCS,
        QUESTIONS,
        k=3,
        strategies={"whole-doc": whole_document()},
        retrievers=[BM25Retriever()],
    )
    assert len(rows) == 1
    row = rows[0]
    assert 0.0 <= row["mrr"] <= row["recall@3"] <= 1.0
    assert row["mrr_ci_low"] <= row["mrr"] <= row["mrr_ci_high"]


def test_mrr_never_exceeds_coverage_ceiling():
    for row in run_sweep(DOCS, QUESTIONS, k=3):
        assert row["recall@3"] <= row["coverage"] + 1e-9


def test_cli_writes_csv(tmp_path, capsys):
    out = tmp_path / "results.csv"
    assert main(["--csv", str(out)]) == 0
    assert out.read_text().splitlines()[0].startswith("chunking,retriever")
    assert "Best MRR" in capsys.readouterr().out
