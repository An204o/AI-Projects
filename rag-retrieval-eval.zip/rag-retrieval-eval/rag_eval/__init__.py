"""rag_eval: measure how chunking and retrieval choices affect RAG retrieval quality."""

__version__ = "0.1.0"
