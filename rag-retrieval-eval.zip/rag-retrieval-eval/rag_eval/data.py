"""Dataset loading and text normalization."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

_WHITESPACE = re.compile(r"\s+")
_TOKEN = re.compile(r"[a-z0-9]+")
_STOPWORDS = frozenset(
    "a an and are as at be by do does for from how i in is it my of on or the "
    "to what when which why with can should would".split()
)


@dataclass(frozen=True)
class Document:
    id: str
    title: str
    text: str


@dataclass(frozen=True)
class Question:
    id: str
    question: str
    doc_id: str
    evidence: str


def normalize(text: str) -> str:
    """Lowercase and collapse whitespace so evidence matching ignores layout."""
    return _WHITESPACE.sub(" ", text).strip().lower()


def tokenize(text: str) -> list[str]:
    """Lowercase alphanumeric tokens with common stopwords removed."""
    return [t for t in _TOKEN.findall(text.lower()) if t not in _STOPWORDS]


def load_corpus(path: str | Path) -> list[Document]:
    with open(path, encoding="utf-8") as fh:
        return [Document(**row) for row in json.load(fh)]


def load_questions(path: str | Path) -> list[Question]:
    with open(path, encoding="utf-8") as fh:
        return [Question(**row) for row in json.load(fh)]
