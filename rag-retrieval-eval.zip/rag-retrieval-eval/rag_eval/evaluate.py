"""Sweep chunking strategies x retrievers and report retrieval quality."""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

from .chunking import Chunk, Chunker, chunk_corpus, default_strategies
from .data import Document, Question, load_corpus, load_questions, normalize
from .metrics import bootstrap_ci, hit_at_k, ndcg_at_k, reciprocal_rank
from .retrievers import Retriever, default_retrievers

DEFAULT_DATA_DIR = Path(__file__).resolve().parent.parent / "data"


def is_relevant(chunk: Chunk, question: Question) -> int:
    """A chunk is relevant if it comes from the gold document and holds the full evidence."""
    return int(
        chunk.doc_id == question.doc_id
        and normalize(question.evidence) in normalize(chunk.text)
    )


def evidence_coverage(chunks: list[Chunk], questions: list[Question]) -> float:
    """Share of questions whose evidence survives chunking intact in at least one chunk.

    This is the ceiling for any retriever: if the evidence was split across a
    chunk boundary, no ranking can recover it.
    """
    covered = sum(any(is_relevant(c, q) for c in chunks) for q in questions)
    return covered / len(questions)


def evaluate_pair(
    chunks: list[Chunk], questions: list[Question], retriever: Retriever, k: int
) -> dict[str, float]:
    retriever.fit(chunks)
    hits, rrs, ndcgs = [], [], []
    for question in questions:
        top = retriever.rank(question.question, k)
        rels = [is_relevant(chunks[i], question) for i in top]
        hits.append(hit_at_k(rels, k))
        rrs.append(reciprocal_rank(rels))
        ndcgs.append(ndcg_at_k(rels, k))
    n = len(questions)
    low, high = bootstrap_ci(rrs)
    return {
        f"recall@{k}": sum(hits) / n,
        "mrr": sum(rrs) / n,
        "mrr_ci_low": low,
        "mrr_ci_high": high,
        f"ndcg@{k}": sum(ndcgs) / n,
    }


def run_sweep(
    docs: list[Document],
    questions: list[Question],
    k: int = 3,
    strategies: dict[str, Chunker] | None = None,
    retrievers: list[Retriever] | None = None,
) -> list[dict]:
    strategies = strategies or default_strategies()
    rows = []
    for strategy_name, chunker in strategies.items():
        chunks = chunk_corpus(docs, chunker)
        coverage = evidence_coverage(chunks, questions)
        for retriever in retrievers or default_retrievers():
            metrics = evaluate_pair(chunks, questions, retriever, k)
            rows.append(
                {
                    "chunking": strategy_name,
                    "retriever": retriever.name,
                    "chunks": len(chunks),
                    "avg_words": sum(len(c.text.split()) for c in chunks) / len(chunks),
                    "coverage": coverage,
                    **metrics,
                }
            )
    return rows


def format_markdown(rows: list[dict], k: int) -> str:
    header = (
        f"| chunking | retriever | chunks | avg words | coverage | recall@{k} | MRR (95% CI) | nDCG@{k} |\n"
        "|---|---|---:|---:|---:|---:|---|---:|\n"
    )
    lines = [
        f"| {r['chunking']} | {r['retriever']} | {r['chunks']} | {r['avg_words']:.0f} "
        f"| {r['coverage']:.2f} "
        f"| {r[f'recall@{k}']:.2f} "
        f"| {r['mrr']:.2f} ({r['mrr_ci_low']:.2f}-{r['mrr_ci_high']:.2f}) "
        f"| {r[f'ndcg@{k}']:.2f} |"
        for r in rows
    ]
    return header + "\n".join(lines) + "\n"


def write_csv(rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Compare chunking strategies and retrievers on a QA set."
    )
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("-k", type=int, default=3, help="cutoff for recall@k and nDCG@k")
    parser.add_argument("--csv", type=Path, help="also write results to this CSV path")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    docs = load_corpus(args.data_dir / "corpus.json")
    questions = load_questions(args.data_dir / "questions.json")
    rows = run_sweep(docs, questions, k=args.k)
    print(format_markdown(rows, args.k))
    best = max(rows, key=lambda r: r["mrr"])
    print(
        f"Best MRR: {best['mrr']:.3f} with chunking={best['chunking']}, "
        f"retriever={best['retriever']}"
    )
    if args.csv:
        write_csv(rows, args.csv)
        print(f"Wrote {args.csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
