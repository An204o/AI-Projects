"""Ranking metrics over binary relevance lists.

Every function takes `rels`: a list of 0/1 flags ordered by retrieval rank.
"""

from __future__ import annotations

import math
import random
from typing import Sequence


def hit_at_k(rels: Sequence[int], k: int) -> float:
    """1.0 if any relevant item is in the top k (Recall@k for single-evidence queries)."""
    return 1.0 if any(rels[:k]) else 0.0


def reciprocal_rank(rels: Sequence[int]) -> float:
    for rank, rel in enumerate(rels, start=1):
        if rel:
            return 1.0 / rank
    return 0.0


def ndcg_at_k(rels: Sequence[int], k: int) -> float:
    def dcg(values: Sequence[int]) -> float:
        return sum(v / math.log2(i + 2) for i, v in enumerate(values[:k]))

    ideal = dcg(sorted(rels, reverse=True))
    return dcg(rels) / ideal if ideal > 0 else 0.0


def bootstrap_ci(
    values: Sequence[float],
    n_resamples: int = 2000,
    alpha: float = 0.05,
    seed: int = 0,
) -> tuple[float, float]:
    """Percentile bootstrap confidence interval for the mean."""
    if not values:
        return (0.0, 0.0)
    rng = random.Random(seed)
    n = len(values)
    means = sorted(
        sum(values[rng.randrange(n)] for _ in range(n)) / n for _ in range(n_resamples)
    )
    low = means[int((alpha / 2) * n_resamples)]
    high = means[min(n_resamples - 1, int((1 - alpha / 2) * n_resamples))]
    return (low, high)
