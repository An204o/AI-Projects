"""Chunking strategies.

Each strategy maps a Document to a list of Chunk objects. Strategies are
registered by name so the evaluator can sweep over them.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

from .data import Document

_SENTENCE_BOUNDARY = re.compile(r"(?<=[.!?])\s+")


@dataclass(frozen=True)
class Chunk:
    doc_id: str
    index: int
    text: str


Chunker = Callable[[Document], list[Chunk]]


def split_sentences(text: str) -> list[str]:
    return [s for s in _SENTENCE_BOUNDARY.split(text.strip()) if s]


def _windows(items: list[str], size: int, overlap: int) -> list[list[str]]:
    if size <= 0:
        raise ValueError("size must be positive")
    if not 0 <= overlap < size:
        raise ValueError("overlap must satisfy 0 <= overlap < size")
    stride = size - overlap
    windows = []
    for start in range(0, len(items), stride):
        window = items[start : start + size]
        if window:
            windows.append(window)
        if start + size >= len(items):
            break
    return windows


def fixed_words(size: int, overlap: int = 0) -> Chunker:
    """Fixed-size word windows. Fast and structure-blind."""

    def chunker(doc: Document) -> list[Chunk]:
        words = doc.text.split()
        return [
            Chunk(doc.id, i, " ".join(w))
            for i, w in enumerate(_windows(words, size, overlap))
        ]

    return chunker


def sentence_groups(n: int, overlap: int = 0) -> Chunker:
    """Groups of n sentences. Never cuts a sentence in half."""

    def chunker(doc: Document) -> list[Chunk]:
        sentences = split_sentences(doc.text)
        return [
            Chunk(doc.id, i, " ".join(w))
            for i, w in enumerate(_windows(sentences, n, overlap))
        ]

    return chunker


def whole_document() -> Chunker:
    """Baseline: one chunk per document."""

    def chunker(doc: Document) -> list[Chunk]:
        return [Chunk(doc.id, 0, doc.text)]

    return chunker


def default_strategies() -> dict[str, Chunker]:
    return {
        "whole-doc": whole_document(),
        "fixed-25": fixed_words(25),
        "fixed-25-o8": fixed_words(25, overlap=8),
        "fixed-50": fixed_words(50),
        "sentences-1": sentence_groups(1),
        "sentences-2-o1": sentence_groups(2, overlap=1),
    }


def chunk_corpus(docs: list[Document], chunker: Chunker) -> list[Chunk]:
    chunks: list[Chunk] = []
    for doc in docs:
        chunks.extend(chunker(doc))
    return chunks
