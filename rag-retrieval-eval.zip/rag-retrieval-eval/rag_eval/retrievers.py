"""Retrievers: a from-scratch BM25, TF-IDF cosine (scikit-learn), and hybrid RRF."""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from collections import Counter

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

from .chunking import Chunk
from .data import tokenize


class Retriever(ABC):
    name: str

    @abstractmethod
    def fit(self, chunks: list[Chunk]) -> "Retriever": ...

    @abstractmethod
    def scores(self, query: str) -> np.ndarray:
        """Relevance score for every fitted chunk, in fit order."""

    def rank(self, query: str, k: int) -> list[int]:
        """Indices of the top-k chunks. Ties break toward earlier chunks."""
        scores = self.scores(query)
        order = np.argsort(-scores, kind="stable")
        return order[:k].tolist()


class BM25Retriever(Retriever):
    """Okapi BM25 with the non-negative IDF variant."""

    name = "bm25"

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b

    def fit(self, chunks: list[Chunk]) -> "BM25Retriever":
        self._tfs = [Counter(tokenize(c.text)) for c in chunks]
        self._lengths = np.array([sum(tf.values()) for tf in self._tfs], dtype=float)
        self._avg_len = float(self._lengths.mean()) if len(chunks) else 0.0
        n = len(chunks)
        df: Counter[str] = Counter()
        for tf in self._tfs:
            df.update(tf.keys())
        self._idf = {
            term: math.log(1.0 + (n - freq + 0.5) / (freq + 0.5))
            for term, freq in df.items()
        }
        return self

    def scores(self, query: str) -> np.ndarray:
        terms = tokenize(query)
        out = np.zeros(len(self._tfs))
        for i, tf in enumerate(self._tfs):
            norm = self.k1 * (1 - self.b + self.b * self._lengths[i] / self._avg_len)
            for term in terms:
                freq = tf.get(term, 0)
                if freq:
                    out[i] += self._idf[term] * freq * (self.k1 + 1) / (freq + norm)
        return out


class TfidfRetriever(Retriever):
    """Cosine similarity over sublinear TF-IDF unigram+bigram vectors."""

    name = "tfidf"

    def fit(self, chunks: list[Chunk]) -> "TfidfRetriever":
        self._vectorizer = TfidfVectorizer(
            tokenizer=tokenize,
            lowercase=False,
            token_pattern=None,
            ngram_range=(1, 2),
            sublinear_tf=True,
        )
        self._matrix = self._vectorizer.fit_transform([c.text for c in chunks])
        return self

    def scores(self, query: str) -> np.ndarray:
        query_vec = self._vectorizer.transform([query])
        return linear_kernel(query_vec, self._matrix).ravel()


class HybridRetriever(Retriever):
    """Reciprocal Rank Fusion of several retrievers.

    score(d) = sum over retrievers of 1 / (rrf_k + rank_r(d)), rank starting at 1.
    RRF needs no score calibration, which is why it is a common hybrid default.
    """

    name = "hybrid-rrf"

    def __init__(self, retrievers: list[Retriever], rrf_k: int = 60) -> None:
        if not retrievers:
            raise ValueError("need at least one retriever")
        self.retrievers = retrievers
        self.rrf_k = rrf_k

    def fit(self, chunks: list[Chunk]) -> "HybridRetriever":
        self._n = len(chunks)
        for retriever in self.retrievers:
            retriever.fit(chunks)
        return self

    def scores(self, query: str) -> np.ndarray:
        fused = np.zeros(self._n)
        for retriever in self.retrievers:
            order = retriever.rank(query, self._n)
            for rank, idx in enumerate(order, start=1):
                fused[idx] += 1.0 / (self.rrf_k + rank)
        return fused


def default_retrievers() -> list[Retriever]:
    return [
        BM25Retriever(),
        TfidfRetriever(),
        HybridRetriever([BM25Retriever(), TfidfRetriever()]),
    ]
