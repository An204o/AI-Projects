"""agent_eval: an evaluation framework for LLM coding agents."""

__version__ = "0.1.0"
