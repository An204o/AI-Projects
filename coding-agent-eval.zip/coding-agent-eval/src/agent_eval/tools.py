"""Structured tool interface exposed to agents, with argument validation."""

from __future__ import annotations

import time
from typing import Any

from .models import ToolEvent
from .sandbox import Sandbox, TestOutcome, ToolError

_NO_ARGS = {"type": "object", "properties": {}, "required": [], "additionalProperties": False}


def _schema(properties: dict[str, str]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": {name: {"type": "string", "description": doc} for name, doc in properties.items()},
        "required": list(properties),
        "additionalProperties": False,
    }


# Anthropic tool-use format: {"name", "description", "input_schema"}.
TOOL_SPECS: list[dict[str, Any]] = [
    {
        "name": "list_files",
        "description": "List every file in the workspace (relative paths).",
        "input_schema": _NO_ARGS,
    },
    {
        "name": "read_file",
        "description": "Return the full text of one workspace file.",
        "input_schema": _schema({"path": "Relative path of the file to read."}),
    },
    {
        "name": "write_file",
        "description": (
            "Create or overwrite a source file with the given content. "
            "Files under tests/ and configuration files are read-only."
        ),
        "input_schema": _schema(
            {"path": "Relative path to write.", "content": "Complete new file content."}
        ),
    },
    {
        "name": "replace_in_file",
        "description": (
            "Replace one exact occurrence of `old` with `new` in a source file. "
            "Fails unless `old` appears exactly once."
        ),
        "input_schema": _schema(
            {
                "path": "Relative path of the file to edit.",
                "old": "Exact text to replace; must match exactly once.",
                "new": "Replacement text.",
            }
        ),
    },
    {
        "name": "run_tests",
        "description": "Run the project's test suite and return the pass/fail summary and output.",
        "input_schema": _NO_ARGS,
    },
]

EDIT_TOOLS = ("write_file", "replace_in_file")
PREVIEW_CHARS = 300


class ToolResult:
    """What an agent gets back from a tool call."""

    __slots__ = ("ok", "output")

    def __init__(self, ok: bool, output: str):
        self.ok = ok
        self.output = output


def check_args(spec: dict[str, Any], args: Any) -> None:
    """Validate ``args`` against a tool's flat string-only schema."""
    if not isinstance(args, dict):
        raise ToolError(f"arguments must be an object, got {type(args).__name__}")
    schema = spec["input_schema"]
    missing = [name for name in schema["required"] if name not in args]
    if missing:
        raise ToolError(f"missing required argument(s): {', '.join(missing)}")
    unexpected = [name for name in args if name not in schema["properties"]]
    if unexpected:
        raise ToolError(f"unexpected argument(s): {', '.join(sorted(unexpected))}")
    for name, value in args.items():
        if not isinstance(value, str):
            raise ToolError(f"argument {name!r} must be a string, got {type(value).__name__}")


class ToolBox:
    """Executes tool calls against a sandbox and records every call.

    A call is *valid* when the tool exists, the arguments match its schema and
    the operation itself succeeds (no path escape, missing file, ambiguous
    edit, protected file...). Tool-call accuracy is valid calls / all calls.
    """

    def __init__(self, sandbox: Sandbox, max_output_chars: int = 4000):
        self.sandbox = sandbox
        self.max_output_chars = max_output_chars
        self.events: list[ToolEvent] = []
        self._specs = {spec["name"]: spec for spec in TOOL_SPECS}

    # -- public ------------------------------------------------------------
    def call(self, name: str, args: Any) -> ToolResult:
        started = time.perf_counter()
        ok, error, meta = True, None, {}
        try:
            spec = self._specs.get(name)
            if spec is None:
                raise ToolError(f"unknown tool {name!r}; available: {', '.join(self._specs)}")
            check_args(spec, args)
            output, meta = getattr(self, f"_tool_{name}")(**args)
        except ToolError as exc:
            ok, error = False, str(exc)
            output = f"ERROR: {exc}"
        output = self._clip(output)
        self.events.append(
            ToolEvent(
                step=len(self.events) + 1,
                tool=str(name),
                args=self._summarise_args(args),
                ok=ok,
                error=error,
                preview=output[:PREVIEW_CHARS],
                duration_s=time.perf_counter() - started,
                meta=meta,
            )
        )
        return ToolResult(ok, output)

    @property
    def valid_calls(self) -> int:
        return sum(1 for e in self.events if e.ok)

    # -- tools -------------------------------------------------------------
    def _tool_list_files(self) -> tuple[str, dict]:
        return "\n".join(self.sandbox.list_files()), {}

    def _tool_read_file(self, path: str) -> tuple[str, dict]:
        return self.sandbox.read(path), {"path": path}

    def _tool_write_file(self, path: str, content: str) -> tuple[str, dict]:
        self.sandbox.write(path, content)
        return f"wrote {len(content)} characters to {path}", {"edit_path": path}

    def _tool_replace_in_file(self, path: str, old: str, new: str) -> tuple[str, dict]:
        if not old:
            raise ToolError("`old` must not be empty")
        text = self.sandbox.read(path)
        occurrences = text.count(old)
        if occurrences == 0:
            raise ToolError(f"`old` text not found in {path}")
        if occurrences > 1:
            raise ToolError(f"`old` text appears {occurrences} times in {path}; make it unique")
        self.sandbox.write(path, text.replace(old, new, 1))
        return f"replaced 1 occurrence in {path}", {"edit_path": path}

    def _tool_run_tests(self) -> tuple[str, dict]:
        outcome: TestOutcome = self.sandbox.run_tests()
        meta = {
            "passed": outcome.passed,
            "total": outcome.total,
            "failed": outcome.failed,
            "errors": outcome.errors,
            "timed_out": outcome.timed_out,
            "all_passed": outcome.all_passed,
        }
        return f"{outcome.summary()}\n{outcome.output}", meta

    # -- helpers -----------------------------------------------------------
    def _clip(self, text: str) -> str:
        if len(text) <= self.max_output_chars:
            return text
        return text[: self.max_output_chars] + "\n...[output truncated]"

    @staticmethod
    def _summarise_args(args: Any) -> dict[str, Any]:
        """Keep logs small: replace long strings with their length."""
        if not isinstance(args, dict):
            return {"_invalid": repr(args)[:100]}
        summary: dict[str, Any] = {}
        for key, value in args.items():
            if isinstance(value, str) and len(value) > 80:
                summary[key] = f"<{len(value)} chars>"
            else:
                summary[key] = value
        return summary
