"""Markdown report generation."""

from __future__ import annotations

from collections import defaultdict

from .metrics import by_category, paired_comparison, summarize
from .models import FAILURE_AREA, RunResult


def _pct(value: float | None) -> str:
    return "n/a" if value is None else f"{value * 100:.1f}%"


def _table(headers: list[str], rows: list[list[str]]) -> str:
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    lines += ["| " + " | ".join(row) + " |" for row in rows]
    return "\n".join(lines)


def build_report(results: list[RunResult], manifest: dict | None = None) -> str:
    manifest = manifest or {}
    by_config: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        by_config[r.config_name].append(r)

    out = [f"# Agent evaluation report — {manifest.get('run_id', 'run')}", ""]
    if manifest.get("simulated"):
        out += [
            "> **Simulated results.** At least one configuration is the offline mock agent, "
            "which follows scripted behaviours to exercise the harness. Its numbers say "
            "nothing about any real model.",
            "",
        ]
    out += [
        f"- Tasks: {len(manifest.get('task_ids', [])) or len({r.task_id for r in results})}",
        f"- Configurations: {', '.join(by_config)}",
        f"- Repeats per task: {manifest.get('repeats', 1)}",
        f"- Seed: {manifest.get('seed', 'n/a')}",
        "",
        "## Summary by configuration",
        "",
    ]
    rows = []
    for name, runs in by_config.items():
        s = summarize(runs)
        low, high = s["resolve_ci"]
        rows.append(
            [
                name,
                str(s["runs"]),
                f"{_pct(s['resolve_rate'])} ({_pct(low)}–{_pct(high)})",
                _pct(s["mean_pass_rate"]),
                _pct(s["tool_call_accuracy"]),
                f"{s['mean_duration_s']:.2f}s / {s['p90_duration_s']:.2f}s",
                f"{s['mean_steps']:.1f}",
            ]
        )
    out.append(
        _table(
            ["Config", "Runs", "Task completion (95% CI)", "Test pass rate", "Tool-call accuracy",
             "Time mean / p90", "Mean steps"],
            rows,
        )
    )

    out += ["", "## Failure analysis", ""]
    failure_types = sorted({f for r in results for f in [r.failure_type] if f != "none"})
    if failure_types:
        out.append(
            _table(
                ["Failure type", "Capability", *by_config],
                [
                    [
                        f,
                        FAILURE_AREA.get(f, "?"),
                        *[
                            str(sum(1 for r in runs if r.failure_type == f))
                            for runs in by_config.values()
                        ],
                    ]
                    for f in failure_types
                ],
            )
        )
    else:
        out.append("No failures.")

    out += ["", "## Task completion by category", ""]
    categories = sorted({r.category for r in results})
    cat_rows = []
    for cat in categories:
        row = [cat]
        for runs in by_config.values():
            sub = by_category([r for r in runs if r.category == cat])[cat]
            row.append(_pct(sub["resolve_rate"]))
        cat_rows.append(row)
    out.append(_table(["Category", *by_config], cat_rows))

    names = list(by_config)
    if len(names) > 1:
        out += ["", f"## Paired comparison against `{names[0]}`", ""]
        pair_rows = []
        for other in names[1:]:
            c = paired_comparison(by_config[names[0]], by_config[other])
            pair_rows.append(
                [
                    other,
                    str(c["paired_runs"]),
                    str(c["only_a_resolved"]),
                    str(c["only_b_resolved"]),
                    f"{c['p_value']:.4f}",
                ]
            )
        out.append(
            _table(
                ["Config", "Paired runs", f"Only {names[0]} solved", "Only this config solved",
                 "McNemar exact p"],
                pair_rows,
            )
        )
    return "\n".join(out) + "\n"
