"""Command-line interface: ``agent-eval <command>``."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .metrics import summarize
from .models import AgentConfig
from .regression import compare_runs
from .report import build_report
from .runner import load_manifest, load_results, run_suite
from .task_bank import build_task_bank, export_tasks, select_tasks, validate_bank


def _load_configs(path: str) -> list[AgentConfig]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, list) or not data:
        raise SystemExit("configs file must contain a non-empty JSON list")
    return [AgentConfig.from_dict(item) for item in data]


def _cmd_list(args: argparse.Namespace) -> int:
    tasks = select_tasks(build_task_bank(), categories=args.category)
    for t in tasks:
        print(f"{t.task_id:32} {t.category:16} {t.difficulty:7} {t.expected_tests} tests")
    print(f"\n{len(tasks)} tasks")
    return 0


def _cmd_validate(args: argparse.Namespace) -> int:
    tasks = build_task_bank()
    problems = validate_bank(tasks, workers=args.workers)
    for task_id, issues in problems.items():
        print(f"INVALID {task_id}: {'; '.join(issues)}")
    print(f"{len(tasks) - len(problems)}/{len(tasks)} tasks valid")
    return 1 if problems else 0


def _cmd_export(args: argparse.Namespace) -> int:
    print(f"wrote {export_tasks(build_task_bank(), args.directory)} tasks to {args.directory}")
    return 0


def _cmd_run(args: argparse.Namespace) -> int:
    tasks = select_tasks(
        build_task_bank(), categories=args.category, task_ids=args.task_id, limit=args.limit
    )
    if not tasks:
        raise SystemExit("no tasks selected")
    configs = _load_configs(args.configs)
    run_dir = run_suite(
        tasks, configs, args.out, seed=args.seed, repeats=args.repeats, workers=args.workers
    )
    results = load_results(run_dir)
    for config in configs:
        s = summarize([r for r in results if r.config_name == config.name])
        print(
            f"{config.name:20} resolved {s['resolved']}/{s['runs']} "
            f"({s['resolve_rate'] * 100:.1f}%)  pass rate {s['mean_pass_rate'] * 100:.1f}%"
        )
    report = build_report(results, load_manifest(run_dir))
    (run_dir / "report.md").write_text(report, encoding="utf-8")
    print(f"\nrun directory: {run_dir}")
    return 0


def _cmd_report(args: argparse.Namespace) -> int:
    report = build_report(load_results(args.run_dir), load_manifest(args.run_dir))
    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
        print(f"wrote {args.output}")
    else:
        print(report)
    return 0


def _cmd_compare(args: argparse.Namespace) -> int:
    report = compare_runs(
        load_results(args.baseline), load_results(args.current), threshold=args.threshold
    )
    print(f"compared {report.compared} (config, task) pairs")
    print(f"regressions: {len(report.regressions)}   improvements: {len(report.improvements)}   "
          f"unchanged: {report.unchanged}")
    for config, task_id, before, after in report.regressions:
        print(f"  REGRESSION {config}/{task_id}: {before:.2f} -> {after:.2f}")
    for config, task_id in report.missing_in_current:
        print(f"  MISSING    {config}/{task_id}: not present in current run")
    ok = report.passes(args.max_regressions)
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="agent-eval", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("list-tasks", help="list tasks in the bank")
    p.add_argument("--category", action="append")
    p.set_defaults(func=_cmd_list)

    p = sub.add_parser("validate-tasks", help="check every task fails when buggy and passes when fixed")
    p.add_argument("--workers", type=int, default=4)
    p.set_defaults(func=_cmd_validate)

    p = sub.add_parser("export-tasks", help="write each task to a JSON file")
    p.add_argument("directory")
    p.set_defaults(func=_cmd_export)

    p = sub.add_parser("run", help="run configurations over tasks and record the experiment")
    p.add_argument("--configs", required=True, help="JSON file listing agent configurations")
    p.add_argument("--out", default="runs")
    p.add_argument("--seed", default="0")
    p.add_argument("--repeats", type=int, default=1)
    p.add_argument("--workers", type=int, default=2)
    p.add_argument("--limit", type=int)
    p.add_argument("--category", action="append")
    p.add_argument("--task-id", action="append")
    p.set_defaults(func=_cmd_run)

    p = sub.add_parser("report", help="render the Markdown report for a run directory")
    p.add_argument("run_dir")
    p.add_argument("--output")
    p.set_defaults(func=_cmd_report)

    p = sub.add_parser("compare", help="flag tasks that regressed between two runs")
    p.add_argument("baseline")
    p.add_argument("current")
    p.add_argument("--threshold", type=float, default=0.5)
    p.add_argument("--max-regressions", type=int, default=0)
    p.set_defaults(func=_cmd_compare)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
