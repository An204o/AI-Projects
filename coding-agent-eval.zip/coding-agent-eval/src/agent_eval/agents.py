"""Agents: a real LLM agent loop and an offline mock for exercising the harness."""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any

from .llm import AnthropicChatClient, ChatClient
from .models import AgentConfig, Task
from .sandbox import TestOutcome
from .tools import TOOL_SPECS, ToolBox

SYSTEM_PROMPT = (
    "You are a careful software engineering agent working in a small Python project. "
    "Fix the bug so that the project's tests pass. Use the tools to inspect files, "
    "edit source files and run the tests. Never edit files under tests/. "
    "When the tests pass, reply with a one-sentence summary and make no further tool calls."
)


@dataclass
class Budget:
    """Limits for one run. Steps count tool calls; the deadline is wall-clock."""

    max_steps: int
    wall_timeout_s: float
    started: float = 0.0

    def __post_init__(self) -> None:
        self.started = time.perf_counter()

    def steps_exhausted(self, toolbox: ToolBox) -> bool:
        return len(toolbox.events) >= self.max_steps

    def timed_out(self) -> bool:
        return time.perf_counter() - self.started > self.wall_timeout_s


@dataclass
class AgentOutcome:
    """How the agent's loop ended, before grading."""

    stop_reason: str  # finished | step_limit | timeout | error
    message: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    error: str | None = None


class Agent:
    def solve(
        self, task: Task, toolbox: ToolBox, budget: Budget, initial: TestOutcome
    ) -> AgentOutcome:
        raise NotImplementedError


# --------------------------------------------------------------------- LLM agent
def build_initial_prompt(
    task: Task, toolbox: ToolBox, context_mode: str, initial: TestOutcome
) -> str:
    """Compose the first user message. ``context_mode`` controls what is included."""
    sandbox = toolbox.sandbox
    parts = [f"Task: {task.description}"]
    if context_mode in ("tree", "failing_output", "full"):
        parts.append("Files in the workspace:\n" + "\n".join(sandbox.list_files()))
    if context_mode in ("tests", "full"):
        for path in sorted(task.tests):
            parts.append(f"Contents of {path}:\n{sandbox.read(path)}")
    if context_mode == "full":
        for path in sorted(task.files):
            parts.append(f"Contents of {path}:\n{sandbox.read(path)}")
    if context_mode in ("failing_output", "full"):
        parts.append(f"Initial test run ({initial.summary()}):\n{initial.output}")
    return "\n\n".join(parts)


class LLMAgent(Agent):
    """Tool-using loop: ask the model, run its tool calls, feed results back."""

    def __init__(self, config: AgentConfig, client: ChatClient | None = None):
        self.config = config
        self.client = client or AnthropicChatClient(
            model=config.model or "",
            max_tokens=config.max_tokens,
            temperature=config.temperature,
        )

    def solve(
        self, task: Task, toolbox: ToolBox, budget: Budget, initial: TestOutcome
    ) -> AgentOutcome:
        messages: list[dict[str, Any]] = [
            {
                "role": "user",
                "content": build_initial_prompt(task, toolbox, self.config.context_mode, initial),
            }
        ]
        in_tokens = out_tokens = 0
        last_text = ""
        while True:
            if budget.timed_out():
                return AgentOutcome("timeout", last_text, in_tokens, out_tokens)
            if budget.steps_exhausted(toolbox):
                return AgentOutcome("step_limit", last_text, in_tokens, out_tokens)
            turn = self.client.complete(SYSTEM_PROMPT, messages, TOOL_SPECS)
            in_tokens += turn.input_tokens
            out_tokens += turn.output_tokens
            last_text = turn.text or last_text
            messages.append({"role": "assistant", "content": turn.blocks})
            if not turn.tool_calls:
                return AgentOutcome("finished", last_text, in_tokens, out_tokens)
            results = []
            for call in turn.tool_calls:
                if budget.steps_exhausted(toolbox):
                    results.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": call.id,
                            "content": "ERROR: step budget exhausted",
                            "is_error": True,
                        }
                    )
                    continue
                result = toolbox.call(call.name, call.args)
                results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": call.id,
                        "content": result.output,
                        "is_error": not result.ok,
                    }
                )
            messages.append({"role": "user", "content": results})


# ------------------------------------------------------------------- mock agent
# Probability of each scripted behaviour, per profile. These simulate agents of
# different strength so the harness, metrics and reports can be exercised
# offline. They are NOT measurements of any real model.
MOCK_WEIGHTS: dict[str, dict[str, float]] = {
    "strong": dict(success=0.85, bad_patch=0.04, no_recovery=0.04, syntax_error=0.01,
                   context_miss=0.02, tool_misuse=0.02, no_edit=0.01, step_limit=0.01),
    "medium": dict(success=0.60, bad_patch=0.10, no_recovery=0.10, syntax_error=0.04,
                   context_miss=0.05, tool_misuse=0.05, no_edit=0.03, step_limit=0.03),
    "weak": dict(success=0.35, bad_patch=0.15, no_recovery=0.15, syntax_error=0.08,
                 context_miss=0.10, tool_misuse=0.08, no_edit=0.05, step_limit=0.04),
}


class MockAgent(Agent):
    """Deterministic scripted agent. Peeks at the reference solution by design."""

    def __init__(self, config: AgentConfig, seed: int | str = 0, repeat: int = 0):
        self.config = config
        self._rng_seed = f"{seed}|{config.name}|{repeat}"

    def solve(
        self, task: Task, toolbox: ToolBox, budget: Budget, initial: TestOutcome
    ) -> AgentOutcome:
        rng = random.Random(f"{self._rng_seed}|{task.task_id}")
        weights = MOCK_WEIGHTS[self.config.profile]
        behaviour = rng.choices(list(weights), weights=list(weights.values()))[0]
        target = task.target_files[0]
        original = task.files[target]
        correct = task.solution[target]

        def call(name: str, args: dict) -> bool:
            if budget.steps_exhausted(toolbox):
                return False
            toolbox.call(name, args)
            return True

        def finish(reason: str = "finished") -> AgentOutcome:
            return AgentOutcome(reason, f"mock behaviour: {behaviour}")

        if behaviour == "no_edit":
            call("list_files", {})
            call("read_file", {"path": target})
            return finish()
        if behaviour == "tool_misuse":
            call("apply_diff", {"path": target})
            call("read_file", {"path": "missing/file.py"})
            return finish()
        if behaviour == "step_limit":
            while call("read_file", {"path": target}):
                pass
            return finish("step_limit")
        if behaviour == "context_miss":
            call("list_files", {})
            call("write_file", {"path": "helpers.py", "content": "# edited\n"})
            call("run_tests", {})
            return finish()

        call("list_files", {})
        call("read_file", {"path": target})
        if behaviour == "success":
            call("write_file", {"path": target, "content": correct})
            call("run_tests", {})
        elif behaviour == "bad_patch":  # wrong fix, never verified
            call("write_file", {"path": target, "content": original + "\n# attempted fix\n"})
        elif behaviour == "no_recovery":  # wrong fix, sees failure, gives up
            call("write_file", {"path": target, "content": original + "\n# attempted fix\n"})
            call("run_tests", {})
        elif behaviour == "syntax_error":
            call("write_file", {"path": target, "content": original + "\ndef broken(:\n"})
            call("run_tests", {})
        return finish()


def build_agent(config: AgentConfig, seed: int | str = 0, repeat: int = 0) -> Agent:
    if config.kind == "mock":
        return MockAgent(config, seed=seed, repeat=repeat)
    return LLMAgent(config)
