"""Compare two experiment runs and flag tasks that got worse."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

from .models import RunResult


@dataclass
class RegressionReport:
    regressions: list[tuple[str, str, float, float]] = field(default_factory=list)
    improvements: list[tuple[str, str, float, float]] = field(default_factory=list)
    unchanged: int = 0
    compared: int = 0
    missing_in_current: list[tuple[str, str]] = field(default_factory=list)

    def passes(self, max_regressions: int = 0) -> bool:
        return len(self.regressions) <= max_regressions and not self.missing_in_current


def _resolve_rates(results: list[RunResult]) -> dict[tuple[str, str], float]:
    groups: dict[tuple[str, str], list[bool]] = defaultdict(list)
    for r in results:
        groups[(r.config_name, r.task_id)].append(r.resolved)
    return {key: sum(v) / len(v) for key, v in groups.items()}


def compare_runs(
    baseline: list[RunResult], current: list[RunResult], threshold: float = 0.5
) -> RegressionReport:
    """Tasks whose resolve rate dropped by at least ``threshold`` are regressions.

    With one repeat a rate is 0 or 1, so any drop counts. With several repeats
    the threshold tolerates ordinary run-to-run variance.
    """
    base, cur = _resolve_rates(baseline), _resolve_rates(current)
    report = RegressionReport()
    for key in sorted(base):
        if key not in cur:
            report.missing_in_current.append(key)
            continue
        report.compared += 1
        delta = cur[key] - base[key]
        if delta <= -threshold:
            report.regressions.append((key[0], key[1], base[key], cur[key]))
        elif delta >= threshold:
            report.improvements.append((key[0], key[1], base[key], cur[key]))
        else:
            report.unchanged += 1
    return report
