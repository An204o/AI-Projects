"""Bug templates used to generate the task bank.

Each template describes one bug pattern: the buggy source, the edits that fix
it, the tests, and several parameter sets ("variants"). Placeholders look like
``@@NAME@@`` and are replaced textually, so Python braces never need escaping.
``@@SPEC@@`` is the rendered ``spec`` sentence and is reused as the docstring.

The task bank therefore holds 28 patterns x 4 variants = 112 tasks. Variants
change names, constants and test data, but not the underlying bug pattern.
"""

from __future__ import annotations

TEMPLATES: list[dict] = [
    # ------------------------------------------------------------------ off by one
    dict(
        id="range-sum",
        category="off_by_one",
        difficulty="easy",
        spec="Return the sum of the integers from @@S@@ through n, inclusive (0 when n is below @@S@@).",
        buggy=r'''def @@F@@(n):
    """@@SPEC@@"""
    total = 0
    for i in range(@@S@@, n):
        total += i
    return total
''',
        fix=[("range(@@S@@, n)", "range(@@S@@, n + 1)")],
        tests=r'''from solution import @@F@@


def test_small():
    assert @@F@@(5) == sum(range(@@S@@, 6))


def test_equal_to_start():
    assert @@F@@(@@S@@) == @@S@@


def test_below_start_is_zero():
    assert @@F@@(@@S@@ - 1) == 0


def test_larger():
    assert @@F@@(100) == sum(range(@@S@@, 101))
''',
        variants=[
            dict(F="sum_to", S="1"),
            dict(F="sum_from_two", S="2"),
            dict(F="total_up_to", S="0"),
            dict(F="accumulate_from_three", S="3"),
        ],
    ),
    dict(
        id="scaled-factorial",
        category="off_by_one",
        difficulty="easy",
        spec="Return @@B@@ multiplied by every integer from 1 through n inclusive (@@B@@ when n is 0).",
        buggy=r'''def @@F@@(n):
    """@@SPEC@@"""
    result = @@B@@
    for i in range(1, n):
        result *= i
    return result
''',
        fix=[("range(1, n)", "range(1, n + 1)")],
        tests=r'''import math

from solution import @@F@@


def test_zero():
    assert @@F@@(0) == @@B@@


def test_one():
    assert @@F@@(1) == @@B@@


def test_five():
    assert @@F@@(5) == @@B@@ * math.factorial(5)


def test_ten():
    assert @@F@@(10) == @@B@@ * math.factorial(10)
''',
        variants=[
            dict(F="factorial", B="1"),
            dict(F="double_factorial_product", B="2"),
            dict(F="triple_product", B="3"),
            dict(F="five_times_factorial", B="5"),
        ],
    ),
    dict(
        id="sequence-term",
        category="off_by_one",
        difficulty="medium",
        spec=(
            "Return the n-th term (counting from 0) of the sequence that starts @@A@@, @@B@@ "
            "and in which every later term is the sum of the previous two."
        ),
        buggy=r'''def @@F@@(n):
    """@@SPEC@@"""
    a, b = @@A@@, @@B@@
    for _ in range(n - 1):
        a, b = b, a + b
    return a
''',
        fix=[("range(n - 1)", "range(n)")],
        tests=r'''from solution import @@F@@


def reference(n):
    terms = [@@A@@, @@B@@]
    while len(terms) <= n:
        terms.append(terms[-1] + terms[-2])
    return terms[n]


def test_first_terms():
    for n in range(5):
        assert @@F@@(n) == reference(n)


def test_term_ten():
    assert @@F@@(10) == reference(10)


def test_term_zero():
    assert @@F@@(0) == @@A@@
''',
        variants=[
            dict(F="fibonacci", A="0", B="1"),
            dict(F="lucas", A="2", B="1"),
            dict(F="seeded_one_three", A="1", B="3"),
            dict(F="seeded_zero_two", A="0", B="2"),
        ],
    ),
    dict(
        id="binary-search",
        category="off_by_one",
        difficulty="medium",
        spec="Return the index of target in the sorted list values, or -1 when target is absent.",
        buggy=r'''def @@F@@(values, target):
    """@@SPEC@@"""
    lo, hi = 0, len(values) - 1
    while lo < hi:
        mid = (lo + hi) // 2
        if values[mid] == target:
            return mid
        if values[mid] < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1
''',
        fix=[("while lo < hi:", "while lo <= hi:")],
        tests=r'''from solution import @@F@@

VALUES = list(range(0, 2 * @@N@@, 2))


def test_finds_every_element():
    for index, value in enumerate(VALUES):
        assert @@F@@(VALUES, value) == index


def test_absent_below():
    assert @@F@@(VALUES, -1) == -1


def test_absent_above():
    assert @@F@@(VALUES, 2 * @@N@@ + 1) == -1


def test_empty_list():
    assert @@F@@([], 0) == -1
''',
        variants=[
            dict(F="binary_search", N="1"),
            dict(F="find_index", N="2"),
            dict(F="locate", N="7"),
            dict(F="bisect_find", N="16"),
        ],
    ),
    dict(
        id="pagination",
        category="off_by_one",
        difficulty="easy",
        spec="Return the items on the given page, where pages are numbered from 1 and each holds size items (default @@SZ@@).",
        buggy=r'''def @@F@@(items, page, size=@@SZ@@):
    """@@SPEC@@"""
    start = page * size
    return items[start:start + size]
''',
        fix=[("start = page * size", "start = (page - 1) * size")],
        tests=r'''from solution import @@F@@

ITEMS = list(range(10))


def test_first_page():
    assert @@F@@(ITEMS, 1) == ITEMS[:@@SZ@@]


def test_second_page():
    assert @@F@@(ITEMS, 2) == ITEMS[@@SZ@@:2 * @@SZ@@]


def test_page_past_the_end():
    assert @@F@@(ITEMS, 99) == []


def test_empty_items():
    assert @@F@@([], 1) == []
''',
        variants=[
            dict(F="get_page", SZ="3"),
            dict(F="paginate", SZ="4"),
            dict(F="page_of", SZ="5"),
            dict(F="slice_page", SZ="2"),
        ],
    ),
    # ------------------------------------------------------------- operator / logic
    dict(
        id="threshold-boundary",
        category="operator_logic",
        difficulty="easy",
        spec="Return True when value is at least @@T@@ (the threshold itself counts).",
        buggy=r'''def @@F@@(value):
    """@@SPEC@@"""
    return value > @@T@@
''',
        fix=[("value > @@T@@", "value >= @@T@@")],
        tests=r'''from solution import @@F@@


def test_at_threshold():
    assert @@F@@(@@T@@) is True


def test_below_threshold():
    assert @@F@@(@@T@@ - 1) is False


def test_above_threshold():
    assert @@F@@(@@T@@ + 1) is True
''',
        variants=[
            dict(F="is_adult", T="18"),
            dict(F="can_rent_car", T="21"),
            dict(F="is_senior", T="65"),
            dict(F="is_perfect_score", T="100"),
        ],
    ),
    dict(
        id="leap-year",
        category="operator_logic",
        difficulty="easy",
        spec="Return True when year is a leap year in the Gregorian calendar.",
        buggy=r'''def @@F@@(year):
    """@@SPEC@@"""
    return year % 4 == 0
''',
        fix=[("return year % 4 == 0", "return (year % 4 == 0 and year % 100 != 0) or year % 400 == 0")],
        tests=r'''from solution import @@F@@


def test_ordinary_leap_year():
    assert @@F@@(2024) is True


def test_ordinary_common_year():
    assert @@F@@(2023) is False


def test_century_is_not_leap():
    assert @@F@@(1900) is False
    assert @@F@@(2100) is False


def test_four_hundred_rule():
    assert @@F@@(2000) is True
''',
        variants=[
            dict(F="is_leap_year"),
            dict(F="leap_year"),
            dict(F="has_feb_29"),
            dict(F="is_leap"),
        ],
    ),
    dict(
        id="clamp",
        category="operator_logic",
        difficulty="easy",
        spec="Clamp value into the inclusive range [low, high]; low defaults to @@LO@@ and high to @@HI@@.",
        buggy=r'''def @@F@@(value, low=@@LO@@, high=@@HI@@):
    """@@SPEC@@"""
    return min(low, max(value, high))
''',
        fix=[("min(low, max(value, high))", "max(low, min(value, high))")],
        tests=r'''from solution import @@F@@

MID = (@@LO@@ + @@HI@@) // 2


def test_inside_range_is_unchanged():
    assert @@F@@(MID) == MID


def test_above_is_clamped_to_high():
    assert @@F@@(@@HI@@ + 100) == @@HI@@


def test_below_is_clamped_to_low():
    assert @@F@@(@@LO@@ - 100) == @@LO@@


def test_custom_bounds():
    assert @@F@@(5, 0, 10) == 5
    assert @@F@@(50, 0, 10) == 10
''',
        variants=[
            dict(F="clamp", LO="0", HI="10"),
            dict(F="clamp_rating", LO="1", HI="5"),
            dict(F="clamp_offset", LO="-5", HI="5"),
            dict(F="clamp_volume", LO="10", HI="20"),
        ],
    ),
    dict(
        id="early-return",
        category="operator_logic",
        difficulty="medium",
        spec="Return True when any value in values @@DESC@@ limit, otherwise False.",
        buggy=r'''def @@F@@(values, limit):
    """@@SPEC@@"""
    for v in values:
        if v @@OP@@ limit:
            return True
        return False
    return False
''',
        fix=[("            return True\n        return False\n", "            return True\n")],
        tests=r'''from solution import @@F@@


def test_match_after_first_item():
    assert @@F@@(@@HIT@@, 5) is True


def test_no_match():
    assert @@F@@(@@MISS@@, 5) is False


def test_empty():
    assert @@F@@([], 5) is False
''',
        variants=[
            dict(F="any_above", OP=">", DESC="is greater than", HIT="[1, 9]", MISS="[1, 2]"),
            dict(F="any_below", OP="<", DESC="is less than", HIT="[9, 1]", MISS="[9, 8]"),
            dict(F="any_equal", OP="==", DESC="equals", HIT="[1, 5]", MISS="[1, 2]"),
            dict(F="any_at_least", OP=">=", DESC="is at least", HIT="[1, 5]", MISS="[1, 2]"),
        ],
    ),
    # --------------------------------------------------------------- control flow
    dict(
        id="missing-return",
        category="control_flow",
        difficulty="easy",
        spec="Return the values divisible by @@M@@, in their original order.",
        buggy=r'''def @@F@@(values):
    """@@SPEC@@"""
    result = []
    for v in values:
        if v % @@M@@ == 0:
            result.append(v)
''',
        fix=[("            result.append(v)\n", "            result.append(v)\n    return result\n")],
        tests=r'''from solution import @@F@@


def test_filters_in_order():
    assert @@F@@(list(range(1, 21))) == [v for v in range(1, 21) if v % @@M@@ == 0]


def test_empty_input():
    assert @@F@@([]) == []


def test_no_matches():
    assert @@F@@([1]) == []
''',
        variants=[
            dict(F="keep_even", M="2"),
            dict(F="keep_multiples_of_three", M="3"),
            dict(F="keep_multiples_of_five", M="5"),
            dict(F="keep_multiples_of_seven", M="7"),
        ],
    ),
    dict(
        id="recursive-fold",
        category="control_flow",
        difficulty="medium",
        spec="Using recursion, return the @@W@@ of all numbers in values; the empty list gives @@B@@.",
        buggy=r'''def @@F@@(values):
    """@@SPEC@@"""
    return values[0] @@OP@@ @@F@@(values[1:])
''',
        fix=[
            (
                "    return values[0] @@OP@@",
                "    if not values:\n        return @@B@@\n    return values[0] @@OP@@",
            )
        ],
        tests=r'''import math

from solution import @@F@@


def reference(values):
    return @@REF@@(values)


def test_several_numbers():
    assert @@F@@([1, 2, 3, 4]) == reference([1, 2, 3, 4])


def test_empty_list():
    assert @@F@@([]) == @@B@@


def test_single_number():
    assert @@F@@([5]) == 5


def test_pair():
    assert @@F@@([2, 3]) == reference([2, 3])
''',
        variants=[
            dict(F="recursive_sum", OP="+", B="0", W="sum", REF="sum"),
            dict(F="recursive_product", OP="*", B="1", W="product", REF="math.prod"),
            dict(F="add_all", OP="+", B="0", W="sum", REF="sum"),
            dict(F="multiply_all", OP="*", B="1", W="product", REF="math.prod"),
        ],
    ),
    # ----------------------------------------------------------------- numeric
    dict(
        id="integer-mean",
        category="numeric",
        difficulty="easy",
        spec="Return the arithmetic mean of values multiplied by @@K@@ (0.0 for an empty list).",
        buggy=r'''def @@F@@(values):
    """@@SPEC@@"""
    if not values:
        return 0.0
    return sum(values) // len(values) * @@K@@
''',
        fix=[("sum(values) //", "sum(values) /")],
        tests=r'''import pytest

from solution import @@F@@


def test_fractional_mean():
    assert @@F@@([1, 2]) == pytest.approx(1.5 * @@K@@)


def test_empty_list():
    assert @@F@@([]) == 0.0


def test_exact_mean():
    assert @@F@@([4, 4, 4]) == pytest.approx(4.0 * @@K@@)


def test_four_values():
    assert @@F@@([1, 2, 3, 4]) == pytest.approx(2.5 * @@K@@)
''',
        variants=[
            dict(F="mean", K="1"),
            dict(F="mean_times_two", K="2"),
            dict(F="mean_times_ten", K="10"),
            dict(F="mean_times_hundred", K="100"),
        ],
    ),
    dict(
        id="percent-rounding",
        category="numeric",
        difficulty="medium",
        spec="Convert a fraction such as 0.29 into a whole-number percentage, rounding to the nearest integer.",
        buggy=r'''def @@F@@(fraction):
    """@@SPEC@@"""
    return int(fraction * 100)
''',
        fix=[("int(fraction * 100)", "round(fraction * 100)")],
        tests=r'''from solution import @@F@@


def test_problem_value():
    assert @@F@@(@@V@@) == @@E@@


def test_zero():
    assert @@F@@(0) == 0


def test_one():
    assert @@F@@(1) == 100


def test_half():
    assert @@F@@(0.5) == 50
''',
        variants=[
            dict(F="to_percent", V="0.29", E="29"),
            dict(F="as_percentage", V="0.57", E="57"),
            dict(F="percent_of", V="0.58", E="58"),
            dict(F="fraction_to_percent", V="1.13", E="113"),
        ],
    ),
    # ------------------------------------------------------------ string handling
    dict(
        id="normalised-equality",
        category="string_handling",
        difficulty="easy",
        spec="Return True when a and b are equal @@DOC@@.",
        buggy=r'''def @@F@@(a, b):
    """@@SPEC@@"""
    return a == b
''',
        fix=[("return a == b", "return a@@N@@ == b@@N@@")],
        tests=r'''from solution import @@F@@


def test_equal_after_normalising():
    assert @@F@@(@@X@@, @@Y@@) is True


def test_different_words():
    assert @@F@@("apple", "orange") is False


def test_identical_strings():
    assert @@F@@("same", "same") is True
''',
        variants=[
            dict(F="same_word", N=".lower()", DOC="ignoring letter case", X='"Hello"', Y='"hello"'),
            dict(F="same_code", N=".upper()", DOC="ignoring letter case", X='"abc"', Y='"ABC"'),
            dict(F="same_name", N=".strip().lower()", DOC="ignoring case and surrounding whitespace", X='" Hi "', Y='"hi"'),
            dict(F="same_text", N=".casefold()", DOC="ignoring case differences, including the German sharp s", X='"Straße"', Y='"STRASSE"'),
        ],
    ),
    dict(
        id="palindrome",
        category="string_handling",
        difficulty="medium",
        spec="Return True when text reads the same forwards and backwards, ignoring case, spaces and punctuation.",
        buggy=r'''def @@F@@(text):
    """@@SPEC@@"""
    return text == text[::-1]
''',
        fix=[
            (
                "    return text == text[::-1]",
                "    cleaned = [c.lower() for c in text if c.isalnum()]\n    return cleaned == cleaned[::-1]",
            )
        ],
        tests=r'''from solution import @@F@@


def test_phrase_with_punctuation():
    assert @@F@@("@@P@@") is True


def test_not_a_palindrome():
    assert @@F@@("hello world") is False


def test_empty_string():
    assert @@F@@("") is True


def test_near_miss():
    assert @@F@@("abca") is False
''',
        variants=[
            dict(F="is_palindrome", P="A man, a plan, a canal: Panama"),
            dict(F="reads_same_both_ways", P="No lemon, no melon"),
            dict(F="is_mirror_text", P="Was it a car or a cat I saw"),
            dict(F="palindromic", P="Madam, I'm Adam"),
        ],
    ),
    dict(
        id="word-count",
        category="string_handling",
        difficulty="medium",
        spec=(
            "Count the words in text that satisfy this condition: @@DESC@@. "
            "Words are separated by any amount of whitespace (spaces, tabs, newlines)."
        ),
        buggy=r'''def @@F@@(text):
    """@@SPEC@@"""
    return len([w for w in text.split(" ") if @@COND@@])
''',
        fix=[('text.split(" ")', "text.split()")],
        tests=r'''from solution import @@F@@


def reference(text):
    return sum(1 for w in text.split() if @@COND@@)


def test_multiple_spaces_and_tabs():
    text = "@@TEXT@@"
    assert @@F@@(text) == reference(text)


def test_empty_string():
    assert @@F@@("") == 0


def test_plain_sentence():
    assert @@F@@("Hello World Today") == reference("Hello World Today")


def test_padded_text():
    assert @@F@@("  Padded  ") == reference("  Padded  ")
''',
        variants=[
            dict(F="count_words", COND="True", DESC="every word", TEXT=r"a   b"),
            dict(F="count_long_words", COND="len(w) > 3", DESC="longer than 3 characters", TEXT=r"long  words\tfive"),
            dict(F="count_alpha_words", COND="w.isalpha()", DESC="made only of letters", TEXT=r"ab  cd\tef"),
            dict(F="count_capitalised", COND="w[0].isupper()", DESC="starting with an uppercase letter", TEXT=r"Hello  World\tToday"),
        ],
    ),
    dict(
        id="word-frequency",
        category="string_handling",
        difficulty="medium",
        spec="Return a dict mapping each word of text, normalised with str.@@N@@(), to the number of times it occurs.",
        buggy=r'''def @@F@@(text):
    """@@SPEC@@"""
    counts = {}
    for word in text.split():
        counts[word] = counts.get(word, 0) + 1
    return counts
''',
        fix=[
            (
                "counts[word] = counts.get(word, 0) + 1",
                "key = word.@@N@@()\n        counts[key] = counts.get(key, 0) + 1",
            )
        ],
        tests=r'''from solution import @@F@@


def test_mixed_case_words():
    assert @@F@@("@@TEXT@@") == @@EXPECT@@


def test_empty_text():
    assert @@F@@("") == {}


def test_simple_repeat():
    assert @@F@@("a b a") == @@EXPECT2@@
''',
        variants=[
            dict(F="word_counts", N="lower", TEXT="The the THE cat", EXPECT='{"the": 3, "cat": 1}', EXPECT2='{"a": 2, "b": 1}'),
            dict(F="shout_counts", N="upper", TEXT="The the THE cat", EXPECT='{"THE": 3, "CAT": 1}', EXPECT2='{"A": 2, "B": 1}'),
            dict(F="folded_counts", N="casefold", TEXT="Straße strasse STRASSE", EXPECT='{"strasse": 3}', EXPECT2='{"a": 2, "b": 1}'),
            dict(F="title_counts", N="title", TEXT="hello HELLO Hello world", EXPECT='{"Hello": 3, "World": 1}', EXPECT2='{"A": 2, "B": 1}'),
        ],
    ),
    dict(
        id="duration-format",
        category="string_handling",
        difficulty="easy",
        spec="Format a number of seconds as minutes@@SEP@@seconds with the seconds zero-padded to two digits (65 becomes 1@@SEP@@05).",
        buggy=r'''def @@F@@(seconds):
    """@@SPEC@@"""
    return f"{seconds // 60}@@SEP@@{seconds % 60}"
''',
        fix=[("{seconds % 60}", "{seconds % 60:02d}")],
        tests=r'''from solution import @@F@@


def test_pads_single_digit_seconds():
    assert @@F@@(65) == "1@@SEP@@05"


def test_zero():
    assert @@F@@(0) == "0@@SEP@@00"


def test_whole_minutes():
    assert @@F@@(600) == "10@@SEP@@00"


def test_under_a_minute():
    assert @@F@@(59) == "0@@SEP@@59"
''',
        variants=[
            dict(F="format_duration", SEP=":"),
            dict(F="clock_text", SEP="-"),
            dict(F="lap_time", SEP="."),
            dict(F="timer_label", SEP="_"),
        ],
    ),
    dict(
        id="title-words",
        category="string_handling",
        difficulty="easy",
        spec="Capitalise the first letter of every '@@SEP@@'-separated word of text and lowercase the rest of each word.",
        buggy=r'''def @@F@@(text):
    """@@SPEC@@"""
    return text.capitalize()
''',
        fix=[
            (
                "return text.capitalize()",
                'return "@@SEP@@".join(w.capitalize() for w in text.split("@@SEP@@"))',
            )
        ],
        tests=r'''from solution import @@F@@


def test_two_words():
    assert @@F@@("hello@@SEP@@wORLD") == "Hello@@SEP@@World"


def test_empty():
    assert @@F@@("") == ""


def test_single_word():
    assert @@F@@("single") == "Single"


def test_three_words():
    assert @@F@@("ABC@@SEP@@def@@SEP@@gHi") == "Abc@@SEP@@Def@@SEP@@Ghi"
''',
        variants=[
            dict(F="title_words", SEP=" "),
            dict(F="title_kebab", SEP="-"),
            dict(F="title_snake", SEP="_"),
            dict(F="title_list", SEP=","),
        ],
    ),
    # --------------------------------------------------------- state / mutation
    dict(
        id="mutable-default",
        category="state_mutation",
        difficulty="medium",
        spec=(
            "Append the transformed item (@@DOC@@) to bucket and return bucket; "
            "when no bucket is given, start from a fresh empty list on every call."
        ),
        buggy=r'''def @@F@@(item, bucket=[]):
    """@@SPEC@@"""
    bucket.append(@@W@@)
    return bucket
''',
        fix=[
            (
                "def @@F@@(item, bucket=[]):",
                "def @@F@@(item, bucket=None):",
            ),
            (
                "    bucket.append(@@W@@)",
                "    if bucket is None:\n        bucket = []\n    bucket.append(@@W@@)",
            ),
        ],
        tests=r'''from solution import @@F@@


def test_fresh_list_each_call():
    assert @@F@@(@@A@@) == [@@EA@@]
    assert @@F@@(@@B@@) == [@@EB@@]


def test_uses_the_list_it_is_given():
    existing = [0]
    assert @@F@@(@@A@@, existing) is existing
    assert existing == [0, @@EA@@]
''',
        variants=[
            dict(F="add_item", W="item", DOC="unchanged", A='"a"', B='"b"', EA='"a"', EB='"b"'),
            dict(F="collect_text", W="str(item)", DOC="converted to text", A="1", B="2", EA='"1"', EB='"2"'),
            dict(F="record_double", W="item * 2", DOC="doubled", A="1", B="2", EA="2", EB="4"),
            dict(F="push_negative", W="-item", DOC="negated", A="3", B="4", EA="-3", EB="-4"),
        ],
    ),
    dict(
        id="fifo-queue",
        category="state_mutation",
        difficulty="easy",
        spec="A first-in, first-out queue: pop removes and returns the oldest item and raises IndexError when empty.",
        buggy=r'''class @@C@@:
    """@@SPEC@@"""

    def __init__(self):
        self._items = []

    def push(self, item):
        self._items.append(item)

    def pop(self):
        return self._items.pop()

    def __len__(self):
        return len(self._items)
''',
        fix=[("return self._items.pop()", "return self._items.pop(0)")],
        tests=r'''import pytest

from solution import @@C@@


def test_first_in_first_out():
    queue = @@C@@()
    for value in (1, 2, 3):
        queue.push(value)
    assert queue.pop() == 1
    assert queue.pop() == 2


def test_length_tracks_contents():
    queue = @@C@@()
    queue.push("a")
    queue.push("b")
    queue.pop()
    assert len(queue) == 1


def test_pop_from_empty_raises():
    with pytest.raises(IndexError):
        @@C@@().pop()
''',
        variants=[
            dict(C="Queue"),
            dict(C="TaskQueue"),
            dict(C="MessageQueue"),
            dict(C="JobQueue"),
        ],
    ),
    dict(
        id="overdraft-limit",
        category="state_mutation",
        difficulty="medium",
        spec=(
            "An account whose balance may be overdrawn by at most @@L@@: a withdrawal that would "
            "take the balance below -@@L@@ raises ValueError and leaves the balance unchanged."
        ),
        buggy=r'''class @@C@@:
    """@@SPEC@@"""

    def __init__(self, balance=0):
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("deposit must be positive")
        self.balance += amount

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("withdrawal must be positive")
        self.balance -= amount
''',
        fix=[
            (
                '            raise ValueError("withdrawal must be positive")\n',
                '            raise ValueError("withdrawal must be positive")\n'
                "        if amount > self.balance + @@L@@:\n"
                '            raise ValueError("insufficient funds")\n',
            )
        ],
        tests=r'''import pytest

from solution import @@C@@


def test_withdraw_within_balance():
    account = @@C@@(100)
    account.withdraw(40)
    assert account.balance == 60


def test_overdraft_up_to_the_limit_is_allowed():
    account = @@C@@(100)
    account.withdraw(100 + @@L@@)
    assert account.balance == -@@L@@


def test_overdraft_beyond_the_limit_is_rejected():
    account = @@C@@(100)
    with pytest.raises(ValueError):
        account.withdraw(100 + @@L@@ + 1)
    assert account.balance == 100


def test_deposit():
    account = @@C@@()
    account.deposit(25)
    assert account.balance == 25


def test_non_positive_withdrawal_rejected():
    with pytest.raises(ValueError):
        @@C@@(10).withdraw(0)
''',
        variants=[
            dict(C="Account", L="0"),
            dict(C="CheckingAccount", L="50"),
            dict(C="WalletAccount", L="100"),
            dict(C="SavingsAccount", L="200"),
        ],
    ),
    # ----------------------------------------------------------------- collections
    dict(
        id="dict-default",
        category="collections",
        difficulty="easy",
        spec="Return mapping[key], or @@D@@ when the key is missing.",
        buggy=r'''def @@F@@(mapping, key):
    """@@SPEC@@"""
    return mapping[key]
''',
        fix=[("return mapping[key]", "return mapping.get(key, @@D@@)")],
        tests=r'''from solution import @@F@@


def test_missing_key_uses_default():
    assert @@F@@({}, "a") == @@D@@


def test_present_key():
    assert @@F@@({"a": 1}, "a") == 1


def test_other_key_present():
    assert @@F@@({"b": 2}, "a") == @@D@@
''',
        variants=[
            dict(F="lookup_count", D="0"),
            dict(F="lookup_label", D='"n/a"'),
            dict(F="lookup_index", D="-1"),
            dict(F="lookup_optional", D="None"),
        ],
    ),
    dict(
        id="top-n",
        category="collections",
        difficulty="easy",
        spec="Return the n largest values in descending order (n defaults to @@N@@) without modifying the input list.",
        buggy=r'''def @@F@@(values, n=@@N@@):
    """@@SPEC@@"""
    return sorted(values)[:n]
''',
        fix=[("sorted(values)[:n]", "sorted(values, reverse=True)[:n]")],
        tests=r'''from solution import @@F@@

VALUES = [5, 1, 9, 3, 7, 2, 8]


def test_default_count():
    assert @@F@@(VALUES) == sorted(VALUES, reverse=True)[:@@N@@]


def test_explicit_count():
    assert @@F@@(VALUES, 2) == [9, 8]


def test_empty_input():
    assert @@F@@([]) == []


def test_input_is_not_modified():
    data = list(VALUES)
    @@F@@(data)
    assert data == VALUES
''',
        variants=[
            dict(F="top_values", N="1"),
            dict(F="largest", N="2"),
            dict(F="best_scores", N="3"),
            dict(F="leaderboard", N="5"),
        ],
    ),
    dict(
        id="deep-flatten",
        category="collections",
        difficulty="medium",
        spec="Return a flat list of every non-list value in items, however deeply the lists are nested.",
        buggy=r'''def @@F@@(items):
    """@@SPEC@@"""
    result = []
    for item in items:
        if isinstance(item, list):
            result.extend(item)
        else:
            result.append(item)
    return result
''',
        fix=[("result.extend(item)", "result.extend(@@F@@(item))")],
        tests=r'''from solution import @@F@@


def test_one_level():
    assert @@F@@([1, [2, 3], 4]) == [1, 2, 3, 4]


def test_deep_nesting():
    assert @@F@@([1, [2, [3, [4]]]]) == [1, 2, 3, 4]


def test_empty_list():
    assert @@F@@([]) == []


def test_only_empty_lists():
    assert @@F@@([[[]]]) == []
''',
        variants=[
            dict(F="flatten"),
            dict(F="flatten_all"),
            dict(F="deep_flatten"),
            dict(F="unnest"),
        ],
    ),
    dict(
        id="ordered-unique",
        category="collections",
        difficulty="easy",
        spec="Return values with duplicates removed, keeping the first occurrence of each value in its original order.",
        buggy=r'''def @@F@@(values):
    """@@SPEC@@"""
    return list(set(values))
''',
        fix=[
            (
                "    return list(set(values))",
                "    seen = set()\n    result = []\n    for v in values:\n        if v not in seen:\n            seen.add(v)\n            result.append(v)\n    return result",
            )
        ],
        tests=r'''from solution import @@F@@


def test_keeps_first_occurrence_order():
    assert @@F@@([3, 1, 3, 2, 1]) == [3, 1, 2]


def test_all_equal():
    assert @@F@@([5, 5, 5]) == [5]


def test_empty():
    assert @@F@@([]) == []


def test_already_unique():
    assert @@F@@([9, 4, 7]) == [9, 4, 7]
''',
        variants=[
            dict(F="dedupe_keep_order"),
            dict(F="unique_in_order"),
            dict(F="drop_repeats"),
            dict(F="distinct"),
        ],
    ),
    dict(
        id="transpose",
        category="collections",
        difficulty="medium",
        spec="Return the transpose of a rectangular matrix given as a list of equal-length rows.",
        buggy=r'''def @@F@@(matrix):
    """@@SPEC@@"""
    size = len(matrix)
    return [[matrix[i][j] for i in range(size)] for j in range(size)]
''',
        fix=[
            (
                "    size = len(matrix)\n    return [[matrix[i][j] for i in range(size)] for j in range(size)]",
                "    rows = len(matrix)\n    cols = len(matrix[0]) if matrix else 0\n    return [[matrix[i][j] for i in range(rows)] for j in range(cols)]",
            )
        ],
        tests=r'''from solution import @@F@@


def make(rows, cols):
    return [[r * cols + c for c in range(cols)] for r in range(rows)]


def test_rectangular_matrix():
    m = make(@@ROWS@@, @@COLS@@)
    assert @@F@@(m) == [list(col) for col in zip(*m)]


def test_square_matrix():
    m = make(3, 3)
    assert @@F@@(m) == [list(col) for col in zip(*m)]


def test_empty_matrix():
    assert @@F@@([]) == []


def test_single_cell():
    assert @@F@@([[1]]) == [[1]]
''',
        variants=[
            dict(F="transpose", ROWS="2", COLS="3"),
            dict(F="flip_axes", ROWS="3", COLS="2"),
            dict(F="rows_to_columns", ROWS="1", COLS="4"),
            dict(F="swap_rows_cols", ROWS="4", COLS="1"),
        ],
    ),
    # -------------------------------------------------------------- error handling
    dict(
        id="safe-parse",
        category="error_handling",
        difficulty="easy",
        spec="Convert text to an int; return @@D@@ when text is not a valid integer (including None and empty text).",
        buggy=r'''def @@F@@(text):
    """@@SPEC@@"""
    return int(text)
''',
        fix=[
            (
                "    return int(text)",
                "    try:\n        return int(text)\n    except (TypeError, ValueError):\n        return @@D@@",
            )
        ],
        tests=r'''from solution import @@F@@


def test_valid_numbers():
    assert @@F@@("42") == 42
    assert @@F@@("-7") == -7


def test_invalid_text():
    assert @@F@@("abc") == @@D@@


def test_empty_text():
    assert @@F@@("") == @@D@@


def test_none_input():
    assert @@F@@(None) == @@D@@


def test_decimal_text_is_not_an_int():
    assert @@F@@("3.5") == @@D@@
''',
        variants=[
            dict(F="parse_int", D="0"),
            dict(F="to_int_or_minus_one", D="-1"),
            dict(F="read_count", D="99"),
            dict(F="maybe_int", D="None"),
        ],
    ),
]
