"""Builds, validates, exports and loads the task bank."""

from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .models import Task
from .sandbox import Sandbox
from .templates import TEMPLATES

DECOY_HELPERS = '''"""Utility helpers (unrelated to the bug)."""


def identity(value):
    return value
'''


def _sub(text: str, subs: dict[str, str]) -> str:
    for key, value in subs.items():
        text = text.replace(f"@@{key}@@", value)
    return text


def _render(template: dict, index: int, variant: dict[str, str]) -> Task:
    subs = dict(variant)
    subs["SPEC"] = _sub(template["spec"], subs)
    buggy = _sub(template["buggy"], subs)
    fixed = buggy
    for old, new in template["fix"]:
        old, new = _sub(old, subs), _sub(new, subs)
        if fixed.count(old) != 1:
            raise ValueError(f"{template['id']}: fix target {old!r} must appear exactly once")
        fixed = fixed.replace(old, new)
    tests = _sub(template["tests"], subs)
    description = (
        "Fix the bug in `solution.py` so that every test in `tests/test_solution.py` passes. "
        f"Expected behaviour: {subs['SPEC']}"
    )
    return Task(
        task_id=f"{template['id']}-{index + 1:02d}",
        category=template["category"],
        difficulty=template["difficulty"],
        description=description,
        files={"solution.py": buggy, "helpers.py": DECOY_HELPERS},
        tests={"tests/test_solution.py": tests},
        solution={"solution.py": fixed, "helpers.py": DECOY_HELPERS},
    )


def build_task_bank() -> list[Task]:
    tasks = [
        _render(template, i, variant)
        for template in TEMPLATES
        for i, variant in enumerate(template["variants"])
    ]
    ids = [t.task_id for t in tasks]
    if len(ids) != len(set(ids)):
        raise ValueError("duplicate task ids in the bank")
    return tasks


def validate_task(task: Task) -> list[str]:
    """Return a list of problems; empty means the task is sound.

    A sound task fails on its buggy files, passes on the reference solution and
    has the number of tests it declares.
    """
    problems: list[str] = []
    if not task.target_files:
        return ["solution does not differ from the buggy files"]
    with Sandbox(task) as buggy:
        before = buggy.run_tests()
    if before.all_passed:
        problems.append("tests already pass on the buggy files")
    if before.timed_out:
        problems.append("tests hang on the buggy files")
    fixed_task = Task(
        task_id=task.task_id,
        category=task.category,
        difficulty=task.difficulty,
        description=task.description,
        files=task.solution,
        tests=task.tests,
        solution=task.solution,
    )
    with Sandbox(fixed_task) as fixed:
        after = fixed.run_tests()
    if not after.all_passed:
        problems.append(f"reference solution does not pass: {after.summary()}")
    elif after.total != task.expected_tests:
        problems.append(f"declared {task.expected_tests} tests but ran {after.total}")
    return problems


def validate_bank(tasks: list[Task], workers: int = 4) -> dict[str, list[str]]:
    """Validate every task; returns {task_id: problems} for tasks with problems."""
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        results = list(pool.map(validate_task, tasks))
    return {t.task_id: p for t, p in zip(tasks, results) if p}


def export_tasks(tasks: list[Task], directory: str | Path) -> int:
    """Write each task as ``<task_id>.json`` so the bank can be inspected or extended."""
    out = Path(directory)
    out.mkdir(parents=True, exist_ok=True)
    for task in tasks:
        (out / f"{task.task_id}.json").write_text(
            json.dumps(task.to_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
    return len(tasks)


def load_tasks(directory: str | Path) -> list[Task]:
    return [
        Task.from_dict(json.loads(p.read_text(encoding="utf-8")))
        for p in sorted(Path(directory).glob("*.json"))
    ]


def select_tasks(
    tasks: list[Task],
    categories: list[str] | None = None,
    task_ids: list[str] | None = None,
    limit: int | None = None,
) -> list[Task]:
    chosen = tasks
    if categories:
        chosen = [t for t in chosen if t.category in categories]
    if task_ids:
        chosen = [t for t in chosen if t.task_id in task_ids]
    return chosen[:limit] if limit else chosen
