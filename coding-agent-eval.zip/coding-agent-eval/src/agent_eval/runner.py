"""Runs agents on tasks, grades them, and records experiments to disk."""

from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path

from . import __version__
from .agents import AgentOutcome, Budget, build_agent
from .failures import classify
from .models import AgentConfig, RunResult, Task
from .sandbox import Sandbox
from .tools import ToolBox


def run_task(
    task: Task, config: AgentConfig, run_id: str, seed: int | str = 0, repeat: int = 0
) -> tuple[RunResult, list[dict]]:
    """Run one agent on one task in a fresh sandbox; return (result, trajectory)."""
    with Sandbox(task) as sandbox:
        initial = sandbox.run_tests()
        toolbox = ToolBox(sandbox)
        budget = Budget(config.max_steps, config.wall_timeout_s)
        started = time.perf_counter()
        try:
            agent = build_agent(config, seed=seed, repeat=repeat)
            outcome = agent.solve(task, toolbox, budget, initial)
        except Exception as exc:  # any agent/client failure becomes a graded error
            outcome = AgentOutcome("error", error=f"{type(exc).__name__}: {exc}")
        duration = time.perf_counter() - started

        sandbox.restore_tests()  # grade against the original tests only
        edited = sandbox.edited_files()
        final = sandbox.run_tests()
        resolved = final.all_passed
        failure = classify(
            task, toolbox.events, outcome.stop_reason, initial, final, edited, resolved
        )
        result = RunResult(
            run_id=run_id,
            task_id=task.task_id,
            category=task.category,
            difficulty=task.difficulty,
            config_name=config.name,
            repeat=repeat,
            resolved=resolved,
            tests_total=final.total,
            tests_passed=final.passed,
            pass_rate=(final.passed / final.total) if final.total else 0.0,
            failure_type=failure.value,
            stop_reason=outcome.stop_reason,
            steps=len(toolbox.events),
            tool_calls=len(toolbox.events),
            valid_tool_calls=toolbox.valid_calls,
            duration_s=duration,
            input_tokens=outcome.input_tokens,
            output_tokens=outcome.output_tokens,
            files_edited=edited,
            error=outcome.error,
        )
        trajectory = [event.to_dict() for event in toolbox.events]
    return result, trajectory


def make_run_id(configs: list[AgentConfig], seed: int | str, task_ids: list[str]) -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    digest = hashlib.sha256(
        json.dumps([c.to_dict() for c in configs] + [seed, task_ids], sort_keys=True).encode()
    ).hexdigest()[:8]
    return f"{stamp}-{digest}"


def _git_commit() -> str | None:
    try:
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], capture_output=True, text=True, timeout=5
        )
        return out.stdout.strip() or None if out.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def run_suite(
    tasks: list[Task],
    configs: list[AgentConfig],
    out_dir: str | Path,
    seed: int | str = 0,
    repeats: int = 1,
    workers: int = 2,
) -> Path:
    """Run every (config, task, repeat) combination and write the experiment record.

    Output layout: ``<out_dir>/<run_id>/{manifest.json, results.jsonl, trajectories.jsonl}``.
    """
    run_id = make_run_id(configs, seed, [t.task_id for t in tasks])
    run_dir = Path(out_dir) / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "run_id": run_id,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "seed": seed,
        "repeats": repeats,
        "configs": [c.to_dict() for c in configs],
        "task_ids": [t.task_id for t in tasks],
        "agent_eval_version": __version__,
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "git_commit": _git_commit(),
        "simulated": any(c.kind == "mock" for c in configs),
    }
    jobs = [
        (task, config, repeat)
        for config in configs
        for repeat in range(repeats)
        for task in tasks
    ]
    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        outputs = list(
            pool.map(lambda j: run_task(j[0], j[1], run_id, seed, j[2]), jobs)
        )
    with (run_dir / "results.jsonl").open("w", encoding="utf-8") as results, (
        run_dir / "trajectories.jsonl"
    ).open("w", encoding="utf-8") as trajectories:
        for (result, trajectory), (task, config, repeat) in zip(outputs, jobs):
            results.write(json.dumps(result.to_dict()) + "\n")
            trajectories.write(
                json.dumps(
                    {
                        "task_id": task.task_id,
                        "config": config.name,
                        "repeat": repeat,
                        "events": trajectory,
                    }
                )
                + "\n"
            )
    manifest["finished_at"] = datetime.now(timezone.utc).isoformat()
    manifest["runs"] = len(outputs)
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return run_dir


def load_results(run_dir: str | Path) -> list[RunResult]:
    path = Path(run_dir) / "results.jsonl"
    return [
        RunResult.from_dict(json.loads(line))
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip()
    ]


def load_manifest(run_dir: str | Path) -> dict:
    return json.loads((Path(run_dir) / "manifest.json").read_text(encoding="utf-8"))
