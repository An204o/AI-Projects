"""Aggregate metrics and small statistical helpers (standard library only)."""

from __future__ import annotations

import math
import random
import statistics
from collections import Counter, defaultdict
from typing import Iterable

from .models import RunResult


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Wilson score interval for a proportion (95% by default)."""
    if n == 0:
        return (0.0, 0.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def mcnemar_exact(only_a: int, only_b: int) -> float:
    """Two-sided exact McNemar p-value from the discordant pair counts."""
    n = only_a + only_b
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, k) for k in range(0, min(only_a, only_b) + 1))
    return min(1.0, 2 * tail / 2**n)


def bootstrap_ci(
    values: list[float], iterations: int = 2000, alpha: float = 0.05, seed: int = 0
) -> tuple[float, float]:
    """Percentile bootstrap confidence interval for the mean."""
    if not values:
        return (0.0, 0.0)
    rng = random.Random(seed)
    means = sorted(
        statistics.fmean(rng.choices(values, k=len(values))) for _ in range(iterations)
    )
    low = means[int((alpha / 2) * iterations)]
    high = means[min(iterations - 1, int((1 - alpha / 2) * iterations))]
    return (low, high)


def percentile(values: list[float], q: float) -> float:
    """Linear-interpolated percentile, ``q`` in [0, 100]."""
    if not values:
        return 0.0
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q / 100
    lower, upper = math.floor(pos), math.ceil(pos)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (pos - lower)


def summarize(results: Iterable[RunResult]) -> dict:
    """Summary statistics for a set of runs (normally one configuration)."""
    runs = list(results)
    n = len(runs)
    if n == 0:
        return {"runs": 0}
    resolved = sum(r.resolved for r in runs)
    low, high = wilson_interval(resolved, n)
    calls = sum(r.tool_calls for r in runs)
    valid = sum(r.valid_tool_calls for r in runs)
    durations = [r.duration_s for r in runs]
    pass_rates = [r.pass_rate for r in runs]
    return {
        "runs": n,
        "resolved": resolved,
        "resolve_rate": resolved / n,
        "resolve_ci": (low, high),
        "mean_pass_rate": statistics.fmean(pass_rates),
        "pass_rate_ci": bootstrap_ci(pass_rates),
        "tool_calls": calls,
        "tool_call_accuracy": (valid / calls) if calls else None,
        "mean_duration_s": statistics.fmean(durations),
        "median_duration_s": statistics.median(durations),
        "p90_duration_s": percentile(durations, 90),
        "mean_steps": statistics.fmean(r.steps for r in runs),
        "input_tokens": sum(r.input_tokens for r in runs),
        "output_tokens": sum(r.output_tokens for r in runs),
        "failure_counts": dict(Counter(r.failure_type for r in runs if not r.resolved)),
    }


def by_category(results: Iterable[RunResult]) -> dict[str, dict]:
    groups: dict[str, list[RunResult]] = defaultdict(list)
    for r in results:
        groups[r.category].append(r)
    return {cat: summarize(rs) for cat, rs in sorted(groups.items())}


def paired_comparison(a: list[RunResult], b: list[RunResult]) -> dict:
    """Compare two configurations on the tasks (and repeats) they share."""
    key = lambda r: (r.task_id, r.repeat)  # noqa: E731
    a_map = {key(r): r.resolved for r in a}
    b_map = {key(r): r.resolved for r in b}
    shared = sorted(set(a_map) & set(b_map))
    only_a = sum(1 for k in shared if a_map[k] and not b_map[k])
    only_b = sum(1 for k in shared if b_map[k] and not a_map[k])
    return {
        "paired_runs": len(shared),
        "only_a_resolved": only_a,
        "only_b_resolved": only_b,
        "both_resolved": sum(1 for k in shared if a_map[k] and b_map[k]),
        "neither_resolved": sum(1 for k in shared if not a_map[k] and not b_map[k]),
        "p_value": mcnemar_exact(only_a, only_b),
    }
