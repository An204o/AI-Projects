"""Provider-neutral chat interface plus an Anthropic implementation.

The agent loop only depends on :class:`ChatClient`, so it can be tested with a
scripted client and run for real with :class:`AnthropicChatClient`.
Messages and content blocks use the Anthropic Messages API format.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass
class ToolCall:
    id: str
    name: str
    args: Any


@dataclass
class AssistantTurn:
    """One model response: raw content blocks, parsed tool calls and token usage."""

    blocks: list[dict[str, Any]]
    tool_calls: list[ToolCall] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    stop_reason: str = ""

    @property
    def text(self) -> str:
        return "".join(b.get("text", "") for b in self.blocks if b.get("type") == "text")


class ChatClient(Protocol):
    def complete(
        self, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> AssistantTurn: ...


class AnthropicChatClient:
    """Calls the Anthropic Messages API (requires ``pip install anthropic``).

    Pass ``sdk_client`` to inject a pre-built (or fake) SDK client; otherwise one
    is created from the ``ANTHROPIC_API_KEY`` environment variable.
    """

    def __init__(
        self,
        model: str,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        sdk_client: Any = None,
    ):
        if sdk_client is None:
            try:
                import anthropic
            except ImportError as exc:  # pragma: no cover - depends on environment
                raise RuntimeError("install the SDK first: pip install anthropic") from exc
            sdk_client = anthropic.Anthropic()
        self._client = sdk_client
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature

    def complete(
        self, system: str, messages: list[dict[str, Any]], tools: list[dict[str, Any]]
    ) -> AssistantTurn:
        response = self._client.messages.create(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            system=system,
            messages=messages,
            tools=tools,
        )
        blocks: list[dict[str, Any]] = []
        calls: list[ToolCall] = []
        for block in response.content:
            if block.type == "text":
                blocks.append({"type": "text", "text": block.text})
            elif block.type == "tool_use":
                blocks.append(
                    {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
                )
                calls.append(ToolCall(id=block.id, name=block.name, args=block.input))
        usage = getattr(response, "usage", None)
        return AssistantTurn(
            blocks=blocks,
            tool_calls=calls,
            input_tokens=getattr(usage, "input_tokens", 0) or 0,
            output_tokens=getattr(usage, "output_tokens", 0) or 0,
            stop_reason=getattr(response, "stop_reason", "") or "",
        )
