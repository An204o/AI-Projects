"""Core data structures shared across the framework."""

from __future__ import annotations

import ast
import enum
from dataclasses import asdict, dataclass, field
from typing import Any


class FailureType(str, enum.Enum):
    """Why an agent run did not resolve its task (see failures.classify)."""

    NONE = "none"
    NO_EDIT = "no_edit"
    TOOL_MISUSE = "tool_misuse"
    CONTEXT_MISS = "context_miss"
    SYNTAX_ERROR = "syntax_error"
    REGRESSION = "regression"
    NO_RECOVERY = "no_recovery"
    BAD_PATCH = "bad_patch"
    STEP_LIMIT = "step_limit"
    TIMEOUT = "timeout"
    AGENT_ERROR = "agent_error"


# Which capability each failure type points at. Used by the report.
FAILURE_AREA: dict[str, str] = {
    FailureType.NONE.value: "-",
    FailureType.NO_EDIT.value: "task understanding",
    FailureType.TOOL_MISUSE.value: "tool selection",
    FailureType.CONTEXT_MISS.value: "context construction",
    FailureType.SYNTAX_ERROR.value: "code generation",
    FailureType.REGRESSION.value: "code generation",
    FailureType.NO_RECOVERY.value: "error recovery",
    FailureType.BAD_PATCH.value: "code generation",
    FailureType.STEP_LIMIT.value: "planning / efficiency",
    FailureType.TIMEOUT.value: "planning / efficiency",
    FailureType.AGENT_ERROR.value: "infrastructure",
}

CONTEXT_MODES = ("none", "tree", "tests", "failing_output", "full")
AGENT_KINDS = ("mock", "llm")
MOCK_PROFILES = ("strong", "medium", "weak")


def count_tests(tests: dict[str, str]) -> int:
    """Count test functions (``test_*``) in the given test sources."""
    total = 0
    for source in tests.values():
        tree = ast.parse(source)
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name.startswith("test_"):
                total += 1
            elif isinstance(node, ast.ClassDef) and node.name.startswith("Test"):
                total += sum(
                    1
                    for item in node.body
                    if isinstance(item, ast.FunctionDef) and item.name.startswith("test_")
                )
    return total


@dataclass(frozen=True)
class Task:
    """A buggy mini-project, its tests, and a reference solution.

    ``files`` are the (buggy) source files the agent can see and edit.
    ``tests`` are read-only for the agent and restored before grading.
    ``solution`` is the reference fix. It is used to validate the task and by
    the offline mock agent only; real agents never see it.
    """

    task_id: str
    category: str
    difficulty: str
    description: str
    files: dict[str, str]
    tests: dict[str, str]
    solution: dict[str, str]

    @property
    def target_files(self) -> tuple[str, ...]:
        """Files that differ between the buggy project and the reference fix."""
        return tuple(sorted(p for p, c in self.solution.items() if self.files.get(p) != c))

    @property
    def expected_tests(self) -> int:
        return count_tests(self.tests)

    def to_dict(self) -> dict[str, Any]:
        return {
            "task_id": self.task_id,
            "category": self.category,
            "difficulty": self.difficulty,
            "description": self.description,
            "files": self.files,
            "tests": self.tests,
            "solution": self.solution,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Task":
        return cls(
            task_id=data["task_id"],
            category=data["category"],
            difficulty=data.get("difficulty", "easy"),
            description=data["description"],
            files=dict(data["files"]),
            tests=dict(data["tests"]),
            solution=dict(data["solution"]),
        )


@dataclass(frozen=True)
class AgentConfig:
    """One agent configuration to evaluate."""

    name: str
    kind: str = "mock"  # "mock" (offline simulation) or "llm" (real model)
    profile: str = "medium"  # mock only: strong | medium | weak
    model: str | None = None  # llm only: the model identifier to call
    context_mode: str = "tree"  # llm only: what the first prompt contains
    max_steps: int = 20
    wall_timeout_s: float = 300.0
    temperature: float = 0.0
    max_tokens: int = 4096

    _ALLOWED = (
        "name",
        "kind",
        "profile",
        "model",
        "context_mode",
        "max_steps",
        "wall_timeout_s",
        "temperature",
        "max_tokens",
    )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AgentConfig":
        unknown = set(data) - set(cls._ALLOWED)
        if unknown:
            raise ValueError(f"unknown config keys: {sorted(unknown)}")
        if "name" not in data or not data["name"]:
            raise ValueError("every config needs a non-empty 'name'")
        config = cls(**data)
        if config.kind not in AGENT_KINDS:
            raise ValueError(f"{config.name}: kind must be one of {AGENT_KINDS}")
        if config.kind == "mock" and config.profile not in MOCK_PROFILES:
            raise ValueError(f"{config.name}: profile must be one of {MOCK_PROFILES}")
        if config.context_mode not in CONTEXT_MODES:
            raise ValueError(f"{config.name}: context_mode must be one of {CONTEXT_MODES}")
        if config.max_steps < 1:
            raise ValueError(f"{config.name}: max_steps must be >= 1")
        if config.kind == "llm" and (not config.model or "YOUR_MODEL" in config.model):
            raise ValueError(f"{config.name}: set 'model' to a real model identifier")
        return config

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data.pop("_ALLOWED", None)
        return data


@dataclass
class ToolEvent:
    """One tool call made by an agent."""

    step: int
    tool: str
    args: dict[str, Any]
    ok: bool
    error: str | None
    preview: str
    duration_s: float
    meta: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class RunResult:
    """The graded outcome of one agent run on one task."""

    run_id: str
    task_id: str
    category: str
    difficulty: str
    config_name: str
    repeat: int
    resolved: bool
    tests_total: int
    tests_passed: int
    pass_rate: float
    failure_type: str
    stop_reason: str
    steps: int
    tool_calls: int
    valid_tool_calls: int
    duration_s: float
    input_tokens: int
    output_tokens: int
    files_edited: list[str]
    error: str | None = None

    @property
    def tool_call_accuracy(self) -> float | None:
        if self.tool_calls == 0:
            return None
        return self.valid_tool_calls / self.tool_calls

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["tool_call_accuracy"] = self.tool_call_accuracy
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RunResult":
        fields = {k: v for k, v in data.items() if k != "tool_call_accuracy"}
        return cls(**fields)
