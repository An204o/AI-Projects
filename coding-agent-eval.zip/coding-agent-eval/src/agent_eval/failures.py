"""Deterministic classification of why a run failed."""

from __future__ import annotations

from .models import FailureType, Task, ToolEvent
from .sandbox import TestOutcome
from .tools import EDIT_TOOLS


def classify(
    task: Task,
    events: list[ToolEvent],
    stop_reason: str,
    initial: TestOutcome,
    final: TestOutcome,
    edited_files: list[str],
    resolved: bool,
) -> FailureType:
    """Assign one failure type, checking causes in a fixed priority order.

    1. resolved                       -> NONE
    2. timeout (agent or tests)       -> TIMEOUT
    3. step budget used up            -> STEP_LIMIT
    4. agent crashed                  -> AGENT_ERROR
    5. no successful edit             -> TOOL_MISUSE if any call was invalid, else NO_EDIT
    6. edits, none in a target file   -> CONTEXT_MISS (worked on the wrong file)
    7. final run has a syntax error   -> SYNTAX_ERROR
    8. fewer tests pass than before   -> REGRESSION
    9. ended on a failing test run    -> NO_RECOVERY (saw the failure and stopped)
    10. otherwise                     -> BAD_PATCH (wrong or unverified fix)
    """
    if resolved:
        return FailureType.NONE
    if stop_reason == "timeout" or final.timed_out:
        return FailureType.TIMEOUT
    if stop_reason == "step_limit":
        return FailureType.STEP_LIMIT
    if stop_reason == "error":
        return FailureType.AGENT_ERROR

    successful_edits = [e for e in events if e.tool in EDIT_TOOLS and e.ok]
    if not successful_edits:
        if any(not e.ok for e in events):
            return FailureType.TOOL_MISUSE
        return FailureType.NO_EDIT
    if not set(edited_files) & set(task.target_files):
        return FailureType.CONTEXT_MISS
    if final.syntax_error:
        return FailureType.SYNTAX_ERROR
    if final.passed < initial.passed:
        return FailureType.REGRESSION

    last_edit = max(e.step for e in successful_edits)
    test_runs = [e for e in events if e.tool == "run_tests" and e.ok]
    if test_runs:
        last_run = max(test_runs, key=lambda e: e.step)
        if last_run.step > last_edit and not last_run.meta.get("all_passed", False):
            return FailureType.NO_RECOVERY
    return FailureType.BAD_PATCH
