import pytest

from agent_eval.models import count_tests
from agent_eval.task_bank import (
    export_tasks,
    load_tasks,
    select_tasks,
    validate_bank,
    validate_task,
)


def test_bank_has_at_least_100_unique_tasks(bank):
    assert len(bank) >= 100
    assert len({t.task_id for t in bank}) == len(bank)


def test_every_task_targets_exactly_the_solution_file(bank):
    for t in bank:
        assert t.target_files == ("solution.py",), t.task_id


def test_declared_test_counts_match_sources(bank):
    for t in bank:
        assert t.expected_tests == count_tests(t.tests) >= 2


def test_categories_cover_several_bug_families(bank):
    assert len({t.category for t in bank}) >= 8


def test_task_json_round_trip(bank, tmp_path):
    export_tasks(bank[:5], tmp_path)
    assert [t.to_dict() for t in load_tasks(tmp_path)] == [
        t.to_dict() for t in sorted(bank[:5], key=lambda t: t.task_id)
    ]


def test_select_tasks_filters(bank):
    assert {t.category for t in select_tasks(bank, categories=["numeric"])} == {"numeric"}
    assert len(select_tasks(bank, limit=3)) == 3


def test_validate_task_detects_a_task_that_already_passes(task):
    from agent_eval.models import Task

    broken = Task(**{**task.__dict__, "files": task.solution})
    assert validate_task(broken)


@pytest.mark.slow
def test_every_task_fails_when_buggy_and_passes_when_fixed(bank):
    assert validate_bank(bank, workers=2) == {}
