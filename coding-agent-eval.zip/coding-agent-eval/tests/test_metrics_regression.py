import pytest

from agent_eval.metrics import bootstrap_ci, mcnemar_exact, paired_comparison, percentile, summarize, wilson_interval
from agent_eval.models import RunResult
from agent_eval.regression import compare_runs


def result(task_id, resolved, config="a", repeat=0, failure="none", category="c", calls=4, valid=3):
    return RunResult(run_id="r", task_id=task_id, category=category, difficulty="easy",
                     config_name=config, repeat=repeat, resolved=resolved, tests_total=4,
                     tests_passed=4 if resolved else 1, pass_rate=1.0 if resolved else 0.25,
                     failure_type=failure, stop_reason="finished", steps=calls, tool_calls=calls,
                     valid_tool_calls=valid, duration_s=1.0, input_tokens=0, output_tokens=0,
                     files_edited=[])


def test_wilson_interval_known_value():
    low, high = wilson_interval(5, 10)
    assert low == pytest.approx(0.2366, abs=1e-3) and high == pytest.approx(0.7634, abs=1e-3)
    assert wilson_interval(0, 0) == (0.0, 0.0)


def test_mcnemar_exact_known_values():
    assert mcnemar_exact(0, 5) == pytest.approx(0.0625)
    assert mcnemar_exact(3, 3) == 1.0
    assert mcnemar_exact(0, 0) == 1.0


def test_percentile_and_bootstrap():
    assert percentile([1, 2, 3, 4, 5], 50) == 3
    assert percentile([1, 2, 3, 4, 5], 100) == 5
    low, high = bootstrap_ci([1.0] * 10)
    assert low == high == 1.0


def test_summarize():
    s = summarize([result("t1", True), result("t2", False, failure="bad_patch")])
    assert s["resolve_rate"] == 0.5
    assert s["tool_call_accuracy"] == 0.75
    assert s["failure_counts"] == {"bad_patch": 1}


def test_paired_comparison_counts_discordant_pairs():
    a = [result("t1", True), result("t2", True), result("t3", False)]
    b = [result("t1", False, "b"), result("t2", True, "b"), result("t3", False, "b")]
    c = paired_comparison(a, b)
    assert (c["only_a_resolved"], c["only_b_resolved"], c["both_resolved"], c["neither_resolved"]) == (1, 0, 1, 1)


def test_compare_runs_flags_regressions_improvements_and_missing():
    base = [result("t1", True), result("t2", False), result("t3", True), result("t4", True)]
    cur = [result("t1", False), result("t2", True), result("t3", True)]
    report = compare_runs(base, cur)
    assert [r[1] for r in report.regressions] == ["t1"]
    assert [r[1] for r in report.improvements] == ["t2"]
    assert report.unchanged == 1 and report.missing_in_current == [("a", "t4")]
    assert not report.passes() and not report.passes(max_regressions=5)


def test_compare_runs_tolerates_noise_with_repeats():
    base = [result("t1", r < 3, repeat=r) for r in range(4)]   # 0.75
    cur = [result("t1", r < 2, repeat=r) for r in range(4)]    # 0.50 -> delta -0.25
    assert compare_runs(base, cur, threshold=0.5).passes()
