import pytest

from agent_eval.failures import classify
from agent_eval.models import FailureType, ToolEvent
from agent_eval.sandbox import TestOutcome


def outcome(passed, total=4, syntax=False, timed_out=False):
    return TestOutcome(total=total, passed=passed, failed=total - passed, errors=0, skipped=0,
                       timed_out=timed_out, returncode=0 if passed == total else 1,
                       syntax_error=syntax, duration_s=0.1, output="")


def event(step, tool, ok=True, **meta):
    return ToolEvent(step=step, tool=tool, args={}, ok=ok, error=None if ok else "bad",
                     preview="", duration_s=0.0, meta=meta)


def run(task, events, stop="finished", initial=None, final=None, edited=("solution.py",), resolved=False):
    return classify(task, events, stop, initial or outcome(1), final or outcome(1),
                    list(edited), resolved)


def test_resolved(task):
    assert run(task, [], resolved=True) is FailureType.NONE


def test_timeouts_and_limits(task):
    assert run(task, [], stop="timeout") is FailureType.TIMEOUT
    assert run(task, [], final=outcome(0, timed_out=True)) is FailureType.TIMEOUT
    assert run(task, [], stop="step_limit") is FailureType.STEP_LIMIT
    assert run(task, [], stop="error") is FailureType.AGENT_ERROR


def test_no_edit_vs_tool_misuse(task):
    assert run(task, [event(1, "read_file")], edited=()) is FailureType.NO_EDIT
    assert run(task, [event(1, "apply_diff", ok=False)], edited=()) is FailureType.TOOL_MISUSE


def test_context_miss(task):
    events = [event(1, "write_file", edit_path="helpers.py")]
    assert run(task, events, edited=("helpers.py",)) is FailureType.CONTEXT_MISS


def test_syntax_error_and_regression(task):
    events = [event(1, "write_file")]
    assert run(task, events, final=outcome(0, syntax=True)) is FailureType.SYNTAX_ERROR
    assert run(task, events, initial=outcome(2), final=outcome(1)) is FailureType.REGRESSION


def test_no_recovery_vs_bad_patch(task):
    gave_up = [event(1, "write_file"), event(2, "run_tests", all_passed=False)]
    assert run(task, gave_up) is FailureType.NO_RECOVERY
    unverified = [event(1, "write_file")]
    assert run(task, unverified) is FailureType.BAD_PATCH
    retried = [event(1, "write_file"), event(2, "run_tests", all_passed=False), event(3, "write_file")]
    assert run(task, retried) is FailureType.BAD_PATCH
