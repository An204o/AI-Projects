import pytest

from agent_eval.sandbox import Sandbox, ToolError
from agent_eval.tools import TOOL_SPECS, ToolBox


def test_path_escape_is_rejected(task):
    with Sandbox(task) as sb:
        with pytest.raises(ToolError):
            sb.read("../etc/passwd")
        with pytest.raises(ToolError):
            sb.write("../outside.py", "x")


def test_tests_and_config_are_protected(task):
    with Sandbox(task) as sb:
        for path in ("tests/test_solution.py", "conftest.py", "pytest.ini", "src/../tests/x.py"):
            with pytest.raises(ToolError):
                sb.write(path, "x")


def test_restore_tests_undoes_tampering(task):
    with Sandbox(task) as sb:
        (sb.root / "tests" / "test_solution.py").write_text("def test_x():\n    assert True\n")
        (sb.root / "conftest.py").write_text("")
        sb.restore_tests()
        assert sb.read("tests/test_solution.py") == task.tests["tests/test_solution.py"]
        assert not (sb.root / "conftest.py").exists()


def test_run_tests_counts_failures_on_buggy_code(task):
    with Sandbox(task) as sb:
        outcome = sb.run_tests()
    assert not outcome.all_passed
    assert outcome.total == task.expected_tests
    assert 0 <= outcome.passed < outcome.total


def test_run_tests_passes_on_solution(task):
    with Sandbox(task) as sb:
        sb.write("solution.py", task.solution["solution.py"])
        outcome = sb.run_tests()
    assert outcome.all_passed and outcome.passed == outcome.total


def test_syntax_error_is_detected(task):
    with Sandbox(task) as sb:
        sb.write("solution.py", "def broken(:\n")
        outcome = sb.run_tests()
    assert outcome.syntax_error and outcome.passed == 0


def test_hung_tests_time_out(task):
    with Sandbox(task, test_timeout_s=2) as sb:
        sb.write("solution.py", "while True:\n    pass\n")
        outcome = sb.run_tests()
    assert outcome.timed_out and not outcome.all_passed


def test_edited_files_reports_changes(task):
    with Sandbox(task) as sb:
        assert sb.edited_files() == []
        sb.write("solution.py", task.solution["solution.py"])
        sb.write("notes.txt", "hi")
        assert sb.edited_files() == ["notes.txt", "solution.py"]


def test_toolbox_validates_calls_and_logs_events(task):
    with Sandbox(task) as sb:
        box = ToolBox(sb)
        assert box.call("read_file", {"path": "solution.py"}).ok
        assert not box.call("nope", {}).ok                          # unknown tool
        assert not box.call("read_file", {}).ok                      # missing argument
        assert not box.call("read_file", {"path": 3}).ok             # wrong type
        assert not box.call("read_file", {"path": "x", "z": "y"}).ok  # extra argument
        assert not box.call("read_file", {"path": "missing.py"}).ok  # missing file
        assert not box.call("write_file", {"path": "tests/a.py", "content": ""}).ok
        assert not box.call("list_files", "not a dict").ok
        assert [e.step for e in box.events] == list(range(1, 9))
        assert box.valid_calls == 1


def test_replace_in_file_requires_a_unique_match(task):
    with Sandbox(task) as sb:
        box = ToolBox(sb)
        assert not box.call("replace_in_file", {"path": "solution.py", "old": "zzz", "new": "a"}).ok
        assert not box.call("replace_in_file", {"path": "solution.py", "old": "", "new": "a"}).ok
        assert not box.call("replace_in_file", {"path": "solution.py", "old": "i", "new": "j"}).ok
        assert box.call(
            "replace_in_file", {"path": "solution.py", "old": "range(1, n)", "new": "range(1, n + 1)"}
        ).ok
        assert box.call("run_tests", {}).ok
        assert box.events[-1].meta["all_passed"] is True


def test_tool_specs_are_well_formed():
    names = [s["name"] for s in TOOL_SPECS]
    assert len(names) == len(set(names))
    for spec in TOOL_SPECS:
        assert spec["input_schema"]["type"] == "object"
