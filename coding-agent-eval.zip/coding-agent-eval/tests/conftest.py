"""Shared fixtures."""

import pytest

from agent_eval.task_bank import build_task_bank


@pytest.fixture(scope="session")
def bank():
    return build_task_bank()


@pytest.fixture()
def task(bank):
    return next(t for t in bank if t.task_id == "range-sum-01")
