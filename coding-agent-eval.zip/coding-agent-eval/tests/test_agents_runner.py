import json

from agent_eval.agents import LLMAgent, build_initial_prompt
from agent_eval.llm import AnthropicChatClient, AssistantTurn, ToolCall
from agent_eval.models import AgentConfig, FailureType
from agent_eval.report import build_report
from agent_eval.runner import load_manifest, load_results, run_suite, run_task
from agent_eval.sandbox import Sandbox
from agent_eval.task_bank import select_tasks
import pytest
from types import SimpleNamespace


class ScriptedClient:
    """Test double standing in for a model: replays fixed turns."""

    def __init__(self, turns):
        self.turns = list(turns)
        self.seen = []

    def complete(self, system, messages, tools):
        self.seen.append(len(messages))
        return self.turns.pop(0)


def tool_turn(call_id, name, args):
    call = ToolCall(call_id, name, args)
    return AssistantTurn(blocks=[{"type": "tool_use", "id": call_id, "name": name, "input": args}],
                         tool_calls=[call], input_tokens=10, output_tokens=5)


def done(text="done"):
    return AssistantTurn(blocks=[{"type": "text", "text": text}], input_tokens=3, output_tokens=2)


def run_with_client(task, client, **overrides):
    config = AgentConfig(name="t", kind="llm", model="m", **overrides)
    import agent_eval.runner as runner

    original = runner.build_agent
    runner.build_agent = lambda cfg, seed=0, repeat=0: LLMAgent(cfg, client=client)
    try:
        return run_task(task, config, "run")
    finally:
        runner.build_agent = original


def test_llm_loop_solves_task_and_counts_tokens(task):
    client = ScriptedClient([
        tool_turn("1", "read_file", {"path": "solution.py"}),
        tool_turn("2", "write_file", {"path": "solution.py", "content": task.solution["solution.py"]}),
        tool_turn("3", "run_tests", {}),
        done(),
    ])
    result, trajectory = run_with_client(task, client)
    assert result.resolved and result.failure_type == "none"
    assert result.input_tokens == 33 and result.output_tokens == 17
    assert result.tool_calls == 3 and result.tool_call_accuracy == 1.0
    assert [e["tool"] for e in trajectory] == ["read_file", "write_file", "run_tests"]
    assert client.seen == [1, 3, 5, 7]  # history grows by assistant+tool_result each turn


def test_llm_agent_cannot_cheat_by_editing_tests(task):
    client = ScriptedClient([
        tool_turn("1", "write_file", {"path": "tests/test_solution.py", "content": "def test_a():\n    assert True\n"}),
        done(),
    ])
    result, _ = run_with_client(task, client)
    assert not result.resolved and result.failure_type == "tool_misuse"


def test_step_limit_and_client_error(task):
    endless = ScriptedClient([tool_turn(str(i), "list_files", {}) for i in range(10)])
    result, _ = run_with_client(task, endless, max_steps=3)
    assert result.failure_type == "step_limit" and result.steps == 3

    class Boom:
        def complete(self, *a):
            raise RuntimeError("api down")

    result, _ = run_with_client(task, Boom())
    assert result.failure_type == "agent_error" and "api down" in result.error


def test_initial_prompt_contents_depend_on_context_mode(task):
    from agent_eval.tools import ToolBox

    with Sandbox(task) as sb:
        initial = sb.run_tests()
        box = ToolBox(sb)
        none = build_initial_prompt(task, box, "none", initial)
        tree = build_initial_prompt(task, box, "tree", initial)
        full = build_initial_prompt(task, box, "full", initial)
    assert "helpers.py" not in none and "helpers.py" in tree
    assert "def test_" in full and "Initial test run" in full and "def test_" not in tree


def test_anthropic_client_converts_sdk_response():
    block_text = SimpleNamespace(type="text", text="hi")
    block_tool = SimpleNamespace(type="tool_use", id="tu_1", name="read_file", input={"path": "a.py"})
    response = SimpleNamespace(content=[block_text, block_tool], stop_reason="tool_use",
                               usage=SimpleNamespace(input_tokens=11, output_tokens=7))
    captured = {}

    class FakeMessages:
        def create(self, **kwargs):
            captured.update(kwargs)
            return response

    sdk = SimpleNamespace(messages=FakeMessages())
    turn = AnthropicChatClient("some-model", sdk_client=sdk).complete("sys", [{"role": "user", "content": "x"}], [])
    assert captured["model"] == "some-model" and captured["system"] == "sys"
    assert turn.text == "hi" and turn.tool_calls[0].args == {"path": "a.py"}
    assert (turn.input_tokens, turn.output_tokens) == (11, 7)
    assert turn.blocks[1] == {"type": "tool_use", "id": "tu_1", "name": "read_file", "input": {"path": "a.py"}}


def test_config_validation():
    with pytest.raises(ValueError):
        AgentConfig.from_dict({"name": "x", "bogus": 1})
    with pytest.raises(ValueError):
        AgentConfig.from_dict({"name": "x", "kind": "llm", "model": "YOUR_MODEL_ID"})
    with pytest.raises(ValueError):
        AgentConfig.from_dict({"name": "x", "profile": "superhuman"})
    assert AgentConfig.from_dict({"name": "ok", "kind": "llm", "model": "real"}).model == "real"


def test_mock_suite_is_deterministic_and_recorded(bank, tmp_path):
    tasks = select_tasks(bank, limit=12)
    configs = [AgentConfig.from_dict({"name": "s", "profile": "strong"}),
               AgentConfig.from_dict({"name": "w", "profile": "weak"})]
    run_a = run_suite(tasks, configs, tmp_path / "a", seed=7, workers=2)
    run_b = run_suite(tasks, configs, tmp_path / "b", seed=7, workers=2)
    strip = lambda rs: [(r.task_id, r.config_name, r.resolved, r.failure_type, r.steps) for r in rs]
    assert strip(load_results(run_a)) == strip(load_results(run_b))
    manifest = load_manifest(run_a)
    assert manifest["simulated"] is True and manifest["runs"] == 24
    for name in ("manifest.json", "results.jsonl", "trajectories.jsonl"):
        assert (run_a / name).exists()
    line = json.loads((run_a / "trajectories.jsonl").read_text().splitlines()[0])
    assert {"task_id", "config", "repeat", "events"} <= set(line)
    report = build_report(load_results(run_a), manifest)
    assert "Simulated results" in report and "McNemar" in report and "Failure analysis" in report


def test_every_mock_behaviour_maps_to_its_failure_type(bank):
    """Run the whole bank with a weak profile; each scripted behaviour must classify as intended."""
    from collections import Counter

    config = AgentConfig.from_dict({"name": "w", "profile": "weak"})
    seen = Counter()
    for t in bank[:60]:
        result, _ = run_task(t, config, "r", seed=1)
        seen[result.failure_type] += 1
        if result.failure_type == "none":
            assert result.resolved
    assert seen["none"] > 0 and len(seen) >= 5
