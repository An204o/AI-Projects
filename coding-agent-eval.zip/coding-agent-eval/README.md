# Coding Agent Evaluation Framework

Evaluates LLM coding agents on 112 software-engineering bug-fix tasks (Python, pytest).
Measures task completion, test pass rate, tool-call accuracy and execution time across agent
configurations; supports regression comparison between runs and failure analysis (10 failure types).

## Setup
    pip install -e ".[dev]"        # needs pytest>=8; add ".[llm]" for the Anthropic SDK

## Usage
    agent-eval list-tasks
    agent-eval validate-tasks               # proves every task fails before and passes after its reference fix
    agent-eval run --config configs/mock_configs.json --out runs/a
    agent-eval report runs/a
    agent-eval compare runs/a runs/b        # regression check
    # real model: copy configs/llm_example.json, set a real model id, export ANTHROPIC_API_KEY

## Tests
    pytest            # 40 tests (~2 min; sandboxed pytest subprocesses)

## Honest notes
- `kind: mock` configs are SIMULATED scripted agents (they read the reference fix). Their numbers test the
  harness only; reports carry a banner saying so. Real results need `kind: llm` runs with your API key.
- The 112 tasks are template-generated (28 bug patterns x 4 variants).
- Tests/config files are protected and restored before grading.
